package com.cms.user.service;



import java.util.List;

import com.cms.user.Entity.UserProfile;
import com.cms.user.dto.UserProfileListResponseDTO;
import com.cms.user.dto.UserProfileRequestDTO;
import com.cms.user.dto.UserProfileResponseDTO;

public interface UserProfileService {
	

		UserProfile createUser(UserProfile user);

	    List<UserProfile> getAllUsers();

	    UserProfile getUserById(Long id);

	    UserProfile updateUser(Long id, UserProfile user);

	    UserProfile deleteUser(Long id);


	

	/**	UserProfile createUser( UserProfileRequestDTO userDto);


		UserProfileListResponseDTO getAllUsers();

	    UserProfileResponseDTO getUserById(Long id);

	    UserProfileResponseDTO updateUser(Long id,
	            UserProfileRequestDTO userDto);

	    UserProfileResponseDTO deleteUser(Long id); **/

	
	
	
	
	
}
