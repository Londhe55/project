package com.cms.user.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.user.Entity.UserProfile;
import com.cms.user.dto.UserProfileListResponseDTO;
import com.cms.user.dto.UserProfileRequestDTO;
import com.cms.user.dto.UserProfileResponseDTO;
import com.cms.user.service.UserProfileService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/user")
@Tag( name="user-profile",description = "This is User Profile controller")
public class UserProfileController {

	@Autowired
	UserProfileService userService;

	 @PostMapping("/createuser")
	    @Operation(summary = "To add a User Profile")
	    public ResponseEntity<UserProfileResponseDTO> createUser( @Valid @RequestBody UserProfileRequestDTO dto) {

	        UserProfile savedUser = userService.createUser( dto.getUserProfile());
	        UserProfileResponseDTO response =new UserProfileResponseDTO();

	        response.setHttpStatusCode(200);
	        response.setMessage( "User Created Successfully");
	        response.setUser(savedUser);

	        return ResponseEntity.ok(response);
	    }

	    @GetMapping("/allusers")
	    @Operation(summary = "To see all the users")
	    public ResponseEntity<UserProfileListResponseDTO>  getAllUsers() {

	        List<UserProfile> users = userService.getAllUsers();

	        UserProfileListResponseDTO response = new UserProfileListResponseDTO();

	        response.setEmployees(users);
	        response.setHttpStatusCode(200);
	        response.setMessage(   users.size() + " Users Found");

	        return ResponseEntity.ok(response);
	    }

	    @GetMapping("/userbyid/{id}")
	    @Operation(summary = "To see a user by ID")
	    public ResponseEntity<UserProfileResponseDTO> getUserById( @PathVariable Long id) {

	        UserProfile user =  userService.getUserById(id);

	        UserProfileResponseDTO response =  new UserProfileResponseDTO();

	        response.setHttpStatusCode(200);
	        response.setMessage("User Found Successfully");
	        response.setUser(user);

	        return ResponseEntity.ok(response);
	    }

	    @PutMapping("/updateuser/{id}")
	    @Operation(summary = "To update a User")
	    public ResponseEntity<UserProfileResponseDTO> updateUser(   @PathVariable Long id,
	                    @Valid @RequestBody UserProfileRequestDTO dto) {

	        UserProfile updatedUser = userService.updateUser( id,dto.getUserProfile());
	        UserProfileResponseDTO response =  new UserProfileResponseDTO();

	        response.setHttpStatusCode(200);
	        response.setMessage("User Updated Successfully");
	        response.setUser(updatedUser);

	        return ResponseEntity.ok(response);
	    }

	    @DeleteMapping("/deleteuser/{id}")
	    @Operation(summary = "To delete a User")
	    public ResponseEntity<UserProfileResponseDTO>  deleteUser( @PathVariable Long id) {

	        UserProfile deletedUser =  userService.deleteUser(id);

	        UserProfileResponseDTO response = new UserProfileResponseDTO();

	        response.setHttpStatusCode(200);
	        response.setMessage( "User Deleted Successfully");
	        response.setUser(deletedUser);

	        return ResponseEntity.ok(response);
	    }


/**================================When DTO control is in service to ==========================================
 * 	@PostMapping("/createuser")
	@Operation(summary="To add a User Profile")
	public ResponseEntity<UserProfileResponseDTO> createUser(@Valid @RequestBody UserProfileRequestDTO dto) {

		UserProfile savedUser = userService.createUser(dto);

		UserProfileResponseDTO response = new UserProfileResponseDTO();

		response.setHttpStatusCode(200);
		response.setMessage("User Created Successfully");
		response.setUser(savedUser);

		return ResponseEntity.ok(response);
	}

	@GetMapping("/allusers")
	@Operation(summary="To see all the users ")
	public ResponseEntity<UserProfileListResponseDTO> getAllUsers() {

		UserProfileListResponseDTO response = userService.getAllUsers();

		return ResponseEntity.ok(response);
	}

	@GetMapping("/userbyid/{id}")
	@Operation(summary="To see a user by ID")
	public ResponseEntity<UserProfileResponseDTO> getUserById(@PathVariable Long id) {

		UserProfileResponseDTO user = userService.getUserById(id);

		user.setHttpStatusCode(200);
		user.setMessage("User Found Successfully");

		return ResponseEntity.ok(user);
	}

	@PutMapping("/updateuser/{id}")
	@Operation(summary="To update a User")
	public ResponseEntity<UserProfileResponseDTO> updateUser(@PathVariable Long id,
			@Valid @RequestBody UserProfileRequestDTO dto) {

		UserProfileResponseDTO user = userService.updateUser(id, dto);

		user.setHttpStatusCode(200);
		user.setMessage("User Updated Successfully");

		return ResponseEntity.ok(user);
	}

	@DeleteMapping("/deleteuser/{id}")
	@Operation(summary="To delete a User")
	public ResponseEntity<UserProfileResponseDTO> deleteUser(@PathVariable Long id) {

		UserProfileResponseDTO user = userService.deleteUser(id);

		user.setHttpStatusCode(200);
		user.setMessage("User Deleted Successfully");

		return ResponseEntity.ok(user);
	}	**/

}
