package com.cms.user.dto;

import com.cms.user.Entity.UserProfile;

public class UserProfileResponseDTO {


    private int httpStatusCode;

    private String message;

    private UserProfile user;

	public UserProfileResponseDTO() {
		super();
	}

	public UserProfileResponseDTO(int httpStatusCode, String message, UserProfile user) {
		super();
		this.httpStatusCode = httpStatusCode;
		this.message = message;
		this.user = user;
	}

	public int getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public UserProfile getUser() {
		return user;
	}

	public void setUser(UserProfile user) {
		this.user = user;
	}

}