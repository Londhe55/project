package com.cms.user.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotBlank;

@Embeddable
public class Preferences {
	
	@NotBlank
	 @Column(length = 20)
	private String theme;
	 
	 @Column(nullable = false)
	private boolean notifications;

	public Preferences() {
		super();
	}

	public Preferences(String theme, boolean notifications) {
		super();
		this.theme = theme;
		this.notifications = notifications;
	}

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public boolean isNotifications() {
		return notifications;
	}

	public void setNotifications(boolean notifications) {
		this.notifications = notifications;
	}
	

}
