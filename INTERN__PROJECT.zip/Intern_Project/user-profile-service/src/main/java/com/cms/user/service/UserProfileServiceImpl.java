package com.cms.user.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.user.Entity.UserProfile;
import com.cms.user.exceptions.UserListEmptyException;
import com.cms.user.exceptions.UserNotFoundException;
import com.cms.user.repos.UserProfileRepository;

@Service
public class UserProfileServiceImpl implements UserProfileService {

	@Autowired
	UserProfileRepository repo;
	

	 @Override
	    public UserProfile createUser(UserProfile user) {

	        user.setCreatedAt(LocalDateTime.now());

	        return repo.save(user);
	    }

	    @Override
	    public List<UserProfile> getAllUsers() {

	        List<UserProfile> users = repo.findAll();

	        if(users.isEmpty()) {
	            throw new UserListEmptyException(
	                    "No Users Found");
	        }

	        return users;
	    }

	    @Override
	    public UserProfile getUserById(Long id) {

	        return repo.findById(id)
	                .orElseThrow(() ->
	                        new UserNotFoundException(
	                                "User Not Found With Id : " + id));
	    }

	    @Override
	    public UserProfile updateUser(Long id,
	                                  UserProfile user) {

	        UserProfile existingUser =
	                repo.findById(id)
	                .orElseThrow(() ->
	                        new UserNotFoundException(
	                                "User Not Found With Id : " + id));

	        existingUser.setUsername( user.getUsername());

	        existingUser.setRole( user.getRole());

	        existingUser.setPreferences(
	                user.getPreferences());

	        return repo.save(existingUser);
	    }

	    @Override
	    public UserProfile deleteUser(Long id) {

	        UserProfile user =
	                repo.findById(id)
	                .orElseThrow(() ->
	                        new UserNotFoundException(
	                                "User Not Found With Id : " + id));

	        repo.delete(user);

	        return user;
	    }


/***================================When DTO control is in service to ==========================================
 * 	public UserProfile createUser(UserProfileRequestDTO userdto) {

		UserProfile user = userdto.getUserProfile();

		user.setCreatedAt(LocalDateTime.now());

		return repo.save(user);
	}

	@Override
	public UserProfileListResponseDTO getAllUsers() {

		List<UserProfile> users = repo.findAll();

		if (users.isEmpty()) {
			throw new UserListEmptyException("No Users Found");
		}

		UserProfileListResponseDTO dto = new UserProfileListResponseDTO();

		dto.setEmployees(users);
		dto.setHttpStatusCode(200);
		dto.setMessage(users.size() + " Users Found");

		return dto;
	}

	@Override
	public UserProfileResponseDTO getUserById(Long id) {

		UserProfile user = repo.findById(id)
				.orElseThrow(() -> new UserNotFoundException("User Not Found With Id : " + id));

		return convertToResponseDto(user);

	}

	@Override
	public UserProfileResponseDTO updateUser(Long id, UserProfileRequestDTO userDto) {

		UserProfile existingUser = repo.findById(id)
				.orElseThrow(() -> new UserNotFoundException("User Not Found With Id : " + id));

		UserProfile requestUser = userDto.getUserProfile();

		existingUser.setUsername(requestUser.getUsername());

		existingUser.setRole(requestUser.getRole());

		existingUser.setPreferences(requestUser.getPreferences());

		UserProfile updatedUser = repo.save(existingUser);

		return convertToResponseDto(updatedUser);
	}

	@Override
	public UserProfileResponseDTO deleteUser(Long id) {

		UserProfile user = repo.findById(id)
				.orElseThrow(() -> new UserNotFoundException("User Not Found With Id : " + id));

		repo.delete(user);

		return convertToResponseDto(user);

	}

	private UserProfileResponseDTO convertToResponseDto(UserProfile user) {

		UserProfileResponseDTO dto = new UserProfileResponseDTO();

		dto.setUser(user);

		return dto;
	}	**/
}
