package com.cms.user.dto;

import com.cms.user.Entity.UserProfile;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public class UserProfileRequestDTO {

    @Valid
    @NotNull(message = "User Profile is required")
    private UserProfile userProfile;

    public UserProfileRequestDTO() {
        super();
    }

    public UserProfileRequestDTO(
            UserProfile userProfile) {

        this.userProfile = userProfile;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public void setUserProfile(
            UserProfile userProfile) {

        this.userProfile = userProfile;
    }
}