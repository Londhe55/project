package com.cms.user.dto;

import java.util.List;

import com.cms.user.Entity.UserProfile;

public class UserProfileListResponseDTO {
	
	List<UserProfile> employees;
	int httpStatusCode;
	String message;
	
	public List<UserProfile> getEmployees() {
		return employees;
	}
	public void setEmployees(List<UserProfile> employees) {
		this.employees = employees;
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
