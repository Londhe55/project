package com.cms.user.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI userProfileAPI() {

        return new OpenAPI()

                .servers(List.of(
                        new Server()
                                .url("http://localhost:8080/user")))

                .info(new Info()

                        .title("User Profile Service")

                        .description("User Profile Management Microservice APIs")

                        .version("1.0")

                        .contact(new Contact()

                                .name("CMS Team")

                                .email("cms@company.com")));
    }
}