package com.cms.user.Entity;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "user_profiles")
public class UserProfile {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true)
	private Long id;
	

	 @NotBlank(message = "User Name is required")
	 @Size(max = 100,
	          message = "User Name should be less than 100 characters")

	@Column(nullable = false, length = 100)
	private String username;
	

	 @NotBlank(message = "Role is required")
	 @Size(max = 50,  message = "Role should not exceed 50 characters")
	@Column(nullable = false, length = 50)
	private String role;
	 
	@Valid
	@Embedded
	private Preferences preferences;
	
	
	@Column(name = "created_at",nullable = false)
	private LocalDateTime createdAt;

	
	/**Generate 3 constructors , see the uses of them 
	 * 1. No arg -> JPA needs it to create the table 
	 * 2.Constructor without id -> It is for Like here we are generating id , so 
	 * 3.All args constructor -> For testing or for Updating we pass all args so **/
	
	
	
	public UserProfile(long id, String username, String role, Preferences preferences, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.username = username;
		this.role = role;
		this.preferences = preferences;
		this.createdAt = createdAt;
	}

	public UserProfile() {
		super();
	}

	public UserProfile(String username, String role, Preferences preferences, LocalDateTime createdAt) {
		super();
		this.username = username;
		this.role = role;
		this.preferences = preferences;
		this.createdAt = createdAt;
	}

	public Long getId() {
		return id;
	}

	public void setId(long i) {
		this.id = i;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Preferences getPreferences() {
		return preferences;
	}

	public void setPreferences(Preferences preferences) {
		this.preferences = preferences;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	@Override
	public String toString() {
		return "UserProfile [id=" + id + ", username=" + username + ", role=" + role + ", preferences=" + preferences
				+ ", createdAt=" + createdAt + "]";
	}
	
	

}
