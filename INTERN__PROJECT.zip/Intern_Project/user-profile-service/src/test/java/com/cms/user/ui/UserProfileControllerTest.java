package com.cms.user.ui;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.cms.user.Entity.UserProfile;
import com.cms.user.service.UserProfileService;

@WebMvcTest(UserProfileController.class)
class UserProfileControllerTest {


	   @Autowired
	    private MockMvc mockMvc;

	    @MockitoBean
	    private UserProfileService userService;



@Test
    void testCreateUser() throws Exception {

        UserProfile user = new UserProfile();
        user.setId(1);
        user.setUsername("kavya");
        user.setRole("ADMIN");
        user.setCreatedAt(LocalDateTime.now());

        when(userService.createUser(any()))
                .thenReturn(user);

        String requestJson = """
            {
              "userProfile": {
                "username":"kavya",
                "role":"ADMIN",
                "preferences":{
                  "theme":"dark",
                  "notifications":true
                }
              }
            }
            """;

        mockMvc.perform(post("/user/createuser")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode", is(200)))
                .andExpect(jsonPath("$.message",
                        is("User Created Successfully")))
                .andExpect(jsonPath("$.user.id", is(1)))
                .andExpect(jsonPath("$.user.username",
                        is("kavya")))
                .andExpect(jsonPath("$.user.role",
                        is("ADMIN")));
    }

    @Test
    void testGetAllUsers() throws Exception {

        UserProfile user = new UserProfile();
        user.setId(1);
        user.setUsername("kavya");
        user.setRole("ADMIN");

        when(userService.getAllUsers())
                .thenReturn(Arrays.asList(user));

        mockMvc.perform(get("/user/allusers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode", is(200)))
                .andExpect(jsonPath("$.message",
                        is("1 Users Found")))
                .andExpect(jsonPath("$.employees[0].id",
                        is(1)))
                .andExpect(jsonPath("$.employees[0].username",
                        is("kavya")))
                .andExpect(jsonPath("$.employees[0].role",
                        is("ADMIN")));
    }

    @Test
    void testGetUserById() throws Exception {

        UserProfile user = new UserProfile();
        user.setId(1);
        user.setUsername("kavya");
        user.setRole("ADMIN");

        when(userService.getUserById(1L))
                .thenReturn(user);

        mockMvc.perform(get("/user/userbyid/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode", is(200)))
                .andExpect(jsonPath("$.message",
                        is("User Found Successfully")))
                .andExpect(jsonPath("$.user.id", is(1)))
                .andExpect(jsonPath("$.user.username",
                        is("kavya")))
                .andExpect(jsonPath("$.user.role",
                        is("ADMIN")));
    }

    @Test
    void testUpdateUser() throws Exception {

        UserProfile user = new UserProfile();
        user.setId(1);
        user.setUsername("updatedUser");
        user.setRole("ADMIN");

        when(userService.updateUser(any(), any()))
                .thenReturn(user);

        String requestJson = """
            {
              "userProfile": {
                "username":"updatedUser",
                "role":"ADMIN",
                "preferences":{
                  "theme":"dark",
                  "notifications":true
                }
              }
            }
            """;

        mockMvc.perform(put("/user/updateuser/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode", is(200)))
                .andExpect(jsonPath("$.message", is("User Updated Successfully")))
                .andExpect(jsonPath("$.user.id", is(1)))
                .andExpect(jsonPath("$.user.username",is("updatedUser")))
                .andExpect(jsonPath("$.user.role",  is("ADMIN")));
    }

    @Test
    void testDeleteUser() throws Exception {

        UserProfile user = new UserProfile();
        user.setId(1);
        user.setUsername("kavya");
        user.setRole("ADMIN");

        when(userService.deleteUser(1L))
                .thenReturn(user);

        mockMvc.perform(delete("/user/deleteuser/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode", is(200)))
                .andExpect(jsonPath("$.message",
                        is("User Deleted Successfully")))
                .andExpect(jsonPath("$.user.id", is(1)))
                .andExpect(jsonPath("$.user.username",
                        is("kavya")))
                .andExpect(jsonPath("$.user.role",
                        is("ADMIN")));
    

    }
}
