package com.cms.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cms.user.Entity.Preferences;
import com.cms.user.Entity.UserProfile;
import com.cms.user.exceptions.UserListEmptyException;
import com.cms.user.exceptions.UserNotFoundException;
import com.cms.user.repos.UserProfileRepository;

@ExtendWith(MockitoExtension.class)
class UserProfileServiceImplTest {

    @Mock
    private UserProfileRepository repo;

    @InjectMocks
    private UserProfileServiceImpl service;

    @Test
    void testCreateUser() {

        Preferences preferences =
                new Preferences("dark", true);

        UserProfile user = new UserProfile();

        user.setUsername("kavya");
        user.setRole("ADMIN");
        user.setPreferences(preferences);

        given(repo.save(user))
                .willReturn(user);

        UserProfile result =
                service.createUser(user);

        assertNotNull(result);

        assertEquals(
                "kavya",
                result.getUsername());
    }

    @Test
    void testGetAllUsers() {

        UserProfile user1 = new UserProfile();
        user1.setId(1);
        user1.setUsername("user1");

        UserProfile user2 = new UserProfile();
        user2.setId(2);
        user2.setUsername("user2");

        given(repo.findAll())
                .willReturn(
                        Arrays.asList(user1, user2));

        List<UserProfile> result =
                service.getAllUsers();

        assertNotNull(result);

        assertEquals(
                2,
                result.size());
    }

    @Test
    void testGetAllUsersEmpty() {

        given(repo.findAll())
                .willReturn(Collections.emptyList());

        assertThrows(
                UserListEmptyException.class,
                () -> service.getAllUsers());
    }

    @Test
    void testGetUserById() {

        UserProfile user = new UserProfile();

        user.setId(1);
        user.setUsername("kavya");

        given(repo.findById(1L))
                .willReturn(Optional.of(user));

        UserProfile result =
                service.getUserById(1L);

        assertNotNull(result);

        assertEquals(
                "kavya",
                result.getUsername());
    }

    @Test
    void testGetUserByIdNotFound() {

        given(repo.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                UserNotFoundException.class,
                () -> service.getUserById(1L));
    }

    @Test
    void testUpdateUser() {

        UserProfile existingUser =
                new UserProfile();

        existingUser.setId(1);
        existingUser.setUsername("oldUser");

        UserProfile requestUser =
                new UserProfile();

        requestUser.setUsername("newUser");
        requestUser.setRole("ADMIN");

        given(repo.findById(1L))
                .willReturn(Optional.of(existingUser));

        given(repo.save(existingUser))
                .willReturn(existingUser);

        UserProfile result =
                service.updateUser(
                        1L,
                        requestUser);

        assertNotNull(result);
    }

    @Test
    void testUpdateUserNotFound() {

        UserProfile user =
                new UserProfile();

        given(repo.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                UserNotFoundException.class,
                () -> service.updateUser(
                        1L,
                        user));
    }

    @Test
    void testDeleteUser() {

        UserProfile user =
                new UserProfile();

        user.setId(1);
        user.setUsername("kavya");

        given(repo.findById(1L))
                .willReturn(Optional.of(user));

        UserProfile result =
                service.deleteUser(1L);

        verify(repo, times(1))
                .delete(user);

        assertNotNull(result);
    }

    @Test
    void testDeleteUserNotFound() {

        given(repo.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                UserNotFoundException.class,
                () -> service.deleteUser(1L));
    }
}