package com.cms.user.repos;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import com.cms.user.Entity.Preferences;
import com.cms.user.Entity.UserProfile;

@DataJpaTest
class UserProfileRepositoryTest {

    @MockitoBean
    private UserProfileRepository repo;

    private UserProfile createUser() {

        UserProfile user = new UserProfile(
                "kavya",
                "ADMIN",
                new Preferences("dark", true),
                LocalDateTime.now());

        user.setId(1L);

        return user;
    }

    @Test
    void testSaveUser() {

        UserProfile user = createUser();

        given(repo.save(user))
                .willReturn(user);

        UserProfile savedUser =
                repo.save(user);

        assertThat(savedUser)
                .isNotNull();

        assertThat(savedUser.getId())
                .isEqualTo(1L);
    }

    @Test
    void testFindById() {

        UserProfile user = createUser();

        given(repo.findById(1L))
                .willReturn(Optional.of(user));

        Optional<UserProfile> result =
                repo.findById(1L);

        assertThat(result)
                .isPresent();

        assertThat(result.get().getUsername())
                .isEqualTo("kavya");
    }

    @Test
    void testFindAllUsers() {

        UserProfile user = createUser();

        List<UserProfile> users =
                List.of(user);

        given(repo.findAll())
                .willReturn(users);

        List<UserProfile> result =
                repo.findAll();

        assertThat(result)
                .isNotEmpty();

        assertThat(result.size())
                .isEqualTo(1);
    }

    @Test
    void testDeleteUser() {

        Long id = 1L;

        doNothing()
                .when(repo)
                .deleteById(id);

        repo.deleteById(id);

        given(repo.findById(id))
                .willReturn(Optional.empty());

        Optional<UserProfile> result =
                repo.findById(id);

        assertThat(result)
                .isEmpty();
    }

    @Test
    void testExistsById() {

        given(repo.existsById(1L))
                .willReturn(true);

        boolean exists =
                repo.existsById(1L);

        assertThat(exists)
                .isTrue();
    }
}