package com.training.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import com.training.model.AddressValidationModel;

@DataJpaTest
class AddressValidationRepositoryTest {

    @MockitoBean
    private AddressValidationRepository repository;

    private AddressValidationModel createModel() {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);
        model.setAddressType("PERMANENT");
        model.setCity("Chennai");
        model.setState("Tamil Nadu");
        model.setPin("600001");
        model.setIsValid(true);
        model.setValidationTimestamp(
                LocalDateTime.now());

        return model;
    }

    @Test
    void testSaveAddressValidation() {

        AddressValidationModel model =
                createModel();

        given(repository.save(model))
                .willReturn(model);

        AddressValidationModel saved =
                repository.save(model);

        assertNotNull(saved);
        assertNotNull(saved.getId());
    }

    @Test
    void testFindById() {

        AddressValidationModel model =
                createModel();

        given(repository.findById(1L))
                .willReturn(Optional.of(model));

        Optional<AddressValidationModel> result =
                repository.findById(1L);

        assertTrue(result.isPresent());
    }

    @Test
    void testFindAll() {

        AddressValidationModel model =
                createModel();

        List<AddressValidationModel> models =
                List.of(model);

        given(repository.findAll())
                .willReturn(models);

        List<AddressValidationModel> result =
                repository.findAll();

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }

    @Test
    void testExistsById() {

        given(repository.existsById(1L))
                .willReturn(true);

        assertTrue(
                repository.existsById(1L));
    }

    @Test
    void testDeleteById() {

        Long id = 1L;

        doNothing()
                .when(repository)
                .deleteById(id);

        repository.deleteById(id);

        given(repository.findById(id))
                .willReturn(Optional.empty());

        Optional<AddressValidationModel> result =
                repository.findById(id);

        assertFalse(result.isPresent());
    }
}