package com.training.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.training.model.AddressValidationModel;
import com.training.service.AddressValidationService;

@WebMvcTest(AddressValidationController.class)
class AddressValidationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private AddressValidationService service;

    @Test
    void testSaveAddressValidation() throws Exception {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);
        model.setAddressType("PERMANENT");
        model.setCity("Chennai");
        model.setState("Tamil Nadu");
        model.setPin("600001");
        model.setIsValid(true);
        model.setValidationTimestamp(LocalDateTime.now());

        when(service.saveAddressValidation(any()))
                .thenReturn(model);

        String json = """
                {
                  "addressValidation":{
                    "addressType":"PERMANENT",
                    "city":"Chennai",
                    "state":"Tamil Nadu",
                    "pin":"600001"
                  }
                }
                """;

        mockMvc.perform(post("/address/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(201))
                .andExpect(jsonPath("$.message")
                        .value("Address Validation Saved Successfully"))
                .andExpect(jsonPath("$.addressValidation.id")
                        .value(1))
                .andExpect(jsonPath("$.addressValidation.city")
                        .value("Chennai"));
    }

    @Test
    void testGetAddressValidationById()
            throws Exception {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);
        model.setAddressType("PERMANENT");
        model.setCity("Chennai");

        when(service.getAddressValidationById(1L))
                .thenReturn(model);

        mockMvc.perform(get("/address/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(200))
                .andExpect(jsonPath("$.message")
                        .value("Record Fetched Successfully"))
                .andExpect(jsonPath("$.addressValidation.id")
                        .value(1));
    }

    @Test
    void testGetAllAddressValidations()
            throws Exception {

        List<AddressValidationModel> addressList =
                new ArrayList<>();

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);
        model.setCity("Chennai");

        addressList.add(model);

        when(service.getAllAddressValidations())
                .thenReturn(addressList);

        mockMvc.perform(get("/address"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(200))
                .andExpect(jsonPath("$.addresses[0].id")
                        .value(1));
    }

    @Test
    void testUpdateAddressValidation()
            throws Exception {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);
        model.setCity("Bangalore");

        when(service.updateAddressValidation(
                any(),
                any()))
                .thenReturn(model);

        String json = """
                {
                  "addressValidation":{
                    "addressType":"PERMANENT",
                    "city":"Bangalore",
                    "state":"Karnataka",
                    "pin":"560001"
                  }
                }
                """;

        mockMvc.perform(put("/address/update/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(200))
                .andExpect(jsonPath("$.addressValidation.city")
                        .value("Bangalore"));
    }

    @Test
    void testDeleteAddressValidation()
            throws Exception {

        doNothing()
                .when(service)
                .deleteAddressValidation(1L);

        mockMvc.perform(
                delete("/address/delete/1"))
                .andExpect(status().isOk())
                .andExpect(content()
                        .string("Record Deleted Successfully"));
    }
}