package com.training.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.exception.ResourceListNotFoundException;
import com.training.exception.ResourceNotFoundException;
import com.training.model.AddressValidationModel;
import com.training.repository.AddressValidationRepository;

@ExtendWith(MockitoExtension.class)
class AddressValidationServiceImplTest {

    @Mock
    private AddressValidationRepository repository;

    @InjectMocks
    private AddressValidationServiceImpl service;

    @Test
    void testSaveAddressValidation() {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setAddressType("PERMANENT");
        model.setCity("Chennai");

        AddressValidationModel saved =
                new AddressValidationModel();

        saved.setId(1L);
        saved.setAddressType("PERMANENT");
        saved.setCity("Chennai");
        saved.setValidationTimestamp(
                LocalDateTime.now());

        given(repository.save(model))
                .willReturn(saved);

        AddressValidationModel response =
                service.saveAddressValidation(model);

        assertNotNull(response);

        assertEquals(
                1L,
                response.getId());
    }

    @Test
    void testGetAddressValidationById() {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);

        given(repository.findById(1L))
                .willReturn(Optional.of(model));

        assertEquals(
                1L,
                service.getAddressValidationById(1L)
                        .getId());
    }

    @Test
    void testGetAddressValidationByIdNotFound() {

        given(repository.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getAddressValidationById(
                        1L));
    }

    @Test
    void testGetAllAddressValidations() {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);

        given(repository.findAll())
                .willReturn(List.of(model));

        assertEquals(
                1,
                service.getAllAddressValidations()
                        .size());
    }

    @Test
    void testGetAllAddressValidationsEmpty() {

        given(repository.findAll())
                .willReturn(Collections.emptyList());

        assertThrows(
                ResourceListNotFoundException.class,
                () -> service.getAllAddressValidations());
    }

    @Test
    void testUpdateAddressValidation() {

        AddressValidationModel existing =
                new AddressValidationModel();

        existing.setId(1L);
        existing.setCity("Chennai");

        AddressValidationModel request =
                new AddressValidationModel();

        request.setAddressType("PERMANENT");
        request.setCity("Bangalore");

        given(repository.findById(1L))
                .willReturn(Optional.of(existing));

        given(repository.save(existing))
                .willReturn(existing);

        AddressValidationModel result =
                service.updateAddressValidation(
                        1L,
                        request);

        assertEquals(
                "Bangalore",
                result.getCity());
    }

    @Test
    void testDeleteAddressValidation() {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setId(1L);

        given(repository.findById(1L))
                .willReturn(Optional.of(model));

        service.deleteAddressValidation(1L);

        verify(repository)
                .delete(model);
    }

    @Test
    void testDeleteAddressValidationNotFound() {

        given(repository.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.deleteAddressValidation(
                        1L));
    }
}