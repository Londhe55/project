package com.training.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.exception.ResourceListNotFoundException;
import com.training.exception.ResourceNotFoundException;
import com.training.model.AddressValidationModel;
import com.training.repository.AddressValidationRepository;

@Service
public class AddressValidationServiceImpl
        implements AddressValidationService {

    @Autowired
    private AddressValidationRepository repository;

    @Override
    public AddressValidationModel saveAddressValidation(
            AddressValidationModel model) {

        model.setIsValid(true);
        model.setValidationTimestamp(
                LocalDateTime.now());

        return repository.save(model);
    }

    @Override
    public AddressValidationModel
    getAddressValidationById(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Record not found with id : "
                                        + id));
    }

    @Override
    public List<AddressValidationModel>
    getAllAddressValidations() {

        List<AddressValidationModel> addressList =
                repository.findAll();

        if (addressList.isEmpty()) {

            throw new ResourceListNotFoundException(
                    "No Address Validation Records Found");
        }

        return addressList;
    }

    @Override
    public AddressValidationModel
    updateAddressValidation(
            Long id,
            AddressValidationModel model) {

        AddressValidationModel existingModel =
                repository.findById(id)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Record not found with id : "
                                                + id));

        existingModel.setAddressType(
                model.getAddressType());

        existingModel.setCity(
                model.getCity());

        existingModel.setState(
                model.getState());

        existingModel.setPin(
                model.getPin());

        existingModel.setIsValid(true);

        existingModel.setValidationTimestamp(
                LocalDateTime.now());

        return repository.save(existingModel);
    }

    @Override
    public void deleteAddressValidation(Long id) {

        repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Record not found with id : "
                                        + id));

        repository.deleteById(id);
    }
}