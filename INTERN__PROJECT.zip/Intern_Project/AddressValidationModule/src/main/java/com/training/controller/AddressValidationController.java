package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.dto.AddressValidationListResponseDTO;
import com.training.dto.AddressValidationRequestDTO;
import com.training.dto.AddressValidationResponseDTO;
import com.training.model.AddressValidationModel;
import com.training.service.AddressValidationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/address")
@Tag(name = "Address Validation", description = "Address Validation APIs")
public class AddressValidationController {

	@Autowired
	private AddressValidationService service;

	@PostMapping("/validate")
	public ResponseEntity<AddressValidationResponseDTO>
	validateAddress(
	        @RequestBody
	        com.training.feign.dto.AddressValidationRequestDTO request) {

	    AddressValidationResponseDTO response =
	            new AddressValidationResponseDTO();

	    boolean valid =
	            request.getPin() != null
	            &&
	            request.getPin().length() == 6;

	    response.setIsValid(valid);

	    return ResponseEntity.ok(response);
	}

	@Operation(summary = "Save Address Validation Record", description = "Creates a new Address Validation record")
	@PostMapping("/save")
	public AddressValidationResponseDTO saveAddressValidation(
			@Valid @RequestBody AddressValidationRequestDTO requestDTO) {

		AddressValidationModel savedModel = service.saveAddressValidation(requestDTO.getAddressValidation());

		AddressValidationResponseDTO response = new AddressValidationResponseDTO();

		response.setAddressValidation(savedModel);
		response.setHttpStatusCode(201);
		response.setMessage("Address Validation Saved Successfully");

		return response;
	}

	@Operation(summary = "Get Record By ID", description = "Fetch Address Validation record by ID")
	@GetMapping("/{id}")
	public AddressValidationResponseDTO getAddressValidationById(@PathVariable Long id) {

		AddressValidationModel model = service.getAddressValidationById(id);

		AddressValidationResponseDTO response = new AddressValidationResponseDTO();

		response.setAddressValidation(model);
		response.setHttpStatusCode(200);
		response.setMessage("Record Fetched Successfully");

		return response;
	}

	@Operation(summary = "Get All Records", description = "Fetch all Address Validation records")
	@GetMapping
	public AddressValidationListResponseDTO getAllAddressValidations() {

		List<AddressValidationModel> addressList = service.getAllAddressValidations();

		AddressValidationListResponseDTO response = new AddressValidationListResponseDTO();

		response.setAddresses(addressList);
		response.setHttpStatusCode(200);
		response.setMessage("Records Fetched Successfully");

		return response;
	}

	@Operation(summary = "Update Record", description = "Update Address Validation record")
	@PutMapping("/update/{id}")
	public AddressValidationResponseDTO updateAddressValidation(@PathVariable Long id,
			@Valid @RequestBody AddressValidationRequestDTO requestDTO) {

		AddressValidationModel updatedModel = service.updateAddressValidation(id, requestDTO.getAddressValidation());

		AddressValidationResponseDTO response = new AddressValidationResponseDTO();

		response.setAddressValidation(updatedModel);
		response.setHttpStatusCode(200);
		response.setMessage("Record Updated Successfully");

		return response;
	}

	@Operation(summary = "Delete Record", description = "Delete Address Validation record by ID")
	@DeleteMapping("/delete/{id}")
	public String deleteAddressValidation(@PathVariable Long id) {

		service.deleteAddressValidation(id);

		return "Record Deleted Successfully";
	}
}