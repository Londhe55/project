package com.training.service;

import java.util.List;

import com.training.model.AddressValidationModel;

public interface AddressValidationService {

    AddressValidationModel saveAddressValidation(
            AddressValidationModel model);

    AddressValidationModel getAddressValidationById(
            Long id);

    List<AddressValidationModel>
    getAllAddressValidations();

    AddressValidationModel updateAddressValidation(
            Long id,
            AddressValidationModel model);

    void deleteAddressValidation(
            Long id);
}