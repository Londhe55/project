package com.training.exception;

public class ResourceListNotFoundException
        extends RuntimeException {

    public ResourceListNotFoundException(
            String message) {
        super(message);
    }
}