package com.training.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "customers")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "first_name", nullable = false)
    private String firstName;

    @NotBlank
    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Column(name = "nick_name")
    private String nickName;

    @NotNull
    @Column(name = "sex", nullable = false)
    private Character sex;

    @NotNull
    @Column(name = "age", nullable = false)
    private Integer age;

    @NotBlank
    @Column(name = "qualification", nullable = false)
    private String qualification;

   
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "houseNo", column = @Column(name = "permanent_house_no")),
        @AttributeOverride(name = "street", column = @Column(name = "permanent_street")),
        @AttributeOverride(name = "landmark", column = @Column(name = "permanent_landmark")),
        @AttributeOverride(name = "city", column = @Column(name = "permanent_city")),
        @AttributeOverride(name = "state", column = @Column(name = "permanent_state")),
        @AttributeOverride(name = "pin", column = @Column(name = "permanent_pin"))
    })
    private Address permanentAddress;

    // ✅ ✅ COMMUNICATION ADDRESS (Embedded)
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "houseNo", column = @Column(name = "communication_house_no")),
        @AttributeOverride(name = "street", column = @Column(name = "communication_street")),
        @AttributeOverride(name = "landmark", column = @Column(name = "communication_landmark")),
        @AttributeOverride(name = "city", column = @Column(name = "communication_city")),
        @AttributeOverride(name = "state", column = @Column(name = "communication_state")),
        @AttributeOverride(name = "pin", column = @Column(name = "communication_pin"))
    })
    private Address communicationAddress;

    @Column(name = "notes")
    private String notes;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public Character getSex() {
		return sex;
	}

	public void setSex(Character sex) {
		this.sex = sex;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public Address getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(Address permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public Address getCommunicationAddress() {
		return communicationAddress;
	}

	public void setCommunicationAddress(Address communicationAddress) {
		this.communicationAddress = communicationAddress;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

    
    
    
}