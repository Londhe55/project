package com.training.feign.dto;
 
public class AddressValidationRequestDTO {
 
    private String addressType;
    private String city;
    private String state;
    private String pin;
 
    public AddressValidationRequestDTO() {
    }
 
    public String getAddressType() {
        return addressType;
    }
 
    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }
 
    public String getCity() {
        return city;
    }
 
    public void setCity(String city) {
        this.city = city;
    }
 
    public String getState() {
        return state;
    }
 
    public void setState(String state) {
        this.state = state;
    }
 
    public String getPin() {
        return pin;
    }
 
    public void setPin(String pin) {
        this.pin = pin;
    }
}