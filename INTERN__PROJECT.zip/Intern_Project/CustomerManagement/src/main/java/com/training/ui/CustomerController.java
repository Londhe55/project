package com.training.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.feign.AddressValidationFeignClient;
import com.training.feign.AuditFeignClient;
import com.training.feign.dto.AddressValidationRequestDTO;
import com.training.feign.dto.AddressValidationResponseDTO;
import com.training.feign.dto.AuditRequestDTO;
import com.training.feign.dto.AuditResponseDTO;

import com.training.dto.CustomerListResponseDto;
import com.training.dto.CustomerRequestDTO;
import com.training.dto.CustomerResponseDTO;
import com.training.feign.AddressValidationFeignClient;
import com.training.feign.AuditFeignClient;
import com.training.model.Customer;
import com.training.service.CustomerService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;

@RestController
@RequestMapping("/cms")
@Validated
@Tag(name = "Customer Controller", description = "Customer Management APIs")
public class CustomerController {

	@Autowired
	private CustomerService service;

	@Autowired
	private AddressValidationFeignClient addressValidationFeignClient;

	@Autowired
	private AuditFeignClient auditFeignClient;

	@PostMapping("/save")
	@Operation(summary = "Create Customer")
	public ResponseEntity<CustomerResponseDTO> saveCustomer(@Valid @RequestBody CustomerRequestDTO dto) {

		AddressValidationRequestDTO validationDto = new AddressValidationRequestDTO();

		validationDto.setAddressType("PERMANENT");

		validationDto.setCity(dto.getCustomer().getPermanentAddress().getCity());

		validationDto.setState(dto.getCustomer().getPermanentAddress().getState());

		validationDto.setPin(dto.getCustomer().getPermanentAddress().getPin());

		AddressValidationResponseDTO validationResponse = addressValidationFeignClient.validateAddress(validationDto);

		if (!validationResponse.getIsValid()) {

			throw new RuntimeException("Invalid Address");
		}

		Customer savedCustomer = service.saveCustomer(dto.getCustomer());

		AuditRequestDTO auditRequest = new AuditRequestDTO();

		auditRequest.setCustomerId(savedCustomer.getId());

		auditRequest.setAction("CREATE");

		auditRequest.setPerformedBy("SYSTEM");

		auditRequest.setDetails("Customer Created Successfully");

		AuditResponseDTO auditResponse = auditFeignClient.saveAudit(auditRequest);

		if (!auditResponse.isSuccess()) {

			throw new RuntimeException(auditResponse.getMessage());
		}

		CustomerResponseDTO response = new CustomerResponseDTO();

		response.setCustomer(savedCustomer);

		response.setHttpStatusCode(201);

		response.setMessage("Customer created successfully");

		return ResponseEntity.status(201).body(response);
	}

	@GetMapping("/findall")
	@Operation(summary = "Fetch All Customers")
	public ResponseEntity<CustomerListResponseDto> getAllCustomers() {

		List<Customer> customers = service.getAllCustomers();

		CustomerListResponseDto response = new CustomerListResponseDto();

		response.setCustomers(customers);
		response.setHttpStatusCode(200);
		response.setMessage(customers.size() + " Customers fetched successfully");

		return ResponseEntity.ok(response);
	}

	@GetMapping("/fetch/{id}")
	@Operation(summary = "Fetch Customer By Id")
	public ResponseEntity<CustomerResponseDTO> getCustomerById(
			@PathVariable @Positive(message = "Customer ID must be greater than 0") Long id) {

		Customer customer = service.getCustomerById(id);

		CustomerResponseDTO response = new CustomerResponseDTO();

		response.setCustomer(customer);
		response.setHttpStatusCode(200);
		response.setMessage("Customer found");

		return ResponseEntity.ok(response);
	}

	@PutMapping("/update/{id}")
	@Operation(summary = "Update Customer")
	public ResponseEntity<CustomerResponseDTO> updateCustomer(
			@PathVariable @Positive(message = "Customer ID must be greater than 0") Long id,

			@Valid @RequestBody Customer customer) {

		AddressValidationRequestDTO validationDto = new AddressValidationRequestDTO();

		validationDto.setAddressType("PERMANENT");

		validationDto.setCity(customer.getPermanentAddress().getCity());

		validationDto.setState(customer.getPermanentAddress().getState());

		validationDto.setPin(customer.getPermanentAddress().getPin());

		AddressValidationResponseDTO validationResponse = addressValidationFeignClient.validateAddress(validationDto);

		if (!validationResponse.getIsValid()) {

			throw new RuntimeException("Invalid Address");
		}

		Customer updatedCustomer = service.updateCustomer(id, customer);

		AuditRequestDTO auditRequest = new AuditRequestDTO();

		auditRequest.setCustomerId(updatedCustomer.getId());

		auditRequest.setAction("UPDATE");

		auditRequest.setPerformedBy("SYSTEM");

		auditRequest.setDetails("Customer Updated Successfully");

		AuditResponseDTO auditResponse = auditFeignClient.saveAudit(auditRequest);

		if (!auditResponse.isSuccess()) {

			throw new RuntimeException(auditResponse.getMessage());
		}

		CustomerResponseDTO response = new CustomerResponseDTO();

		response.setCustomer(updatedCustomer);

		response.setHttpStatusCode(200);

		response.setMessage("Customer updated successfully");

		return ResponseEntity.ok(response);
	}

	@DeleteMapping("/delete/{id}")
	@Operation(summary = "Delete Customer")
	public ResponseEntity<CustomerResponseDTO> deleteCustomer(
			@PathVariable @Positive(message = "Customer ID must be greater than 0") Long id) {

		String message = service.deleteCustomer(id);

		AuditRequestDTO auditRequest = new AuditRequestDTO();

		auditRequest.setCustomerId(id);

		auditRequest.setAction("DELETE");

		auditRequest.setPerformedBy("SYSTEM");

		auditRequest.setDetails("Customer Deleted Successfully");

		AuditResponseDTO auditResponse = auditFeignClient.saveAudit(auditRequest);

		if (!auditResponse.isSuccess()) {

			throw new RuntimeException(auditResponse.getMessage());
		}

		CustomerResponseDTO response = new CustomerResponseDTO();

		response.setHttpStatusCode(202);

		response.setMessage(message);

		return ResponseEntity.status(202).body(response);
	}
}