package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.db.CustomerRepository;
import com.training.exception.CustomerListEmptyException;
import com.training.exception.CustomerNotFoundException;
import com.training.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository repo;

    @Override
    public Customer saveCustomer(Customer customer) {
        return repo.save(customer);
    }

    @Override
    public List<Customer> getAllCustomers() throws CustomerListEmptyException {

        List<Customer> customers = repo.findAll();

        if (customers.isEmpty()) {
            throw new CustomerListEmptyException("No Customers Found");
        }

        return customers;
    }

    @Override
    public Customer getCustomerById(Long id)
            throws CustomerNotFoundException {

        return repo.findById(id)
                .orElseThrow(() ->
                        new CustomerNotFoundException(
                                "Customer with ID " + id + " Not Found"));
    }

    @Override
    public Customer updateCustomer(Long id, Customer customer)
            throws CustomerNotFoundException {

        Customer existing = repo.findById(id)
                .orElseThrow(() ->
                        new CustomerNotFoundException(
                                "Customer with ID " + id + " Not Found"));

        existing.setFirstName(customer.getFirstName());
        existing.setLastName(customer.getLastName());
        existing.setNickName(customer.getNickName());
        existing.setSex(customer.getSex());
        existing.setAge(customer.getAge());
        existing.setQualification(customer.getQualification());
        existing.setNotes(customer.getNotes());

        existing.setPermanentAddress(customer.getPermanentAddress());
        existing.setCommunicationAddress(customer.getCommunicationAddress());

        return repo.save(existing);
    }

    @Override
    public String deleteCustomer(Long id)
            throws CustomerNotFoundException {

        Customer customer = repo.findById(id)
                .orElseThrow(() ->
                        new CustomerNotFoundException(
                                "Customer with ID " + id + " Not Found"));

        repo.delete(customer);

        return "Customer deleted successfully";
    }
}