package com.training.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.training.feign.dto.AuditRequestDTO;
import com.training.feign.dto.AuditResponseDTO;


@FeignClient(name = "AUDIT-SERVICE")
public interface AuditFeignClient {

    @PostMapping("/audit/saveAudit")
    AuditResponseDTO saveAudit(
            @RequestBody AuditRequestDTO dto);
}