package com.training.feign.dto;

public class AuditRequestDTO {
 
    private Long customerId;
    private String action;
    private String performedBy;
    private String details;
 
    public AuditRequestDTO() {
    }
 
    public Long getCustomerId() {
        return customerId;
    }
 
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
 
    public String getAction() {
        return action;
    }
 
    public void setAction(String action) {
        this.action = action;
    }
 
    public String getPerformedBy() {
        return performedBy;
    }
 
    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }
 
    public String getDetails() {
        return details;
    }
 
    public void setDetails(String details) {
        this.details = details;
    }
}