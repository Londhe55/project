package com.training.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customerAPI() {

        return new OpenAPI()

                .servers(List.of(
                        new Server()
                                .url("http://localhost:8080/customer")))

                .info(new Info()

                        .title("Customer Service")

                        .description("Customer Management Microservice APIs")

                        .version("1.0")

                        .contact(new Contact()

                                .name("CMS Team")

                                .email("cms@company.com")));
    }
}