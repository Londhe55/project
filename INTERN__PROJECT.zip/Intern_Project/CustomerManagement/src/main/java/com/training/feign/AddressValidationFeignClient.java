package com.training.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.training.feign.dto.*;

@FeignClient(name = "ADDRESS-VALIDATION-SERVICE")
public interface AddressValidationFeignClient {

    @PostMapping("/address/validate")
    AddressValidationResponseDTO validateAddress(
        @RequestBody
        AddressValidationRequestDTO request);
}

