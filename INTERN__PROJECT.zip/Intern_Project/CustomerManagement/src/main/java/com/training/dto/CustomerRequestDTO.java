package com.training.dto;

import com.training.model.Customer;



public class CustomerRequestDTO {

    
    private Customer customer;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}