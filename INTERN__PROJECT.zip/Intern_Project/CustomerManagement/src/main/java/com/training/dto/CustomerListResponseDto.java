package com.training.dto;
 
import java.util.List;
 
import com.training.model.Customer;
 
public class CustomerListResponseDto {
	private int httpStatusCode;
    private String message;
    private List<Customer> customers;
    
 
    public List<Customer> getCustomers() {
        return customers;
    }
 
    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }
 
    public int getHttpStatusCode() {
        return httpStatusCode;
    }
 
    public void setHttpStatusCode(int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }
 
    public String getMessage() {
        return message;
    }
 
    public void setMessage(String message) {
        this.message = message;
    }
}