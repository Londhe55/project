package com.training.feign.dto;
 
import java.time.LocalDateTime;
 
public class AddressValidationResponseDTO {
 
    private Long id;
    private String addressType;
    private String city;
    private String state;
    private String pin;
    private Boolean isValid;
    private LocalDateTime validationTimestamp;
 
    public AddressValidationResponseDTO() {
    }
 
    public Long getId() {
        return id;
    }
 
    public void setId(Long id) {
        this.id = id;
    }
 
    public String getAddressType() {
        return addressType;
    }
 
    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }
 
    public String getCity() {
        return city;
    }
 
    public void setCity(String city) {
        this.city = city;
    }
 
    public String getState() {
        return state;
    }
 
    public void setState(String state) {
        this.state = state;
    }
 
    public String getPin() {
        return pin;
    }
 
    public void setPin(String pin) {
        this.pin = pin;
    }
 
    public Boolean getIsValid() {
        return isValid;
    }
 
    public void setIsValid(Boolean isValid) {
        this.isValid = isValid;
    }
 
    public LocalDateTime getValidationTimestamp() {
        return validationTimestamp;
    }
 
    public void setValidationTimestamp(LocalDateTime validationTimestamp) {
        this.validationTimestamp = validationTimestamp;
    }
}