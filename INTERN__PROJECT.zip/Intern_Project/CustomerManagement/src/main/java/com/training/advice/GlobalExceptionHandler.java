package com.training.advice;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.training.exception.CustomerListEmptyException;
import com.training.exception.CustomerNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<Map<String, Object>>
            handleCustomerNotFound(
                    CustomerNotFoundException ex) {

        Map<String, Object> body =
                new LinkedHashMap<>();

        body.put("httpStatusCode", 404);
        body.put("message", ex.getMessage());

        return new ResponseEntity<>(
                body,
                HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CustomerListEmptyException.class)
    public ResponseEntity<Map<String, Object>>
            handleCustomerListEmpty(
                    CustomerListEmptyException ex) {

        Map<String, Object> body =
                new LinkedHashMap<>();

        body.put("httpStatusCode", 404);
        body.put("message", ex.getMessage());

        return new ResponseEntity<>(
                body,
                HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>>
            handleValidationErrors(
                    MethodArgumentNotValidException ex) {

        Map<String, String> errors =
                new HashMap<>();

        ex.getBindingResult()
                .getFieldErrors()
                .forEach(error ->
                        errors.put(
                                error.getField(),
                                error.getDefaultMessage()));

        Map<String, Object> body =
                new HashMap<>();

        body.put("httpStatusCode", 400);
        body.put("validationErrors", errors);

        return new ResponseEntity<>(
                body,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>>
            handleGenericException(
                    Exception ex) {

        Map<String, Object> body =
                new LinkedHashMap<>();

        body.put("httpStatusCode", 500);
        body.put("message", ex.getMessage());

        return new ResponseEntity<>(
                body,
                HttpStatus.INTERNAL_SERVER_ERROR);
    }
}