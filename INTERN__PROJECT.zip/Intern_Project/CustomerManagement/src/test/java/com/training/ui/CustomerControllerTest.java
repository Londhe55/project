package com.training.ui;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.model.Address;
import com.training.model.Customer;
import com.training.service.CustomerService;

@WebMvcTest(CustomerController.class)
class CustomerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CustomerService service;

    @Autowired
    private ObjectMapper objectMapper;

    private Customer createCustomer() {

        Address address = new Address();

        address.setHouseNo("123");
        address.setStreet("Main Street");
        address.setLandmark("Near Park");
        address.setCity("Chennai");
        address.setState("TN");
        address.setPin("600001");

        Customer customer = new Customer();

        customer.setId(1L);
        customer.setFirstName("John");
        customer.setLastName("Doe");
        customer.setNickName("Johnny");
        customer.setSex('M');
        customer.setAge(25);
        customer.setQualification("MBA");
        customer.setPermanentAddress(address);
        customer.setCommunicationAddress(address);
        customer.setNotes("Test Notes");

        return customer;
    }

    @Test
    void testSaveCustomer() throws Exception {

        Customer customer = createCustomer();

        when(service.saveCustomer(any(Customer.class)))
                .thenReturn(customer);

        String json = """
        {
          "customer": {
            "firstName": "John",
            "lastName": "Doe",
            "nickName": "Johnny",
            "sex": "M",
            "age": 25,
            "qualification": "MBA",
            "permanentAddress": {
              "houseNo": "123",
              "street": "Main Street",
              "landmark": "Near Park",
              "city": "Chennai",
              "state": "TN",
              "pin": "600001"
            },
            "communicationAddress": {
              "houseNo": "123",
              "street": "Main Street",
              "landmark": "Near Park",
              "city": "Chennai",
              "state": "TN",
              "pin": "600001"
            },
            "notes": "Test Notes"
          }
        }
        """;

        mockMvc.perform(post("/cms/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(201))
                .andExpect(jsonPath("$.message")
                        .value("Customer created successfully"))
                .andExpect(jsonPath("$.customer.id")
                        .value(1))
                .andExpect(jsonPath("$.customer.firstName")
                        .value("John"));
    }

    @Test
    void testGetCustomerById() throws Exception {

        Customer customer = createCustomer();

        when(service.getCustomerById(1L))
                .thenReturn(customer);

        mockMvc.perform(get("/cms/fetch/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(200))
                .andExpect(jsonPath("$.message")
                        .value("Customer found"))
                .andExpect(jsonPath("$.customer.id")
                        .value(1))
                .andExpect(jsonPath("$.customer.firstName")
                        .value("John"));
    }

    @Test
    void testUpdateCustomer() throws Exception {

        Customer customer = createCustomer();

        when(service.updateCustomer(
                eq(1L),
                any(Customer.class)))
                .thenReturn(customer);

        mockMvc.perform(put("/cms/update/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(201))
                .andExpect(jsonPath("$.message")
                        .value("Customer updated successfully"));
    }

    @Test
    void testDeleteCustomer() throws Exception {

        when(service.deleteCustomer(1L))
                .thenReturn("Customer deleted successfully");

        mockMvc.perform(delete("/cms/delete/1"))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(202))
                .andExpect(jsonPath("$.message")
                        .value("Customer deleted successfully"));
    }
}