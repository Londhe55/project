package com.training.db;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import com.training.model.Address;
import com.training.model.Customer;
 
@DataJpaTest
class CustomerRepositoryTest {
 
    @MockitoBean
    private CustomerRepository customerRepository;
 
    private Customer createCustomer() {
 
        Address permanentAddress = new Address();
        permanentAddress.setHouseNo("10");
        permanentAddress.setStreet("Main Street");
        permanentAddress.setLandmark("Near Park");
        permanentAddress.setCity("Chennai");
        permanentAddress.setState("TN");
        permanentAddress.setPin("600001");
 
        Address communicationAddress = new Address();
        communicationAddress.setHouseNo("20");
        communicationAddress.setStreet("Second Street");
        communicationAddress.setLandmark("Near Mall");
        communicationAddress.setCity("Chennai");
        communicationAddress.setState("TN");
        communicationAddress.setPin("600002");
 
        Customer customer = new Customer();
        customer.setId(1L);
        customer.setFirstName("John");
        customer.setLastName("Doe");
        customer.setNickName("JD");
        customer.setSex('M');
        customer.setAge(25);
        customer.setQualification("B.Tech");
        customer.setPermanentAddress(permanentAddress);
        customer.setCommunicationAddress(communicationAddress);
        customer.setNotes("Test Customer");
 
        return customer;
    }
 
    @Test
    void testSaveCustomer() {
 
        Customer customer = createCustomer();
 
        given(customerRepository.save(customer))
                .willReturn(customer);
 
        Customer savedCustomer = customerRepository.save(customer);
 
        assertNotNull(savedCustomer);
        assertNotNull(savedCustomer.getId());
 
        assertEquals("John", savedCustomer.getFirstName());
        assertEquals("Doe", savedCustomer.getLastName());
        assertEquals("JD", savedCustomer.getNickName());
        assertEquals('M', savedCustomer.getSex());
        assertEquals(25, savedCustomer.getAge());
        assertEquals("B.Tech", savedCustomer.getQualification());
        assertEquals("Test Customer", savedCustomer.getNotes());
 
        assertNotNull(savedCustomer.getPermanentAddress());
        assertEquals("10", savedCustomer.getPermanentAddress().getHouseNo());
        assertEquals("Main Street", savedCustomer.getPermanentAddress().getStreet());
        assertEquals("Near Park", savedCustomer.getPermanentAddress().getLandmark());
        assertEquals("Chennai", savedCustomer.getPermanentAddress().getCity());
        assertEquals("TN", savedCustomer.getPermanentAddress().getState());
        assertEquals("600001", savedCustomer.getPermanentAddress().getPin());
 
        assertNotNull(savedCustomer.getCommunicationAddress());
        assertEquals("20", savedCustomer.getCommunicationAddress().getHouseNo());
        assertEquals("Second Street", savedCustomer.getCommunicationAddress().getStreet());
        assertEquals("Near Mall", savedCustomer.getCommunicationAddress().getLandmark());
        assertEquals("Chennai", savedCustomer.getCommunicationAddress().getCity());
        assertEquals("TN", savedCustomer.getCommunicationAddress().getState());
        assertEquals("600002", savedCustomer.getCommunicationAddress().getPin());
    }
 
    @Test
    void testFindById() {
 
        Customer customer = createCustomer();
 
        given(customerRepository.findById(customer.getId()))
                .willReturn(Optional.of(customer));
 
        Optional<Customer> result =
                customerRepository.findById(customer.getId());
 
        assertTrue(result.isPresent());
 
        Customer foundCustomer = result.get();
 
        assertEquals("John", foundCustomer.getFirstName());
        assertEquals("Doe", foundCustomer.getLastName());
        assertEquals("JD", foundCustomer.getNickName());
        assertEquals('M', foundCustomer.getSex());
        assertEquals(25, foundCustomer.getAge());
        assertEquals("B.Tech", foundCustomer.getQualification());
        assertEquals("Test Customer", foundCustomer.getNotes());
 
        assertEquals("10",
                foundCustomer.getPermanentAddress().getHouseNo());
 
        assertEquals("20",
                foundCustomer.getCommunicationAddress().getHouseNo());
    }
 
    @Test
    void testFindAll() {
 
        Customer customer1 = createCustomer();
 
        Customer customer2 = createCustomer();
        customer2.setId(2L);
        customer2.setFirstName("Jane");
        customer2.setLastName("Smith");
        customer2.setNickName("Jan");
        customer2.setSex('F');
        customer2.setAge(28);
        customer2.setQualification("MCA");
        customer2.setNotes("Customer 2");
 
        Customer customer3 = createCustomer();
        customer3.setId(3L);
        customer3.setFirstName("Mike");
        customer3.setLastName("Brown");
        customer3.setNickName("Mikey");
        customer3.setSex('M');
        customer3.setAge(30);
        customer3.setQualification("MBA");
        customer3.setNotes("Customer 3");
 
        List<Customer> customers =
                List.of(customer1, customer2, customer3);
 
        given(customerRepository.findAll())
                .willReturn(customers);
 
        List<Customer> result = customerRepository.findAll();
 
        assertNotNull(result);
        assertEquals(3, result.size());
 
        Customer c1 = result.get(0);
 
        assertEquals("John", c1.getFirstName());
        assertEquals("Doe", c1.getLastName());
        assertEquals("JD", c1.getNickName());
        assertEquals('M', c1.getSex());
        assertEquals(25, c1.getAge());
        assertEquals("B.Tech", c1.getQualification());
        assertEquals("Test Customer", c1.getNotes());
 
        assertNotNull(c1.getPermanentAddress());
        assertEquals("10", c1.getPermanentAddress().getHouseNo());
        assertEquals("Main Street", c1.getPermanentAddress().getStreet());
        assertEquals("Near Park", c1.getPermanentAddress().getLandmark());
        assertEquals("Chennai", c1.getPermanentAddress().getCity());
        assertEquals("TN", c1.getPermanentAddress().getState());
        assertEquals("600001", c1.getPermanentAddress().getPin());
 
        assertNotNull(c1.getCommunicationAddress());
        assertEquals("20", c1.getCommunicationAddress().getHouseNo());
        assertEquals("Second Street", c1.getCommunicationAddress().getStreet());
        assertEquals("Near Mall", c1.getCommunicationAddress().getLandmark());
        assertEquals("Chennai", c1.getCommunicationAddress().getCity());
        assertEquals("TN", c1.getCommunicationAddress().getState());
        assertEquals("600002", c1.getCommunicationAddress().getPin());
    }
 
    @Test
    void testDeleteCustomer() {
 
        Long customerId = 1L;
 
        doNothing().when(customerRepository).deleteById(customerId);
 
        customerRepository.deleteById(customerId);
 
        given(customerRepository.findById(customerId))
                .willReturn(Optional.empty());
 
        Optional<Customer> result =
                customerRepository.findById(customerId);
 
        assertFalse(result.isPresent());
    }
 
    @Test
    void testUpdateCustomer() {
 
        Customer customer = createCustomer();
 
        customer.setFirstName("UpdatedName");
        customer.setLastName("UpdatedLastName");
        customer.setNickName("UpdatedNick");
        customer.setSex('F');
        customer.setAge(30);
        customer.setQualification("M.Tech");
        customer.setNotes("Updated Notes");
 
        Address permanentAddress =
                customer.getPermanentAddress();
 
        permanentAddress.setHouseNo("501");
        permanentAddress.setStreet("Updated Street");
        permanentAddress.setLandmark("Updated Landmark");
        permanentAddress.setCity("Bangalore");
        permanentAddress.setState("Karnataka");
        permanentAddress.setPin("560001");
 
        Address communicationAddress =
                customer.getCommunicationAddress();
 
        communicationAddress.setHouseNo("502");
        communicationAddress.setStreet("Comm Street");
        communicationAddress.setLandmark("Comm Landmark");
        communicationAddress.setCity("Hyderabad");
        communicationAddress.setState("Telangana");
        communicationAddress.setPin("500001");
 
        given(customerRepository.save(customer))
                .willReturn(customer);
 
        Customer updatedCustomer =
                customerRepository.save(customer);
 
        assertEquals("UpdatedName",
                updatedCustomer.getFirstName());
 
        assertEquals("UpdatedLastName",
                updatedCustomer.getLastName());
 
        assertEquals("UpdatedNick",
                updatedCustomer.getNickName());
 
        assertEquals('F',
                updatedCustomer.getSex());
 
        assertEquals(30,
                updatedCustomer.getAge());
 
        assertEquals("M.Tech",
                updatedCustomer.getQualification());
 
        assertEquals("Updated Notes",
                updatedCustomer.getNotes());
 
        assertEquals("501",
                updatedCustomer.getPermanentAddress().getHouseNo());
 
        assertEquals("Updated Street",
                updatedCustomer.getPermanentAddress().getStreet());
 
        assertEquals("502",
                updatedCustomer.getCommunicationAddress().getHouseNo());
 
        assertEquals("Comm Street",
                updatedCustomer.getCommunicationAddress().getStreet());
    }
}