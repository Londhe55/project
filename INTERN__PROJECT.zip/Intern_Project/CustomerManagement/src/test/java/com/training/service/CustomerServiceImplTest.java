package com.training.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.db.CustomerRepository;
import com.training.exception.CustomerListEmptyException;
import com.training.exception.CustomerNotFoundException;
import com.training.model.Address;
import com.training.model.Customer;

@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {

    @Mock
    private CustomerRepository repo;

    @InjectMocks
    private CustomerServiceImpl service;

    private Customer customer;

    @BeforeEach
    void setUp() {

        Address address = new Address();

        address.setHouseNo("123");
        address.setStreet("Main Street");
        address.setLandmark("Near Park");
        address.setCity("Chennai");
        address.setState("TN");
        address.setPin("600001");

        customer = new Customer();

        customer.setId(1L);
        customer.setFirstName("John");
        customer.setLastName("Doe");
        customer.setNickName("JD");
        customer.setSex('M');
        customer.setAge(25);
        customer.setQualification("MBA");
        customer.setPermanentAddress(address);
        customer.setCommunicationAddress(address);
        customer.setNotes("Test Customer");
    }

    @Test
    void testSaveCustomer() {

        given(repo.save(customer))
                .willReturn(customer);

        Customer savedCustomer =
                service.saveCustomer(customer);

        assertEquals(1L,
                savedCustomer.getId());

        assertEquals("John",
                savedCustomer.getFirstName());
    }

    @Test
    void testGetCustomerById() {

        given(repo.findById(1L))
                .willReturn(Optional.of(customer));

        Customer result =
                service.getCustomerById(1L);

        assertEquals(1L,
                result.getId());
    }

    @Test
    void testGetCustomerByIdNotFound() {

        given(repo.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                CustomerNotFoundException.class,
                () -> service.getCustomerById(1L));
    }

    @Test
    void testGetAllCustomers() {

        given(repo.findAll())
                .willReturn(
                        Collections.singletonList(customer));

        assertEquals(
                1,
                service.getAllCustomers().size());
    }

    @Test
    void testGetAllCustomersEmpty() {

        given(repo.findAll())
                .willReturn(Collections.emptyList());

        assertThrows(
                CustomerListEmptyException.class,
                () -> service.getAllCustomers());
    }

    @Test
    void testUpdateCustomer() {

        given(repo.findById(1L))
                .willReturn(Optional.of(customer));

        given(repo.save(customer))
                .willReturn(customer);

        Customer updatedCustomer =
                service.updateCustomer(
                        1L,
                        customer);

        assertEquals(
                "John",
                updatedCustomer.getFirstName());
    }

    @Test
    void testUpdateCustomerNotFound() {

        given(repo.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                CustomerNotFoundException.class,
                () -> service.updateCustomer(
                        1L,
                        customer));
    }

    @Test
    void testDeleteCustomer() {

        given(repo.findById(1L))
                .willReturn(Optional.of(customer));

        assertEquals(
                "Customer deleted successfully",
                service.deleteCustomer(1L));
    }

    @Test
    void testDeleteCustomerNotFound() {

        given(repo.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                CustomerNotFoundException.class,
                () -> service.deleteCustomer(1L));
    }
}