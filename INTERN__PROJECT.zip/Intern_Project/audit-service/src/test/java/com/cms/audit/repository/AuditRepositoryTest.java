package com.cms.audit.repository;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import com.cms.audit.model.AuditModel;

import java.util.List;
@DataJpaTest
class AuditRepositoryTest {

    @MockitoBean
    private AuditRepository auditRepository;

    private AuditModel createAudit() {

        AuditModel audit = new AuditModel();

        audit.setId(1L);
        audit.setCustomerId(101L);
        audit.setAction("CREATE");
        audit.setPerformedBy("admin");
        audit.setDetails("Customer Created");

        return audit;
    }

    @Test
    void testSaveAudit() {

        AuditModel audit = createAudit();

        given(auditRepository.save(audit))
                .willReturn(audit);

        AuditModel savedAudit =
                auditRepository.save(audit);

        assertNotNull(savedAudit);
        assertEquals(1L, savedAudit.getId());
        assertEquals(101L, savedAudit.getCustomerId());
        assertEquals("CREATE", savedAudit.getAction());
        assertEquals("admin", savedAudit.getPerformedBy());
        assertEquals("Customer Created",
                savedAudit.getDetails());
    }

    @Test
    void testFindById() {

        AuditModel audit = createAudit();

        given(auditRepository.findById(1L))
                .willReturn(Optional.of(audit));

        Optional<AuditModel> result =
                auditRepository.findById(1L);

        assertTrue(result.isPresent());

        AuditModel foundAudit = result.get();

        assertEquals(101L,
                foundAudit.getCustomerId());
        assertEquals("CREATE",
                foundAudit.getAction());
        assertEquals("admin",
                foundAudit.getPerformedBy());
    }

    @Test
    void testFindAll() {

        AuditModel audit1 = createAudit();

        AuditModel audit2 = new AuditModel();
        audit2.setId(2L);
        audit2.setCustomerId(102L);
        audit2.setAction("UPDATE");
        audit2.setPerformedBy("user");
        audit2.setDetails("Customer Updated");

        List<AuditModel> audits =
                List.of(audit1, audit2);

        given(auditRepository.findAll())
                .willReturn(audits);

        List<AuditModel> result =
                auditRepository.findAll();

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    void testExistsById() {

        given(auditRepository.existsById(1L))
                .willReturn(true);

        boolean exists =
                auditRepository.existsById(1L);

        assertTrue(exists);
    }

    @Test
    void testDeleteById() {

        doNothing()
                .when(auditRepository)
                .deleteById(1L);

        auditRepository.deleteById(1L);

        given(auditRepository.findById(1L))
                .willReturn(Optional.empty());

        Optional<AuditModel> result =
                auditRepository.findById(1L);

        assertFalse(result.isPresent());
    }

    @Test
    void testUpdateAudit() {

        AuditModel audit = createAudit();

        audit.setAction("UPDATE");
        audit.setPerformedBy("superadmin");
        audit.setDetails("Customer Updated");

        given(auditRepository.save(audit))
                .willReturn(audit);

        AuditModel updatedAudit =
                auditRepository.save(audit);

        assertEquals("UPDATE",
                updatedAudit.getAction());

        assertEquals("superadmin",
                updatedAudit.getPerformedBy());

        assertEquals("Customer Updated",
                updatedAudit.getDetails());
    }
}	