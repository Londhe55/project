package com.cms.audit.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.BDDMockito.given;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cms.audit.exception.NoAuditLogsFoundException;
import com.cms.audit.exception.ResourceNotFoundException;
import com.cms.audit.model.AuditModel;
import com.cms.audit.repository.AuditRepository;
import com.cms.audit.service.impl.AuditServiceImpl;

@ExtendWith(MockitoExtension.class)
class AuditServiceTest {

    @Mock
    private AuditRepository repository;

    @InjectMocks
    private AuditServiceImpl service;

    @Test
    void testFindAudit() {

        AuditModel audit = new AuditModel();

        audit.setId(1L);

        given(repository.findById(1L))
                .willReturn(Optional.of(audit));

        assertEquals(
                1L,
                service.findAudit(1L).getId());
    }

    @Test
    void testAuditNotFound() {

        given(repository.findById(1L))
                .willReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.findAudit(1L));
    }

    @Test
    void testSaveAudit() {

        AuditModel audit = new AuditModel();

        audit.setId(1L);
        audit.setCustomerId(1L);
        audit.setAction("CREATE");
        audit.setPerformedBy("admin");

        given(repository.save(audit))
                .willReturn(audit);

        assertEquals(
                1L,
                service.saveAudit(audit).getId());
    }

    @Test
    void testFetchAllAuditsNotFound() {

        given(repository.findAll())
                .willReturn(Collections.emptyList());

        assertThrows(
                NoAuditLogsFoundException.class,
                () -> service.fetchAllAudits());
    }

    @Test
    void testDeleteAudit() {

        given(repository.existsById(1L))
                .willReturn(true);

        assertEquals(
                "Successfully Deleted",
                service.deleteAudit(1L));
    }

    @Test
    void testDeleteAuditNotFound() {

        given(repository.existsById(1L))
                .willReturn(false);

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.deleteAudit(1L));
    }
}