package com.cms.audit.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.cms.audit.model.AuditModel;
import com.cms.audit.service.AuditService;

@WebMvcTest(AuditController.class)
class AuditControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private AuditService auditService;

    @Test
    void testFindAudit() throws Exception {

        AuditModel audit = new AuditModel();

        audit.setId(1L);
        audit.setCustomerId(101L);
        audit.setAction("CREATE");
        audit.setPerformedBy("admin");
        audit.setDetails("Customer Created");

        when(auditService.findAudit(1L))
                .thenReturn(audit);

        mockMvc.perform(get("/audit/findAudit/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(200))
                .andExpect(jsonPath("$.message")
                        .value("Audit Log Retrieved Successfully"))
                .andExpect(jsonPath("$.audit.id")
                        .value(1))
                .andExpect(jsonPath("$.audit.customerId")
                        .value(101))
                .andExpect(jsonPath("$.audit.action")
                        .value("CREATE"))
                .andExpect(jsonPath("$.audit.performedBy")
                        .value("admin"))
                .andExpect(jsonPath("$.audit.details")
                        .value("Customer Created"));
    }

    @Test
    void testFetchAllAudits() throws Exception {

        when(auditService.fetchAllAudits())
                .thenReturn(new ArrayList<>());

        mockMvc.perform(get("/audit/fetchAll"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(200));
    }

    @Test
    void testDeleteAudit() throws Exception {

        when(auditService.deleteAudit(1L))
                .thenReturn("Successfully Deleted");

        mockMvc.perform(delete("/audit/deleteAudit/1"))
                .andExpect(status().isOk())
                .andExpect(content()
                        .string("Successfully Deleted"));
    }

    @Test
    void testSaveAudit() throws Exception {

        AuditModel audit = new AuditModel();

        audit.setId(1L);
        audit.setCustomerId(101L);
        audit.setAction("CREATE");
        audit.setPerformedBy("admin");
        audit.setDetails("Customer Created");

        when(auditService.saveAudit(any()))
                .thenReturn(audit);

        String json = """
        {
          "audit": {
            "customerId": 101,
            "action": "CREATE",
            "performedBy": "admin",
            "details": "Customer Created"
          }
        }
        """;

        mockMvc.perform(post("/audit/saveAudit")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.httpStatusCode")
                        .value(201))
                .andExpect(jsonPath("$.message")
                        .value("Audit Log Created Successfully"))
                .andExpect(jsonPath("$.audit.id")
                        .value(1))
                .andExpect(jsonPath("$.audit.customerId")
                        .value(101))
                .andExpect(jsonPath("$.audit.action")
                        .value("CREATE"))
                .andExpect(jsonPath("$.audit.performedBy")
                        .value("admin"))
                .andExpect(jsonPath("$.audit.details")
                        .value("Customer Created"));
    }
}