package com.cms.audit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cms.audit.model.AuditModel;

@Repository
public interface AuditRepository extends JpaRepository<AuditModel, Long> {

}