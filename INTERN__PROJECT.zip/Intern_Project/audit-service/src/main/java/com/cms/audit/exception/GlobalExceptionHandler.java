package com.cms.audit.exception;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleResourceNotFound(
            ResourceNotFoundException ex) {

        Map<String, Object> body = new LinkedHashMap<>();

        body.put("httpStatusCode", HttpStatus.NOT_FOUND.value());
        body.put("message", ex.getMessage());

        return new ResponseEntity<>(
                body,
                HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(
            MethodArgumentNotValidException ex) {

        Map<String, Object> body = new HashMap<>();

        body.put("httpStatusCode", HttpStatus.BAD_REQUEST.value());

        Map<String, String> errors = new HashMap<>();

        ex.getBindingResult()
                .getFieldErrors()
                .forEach(error ->
                        errors.put(
                                error.getField(),
                                error.getDefaultMessage()));

        body.put("validationErrors", errors);

        return new ResponseEntity<>(
                body,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(
            Exception ex) {

        Map<String, Object> body = new LinkedHashMap<>();

        body.put(
                "httpStatusCode",
                HttpStatus.INTERNAL_SERVER_ERROR.value());

        body.put("message", ex.getMessage());

        return new ResponseEntity<>(
                body,
                HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(NoAuditLogsFoundException.class)
    public ResponseEntity<Map<String, Object>>
            handleNoAuditLogsFound(
                    NoAuditLogsFoundException ex) {

        Map<String, Object> body =
                new LinkedHashMap<>();

        body.put(
                "httpStatusCode",
                HttpStatus.NOT_FOUND.value());

        body.put(
                "message",
                ex.getMessage());

        return new ResponseEntity<>(
                body,
                HttpStatus.NOT_FOUND);
    }
}