package com.cms.audit.dto;

import java.util.List;
import com.cms.audit.model.AuditModel;

public class AuditListResponseDTO {

    private List<AuditModel> audits;
    private int httpStatusCode;
    private String message;

    public List<AuditModel> getAudits() {
        return audits;
    }

    public void setAudits(List<AuditModel> audits) {
        this.audits = audits;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}