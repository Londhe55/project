package com.cms.audit.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.audit.exception.NoAuditLogsFoundException;
import com.cms.audit.exception.ResourceNotFoundException;
import com.cms.audit.model.AuditModel;
import com.cms.audit.repository.AuditRepository;
import com.cms.audit.service.AuditService;

@Service
public class AuditServiceImpl implements AuditService {

    @Autowired
    private AuditRepository repository;

    @Override
    public AuditModel saveAudit(AuditModel audit) {

        return repository.save(audit);
    }

    @Override
    public AuditModel findAudit(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Audit Log Not Found with ID : " + id));
    }

    @Override
    public List<AuditModel> fetchAllAudits() {

        List<AuditModel> audits = repository.findAll();

        if (audits.isEmpty()) {

            throw new NoAuditLogsFoundException(
                    "No Audit Logs Available");
        }

        return audits;
    }

    @Override
    public AuditModel updateAudit(AuditModel audit) {

        AuditModel existingAudit =
                repository.findById(audit.getId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Audit Log Not Found with ID : "
                                        + audit.getId()));

        existingAudit.setCustomerId(
                audit.getCustomerId());

        existingAudit.setAction(
                audit.getAction());

        existingAudit.setPerformedBy(
                audit.getPerformedBy());

        existingAudit.setDetails(
                audit.getDetails());

        return repository.save(existingAudit);
    }

    @Override
    public String deleteAudit(Long id) {

        if (repository.existsById(id)) {

            repository.deleteById(id);

            return "Successfully Deleted";
        }

        throw new ResourceNotFoundException(
                "Audit Log Not Found with ID : " + id);
    }
}