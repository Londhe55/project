package com.cms.audit.exception;

public class NoAuditLogsFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public NoAuditLogsFoundException(String message) {
        super(message);
    }
}