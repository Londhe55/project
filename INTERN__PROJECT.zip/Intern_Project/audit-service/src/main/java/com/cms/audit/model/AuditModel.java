package com.cms.audit.model;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "audit_logs")
public class AuditModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Customer Id is required")
    @Column(name = "customer_id", nullable = false)
    private Long customerId;

    @NotBlank(message = "Action is required")
    @Size(max = 50)
    @Column(nullable = false, length = 50)
    private String action;

    @Column(nullable = false)
    private LocalDateTime timestamp;

    @NotBlank(message = "Performed By is required")
    @Size(max = 100)
    @Column(name = "performed_by", nullable = false, length = 100)
    private String performedBy;

    @Size(max = 1000, message = "Details should not exceed 1000 characters")
    @Column(columnDefinition = "TEXT")
    private String details;

    public AuditModel() {
    }
    
    

    public AuditModel(Long id, @NotNull(message = "Customer Id is required") Long customerId,
			@NotBlank(message = "Action is required") @Size(max = 50) String action, LocalDateTime timestamp,
			@NotBlank(message = "Performed By is required") @Size(max = 100) String performedBy,
			@Size(max = 1000, message = "Details should not exceed 1000 characters") String details) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.action = action;
		this.timestamp = timestamp;
		this.performedBy = performedBy;
		this.details = details;
	}



	@PrePersist
    public void prePersist() {
        this.timestamp = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}