package com.cms.audit.service;

import java.util.List;

import com.cms.audit.model.AuditModel;

public interface AuditService {

    AuditModel saveAudit(AuditModel audit);

    AuditModel findAudit(Long id);

    List<AuditModel> fetchAllAudits();

    AuditModel updateAudit(AuditModel audit);

    String deleteAudit(Long id);

}