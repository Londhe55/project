package com.cms.audit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.audit.dto.AuditListResponseDTO;
import com.cms.audit.dto.AuditRequestDTO;
import com.cms.audit.dto.AuditResponseDTO;
import com.cms.audit.model.AuditModel;
import com.cms.audit.service.AuditService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/audit")
@Validated
@Tag(name = "Audit Service API")
public class AuditController {

	@Autowired
	private AuditService service;

	@Operation(summary = "Create Audit Log")
	@PostMapping("/saveAudit")
	public ResponseEntity<AuditResponseDTO> createAudit(@Valid @RequestBody AuditRequestDTO dto) {

		AuditModel audit = new AuditModel();

		audit.setCustomerId(dto.getCustomerId());

		audit.setAction(dto.getAction());

		audit.setPerformedBy(dto.getPerformedBy());

		audit.setDetails(dto.getDetails());

		AuditModel savedAudit = service.saveAudit(audit);

		AuditResponseDTO response = new AuditResponseDTO();

		response.setAudit(savedAudit);
		response.setHttpStatusCode(201);
		response.setMessage("Audit Log Created Successfully");

		response.setSuccess(true);

		return ResponseEntity.status(201).body(response);
	}

	@Operation(summary = "Fetch All Audit Logs")
	@GetMapping("/fetchAll")
	public ResponseEntity<AuditListResponseDTO> fetchAllAudits() {

		List<AuditModel> audits = service.fetchAllAudits();

		AuditListResponseDTO response = new AuditListResponseDTO();

		response.setAudits(audits);
		response.setHttpStatusCode(200);
		response.setMessage(audits.size() + " Audit Logs Fetched Successfully");

		return ResponseEntity.ok(response);
	}

	@Operation(summary = "Find Audit Log By Id")
	@GetMapping("/findAudit/{id}")
	public ResponseEntity<AuditResponseDTO> findAudit(@PathVariable Long id) {

		AuditModel audit = service.findAudit(id);

		AuditResponseDTO response = new AuditResponseDTO();

		response.setAudit(audit);
		response.setHttpStatusCode(200);
		response.setMessage("Audit Log Retrieved Successfully");

		response.setSuccess(true);

		return ResponseEntity.ok(response);
	}

	@Operation(summary = "Update Audit Log")
	@PostMapping("/updateAudit")
	public ResponseEntity<AuditResponseDTO> updateAudit(@Valid @RequestBody AuditRequestDTO dto) {

		AuditModel audit = new AuditModel();

		audit.setId(dto.getId());

		audit.setCustomerId(dto.getCustomerId());

		audit.setAction(dto.getAction());

		audit.setPerformedBy(dto.getPerformedBy());

		audit.setDetails(dto.getDetails());

		AuditModel updatedAudit = service.updateAudit(audit);

		AuditResponseDTO response = new AuditResponseDTO();

		response.setAudit(updatedAudit);
		response.setHttpStatusCode(200);
		response.setMessage("Audit Log Updated Successfully");

		response.setSuccess(true);

		return ResponseEntity.ok(response);
	}

	@Operation(summary = "Delete Audit Log")
	@DeleteMapping("/deleteAudit/{id}")
	public ResponseEntity<String> deleteAudit(@PathVariable Long id) {

		String response = service.deleteAudit(id);

		return ResponseEntity.ok(response);
	}
}