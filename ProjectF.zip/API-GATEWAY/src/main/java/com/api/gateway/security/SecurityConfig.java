package com.api.gateway.security;

import org.springframework.security.core.userdetails.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

	@Bean
	public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {

		return http.csrf(ServerHttpSecurity.CsrfSpec::disable)

				.authorizeExchange(exchanges -> exchanges

						
						.pathMatchers("/swagger-ui/**", 
										"/v3/api-docs/**", 
										"/companies/v3/api-docs",
										"/assets/v3/api-docs", 
										"/settlements/v3/api-docs", 
										"/api/traders/v3/api-docs",
										"/tradeordersapi/tradeorders/v3/api-docs",
										"/actuator/**")
						.permitAll()

						
						.pathMatchers(HttpMethod.GET, "/**").hasAnyRole("USER", "ADMIN")

						
						.pathMatchers(HttpMethod.POST, "/**").hasRole("ADMIN")

						
						.pathMatchers(HttpMethod.PUT, "/**").hasRole("ADMIN")

						
						.pathMatchers(HttpMethod.DELETE, "/**").hasRole("ADMIN")

						.anyExchange().authenticated())

				.httpBasic(Customizer.withDefaults()).build();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}

	@Bean
	public MapReactiveUserDetailsService users(PasswordEncoder passwordEncoder) {

	    UserDetails admin = User.builder()
	            .username("admin")
	            .password(passwordEncoder.encode("admin123"))
	            .roles("ADMIN")
	            .build();

	    UserDetails user = User.builder()
	            .username("user")
	            .password(passwordEncoder.encode("user123"))
	            .roles("USER")
	            .build();

	    return new MapReactiveUserDetailsService(admin, user);
	}
}