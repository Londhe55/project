package com.trade.order.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trade.order.dto.TradeOrderRequestDTO;
import com.trade.order.dto.TradeOrderResponseDTO;
import com.trade.order.service.TradeOrderService;

@WebMvcTest(TradeOrderController.class)
public class TradeOrderControllerTest {

	@Autowired
	MockMvc mockMvc;

	@MockitoBean
	TradeOrderService service;

	@Autowired
	ObjectMapper objectMapper;

	
	
	@Test
	void createTradeOrder() throws Exception {

		TradeOrderResponseDTO responseDTO = new TradeOrderResponseDTO();
		
		responseDTO.setId(1L);
		responseDTO.setTraderId(2L);
		responseDTO.setAssetId(3L);
		responseDTO.setOrderType("Buy");

		when(service.addTradeOrder(any())).thenReturn(responseDTO);
		
		TradeOrderRequestDTO requestDTO = new TradeOrderRequestDTO();
		
		
		requestDTO.setAssetId(2L);
		requestDTO.setTraderId(3L);
		requestDTO.setOrderType("Sell");
		requestDTO.setPrice(BigDecimal.valueOf(500));
		requestDTO.setQuantity(BigDecimal.valueOf(10));
		requestDTO.setStatus("Pending");
		

		String json = objectMapper.writeValueAsString(requestDTO);
		
		mockMvc.perform(post("/tradeordersapi/tradeorder")
				.contentType(MediaType.APPLICATION_JSON).
				content(json))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.id").value(1))
				.andExpect(jsonPath("$.traderId").value(2))
				.andExpect(jsonPath("$.assetId").value(3))
				.andExpect(jsonPath("$.orderType").value("Buy"));

		verify(service).addTradeOrder(any());
	}

	
	

	@Test
	void getTradeOrderById() throws Exception {

		TradeOrderResponseDTO responseDTO = new TradeOrderResponseDTO();
		
		responseDTO.setId(1L);
		responseDTO.setTraderId(2L);
		responseDTO.setAssetId(3L);
		responseDTO.setOrderType("Buy");
		
		

		when(service.getTradeOrderById(1L)).thenReturn(responseDTO);

		mockMvc.perform(get("/tradeordersapi/tradeorder/1"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id").value(1))
				.andExpect(jsonPath("$.traderId").value(2))
				.andExpect(jsonPath("$.assetId").value(3))
				.andExpect(jsonPath("$.orderType").value("Buy"));

		verify(service).getTradeOrderById(1L);
	}

	
	
	
	
	@Test
	void getTradeOrderAll() throws Exception {

		TradeOrderResponseDTO responseDTO = new TradeOrderResponseDTO();
		
		responseDTO.setId(1L);
		responseDTO.setTraderId(2L);
		responseDTO.setAssetId(3L);
		responseDTO.setOrderType("Buy");
		
		TradeOrderResponseDTO responseDTO2 = new TradeOrderResponseDTO();
		
		responseDTO2.setId(4L);
		responseDTO2.setTraderId(5L);
		responseDTO2.setAssetId(6L);
		responseDTO2.setOrderType("Buy");
		
		
		when(service.getTradeOrders()).thenReturn(List.of(responseDTO, responseDTO2));

		mockMvc.perform(get("/tradeordersapi/tradeorders"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id").value(1))
				.andExpect(jsonPath("$[0].traderId").value(2))
				.andExpect(jsonPath("$[0].assetId").value(3))
				
				.andExpect(jsonPath("$[1].id").value(4))
				.andExpect(jsonPath("$[1].traderId").value(5))
				.andExpect(jsonPath("$[1].assetId").value(6));

		verify(service).getTradeOrders();
	}

	
	
	
	@Test
	void updateTradeOrder() throws Exception {

		TradeOrderResponseDTO responseDTO = new TradeOrderResponseDTO();
		
		responseDTO.setId(1L);
		responseDTO.setTraderId(2L);
		responseDTO.setAssetId(3L);
		responseDTO.setOrderType("Sell");
		responseDTO.setPrice(BigDecimal.valueOf(4000));

		when(service.updateTradeOrder(eq(1L), any())).thenReturn(responseDTO);

		TradeOrderRequestDTO requestDTO = new TradeOrderRequestDTO();

		requestDTO.setAssetId(1L);
		requestDTO.setAssetId(2L);
		requestDTO.setTraderId(3L);
		requestDTO.setOrderType("Buy");
		requestDTO.setPrice(BigDecimal.valueOf(500));
		requestDTO.setQuantity(BigDecimal.valueOf(10));
		requestDTO.setStatus("Pending");

		String json = objectMapper.writeValueAsString(requestDTO);
		
		mockMvc.perform(put("/tradeordersapi/tradeorder/1")
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id").value(1))
				.andExpect(jsonPath("$.traderId").value(2))
				.andExpect(jsonPath("$.assetId").value(3))
				.andExpect(jsonPath("$.orderType").value("Sell"));

		verify(service).updateTradeOrder(eq(1L), any());
	}
	
	


	

	@Test
	void deleteTradeOrder() throws Exception {

		when(service.deleteTradeOrder(1L)).thenReturn("Trade Order Deleted Successfully");

		mockMvc.perform(delete("/tradeordersapi/tradeorder/1"))
				.andExpect(status().isOk());

		verify(service).deleteTradeOrder(1L);
	}

}
