package com.trade.order.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.trade.order.dto.TradeOrderRequestDTO;
import com.trade.order.dto.TradeOrderResponseDTO;
import com.trade.order.entity.TradeOrder;
import com.trade.order.exception.AssetNotFoundException;
import com.trade.order.exception.TradeOrderListNotFoundException;
import com.trade.order.exception.TradeOrderNotFoundException;
import com.trade.order.exception.TraderNotFoundException;
import com.trade.order.feign.AssetClient;
import com.trade.order.feign.TraderClient;
import com.trade.order.mapper.TradeOrderMapper;
import com.trade.order.repo.TradeOrderRepository;

@ExtendWith(MockitoExtension.class)
public class TradeOrderServiceTest {

	@InjectMocks
	TradeOrderService tradeOrderService;

	@Mock
	TradeOrderRepository tradeOrderRepository;

	@Mock
	TraderClient traderClient;

	@Mock
	AssetClient assetClient;

	@Mock
	TradeOrderMapper tradeOrderMapper;

//	Get All Trade Orders
	@Test
	void testGetTradeOrders() {

		TradeOrder order = new TradeOrder();

		TradeOrderResponseDTO response = new TradeOrderResponseDTO();

		when(tradeOrderRepository.findAll()).thenReturn(List.of(order));

		when(tradeOrderMapper.toResponse(order)).thenReturn(response);

		List<TradeOrderResponseDTO> result = tradeOrderService.getTradeOrders();

		assertEquals(1, result.size());
	}

//    Get All Trade Orders Empty
	@Test
	void testGetTradeOrdersEmpty() {

		when(tradeOrderRepository.findAll()).thenReturn(List.of());

		assertThrows(TradeOrderListNotFoundException.class, () -> tradeOrderService.getTradeOrders());
	}

//    Add Trade Order
	@Test
	void testAddTradeOrder() {

		TradeOrderRequestDTO request = new TradeOrderRequestDTO();

		request.setTraderId(1L);
		request.setAssetId(1L);

		TradeOrder order = new TradeOrder();

		TradeOrder savedOrder = new TradeOrder();

		TradeOrderResponseDTO response = new TradeOrderResponseDTO();

		when(tradeOrderMapper.toEntity(request)).thenReturn(order);

		when(tradeOrderRepository.save(order)).thenReturn(savedOrder);

		when(tradeOrderMapper.toResponse(savedOrder)).thenReturn(response);

		TradeOrderResponseDTO result = tradeOrderService.addTradeOrder(request);

		assertNotNull(result);

		verify(tradeOrderRepository).save(order);
	}

//    Trader Not Found
	@Test
	void testAddTradeOrderTraderNotFound() {

		TradeOrderRequestDTO request = new TradeOrderRequestDTO();

		request.setTraderId(1L);

		when(traderClient.getTraderById(1L)).thenThrow(new RuntimeException());

		assertThrows(TraderNotFoundException.class, () -> tradeOrderService.addTradeOrder(request));
	}

//    Asset Not Found
	@Test
	void testAddTradeOrderAssetNotFound() {

		TradeOrderRequestDTO request = new TradeOrderRequestDTO();

		request.setTraderId(1L);
		request.setAssetId(1L);

		when(traderClient.getTraderById(1L)).thenReturn(null);

		when(assetClient.getAssetById(1L)).thenThrow(new RuntimeException());

		assertThrows(AssetNotFoundException.class, () -> tradeOrderService.addTradeOrder(request));
	}

//    Get Trade Order By Id
	@Test
	void testGetTradeOrderById() {

		TradeOrder order = new TradeOrder();

		TradeOrderResponseDTO response = new TradeOrderResponseDTO();

		when(tradeOrderRepository.findById(1L)).thenReturn(Optional.of(order));

		when(tradeOrderMapper.toResponse(order)).thenReturn(response);

		TradeOrderResponseDTO result = tradeOrderService.getTradeOrderById(1L);

		assertNotNull(result);
	}

//    Get Trade Order By Id Not Found

	@Test
	void testGetTradeOrderByIdNotFound() {

		when(tradeOrderRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(TradeOrderNotFoundException.class, () -> tradeOrderService.getTradeOrderById(1L));
	}

//    Update Trade Order
	@Test
	void testUpdateTradeOrder() {

		TradeOrder order = new TradeOrder();

		TradeOrderRequestDTO request = new TradeOrderRequestDTO();

		request.setTraderId(1L);
		request.setAssetId(1L);

		TradeOrderResponseDTO response = new TradeOrderResponseDTO();

		when(tradeOrderRepository.findById(1L)).thenReturn(Optional.of(order));

		when(tradeOrderRepository.save(order)).thenReturn(order);

		when(tradeOrderMapper.toResponse(order)).thenReturn(response);

		TradeOrderResponseDTO result = tradeOrderService.updateTradeOrder(1L, request);

		assertNotNull(result);

		verify(tradeOrderRepository).save(order);
	}

//    Update Trade Order Not Found
	@Test
	void testUpdateTradeOrderNotFound() {

		TradeOrderRequestDTO request = new TradeOrderRequestDTO();

		when(tradeOrderRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(TradeOrderNotFoundException.class, () -> tradeOrderService.updateTradeOrder(1L, request));
	}

//    Delete Trade Order
	@Test
	void testDeleteTradeOrder() {

		TradeOrder order = new TradeOrder();

		when(tradeOrderRepository.findById(1L)).thenReturn(Optional.of(order));

		String result = tradeOrderService.deleteTradeOrder(1L);

		assertEquals("Trade Order Deleted Successfully", result);

		verify(tradeOrderRepository).delete(order);
	}

//    Delete Trade Order Not Found
	@Test
	void testDeleteTradeOrderNotFound() {

		when(tradeOrderRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(TradeOrderNotFoundException.class, () -> tradeOrderService.deleteTradeOrder(1L));
	}
}
