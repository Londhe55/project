package com.trade.order.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.mysql.cj.x.protobuf.MysqlxCrud.Order;
import com.trade.order.entity.TradeOrder;
import com.trade.order.repo.TradeOrderRepository;



@DataJpaTest
public class TradeOrderRepositoryTest {
	
	
	@Autowired
	private TradeOrderRepository repository;
	
	
//	Test case for to save Trade Order
	@Test
	void testSaveTradeOrder() {
		
		TradeOrder order = new TradeOrder();
		
		order.setTraderId(215L);
		order.setAssetId(21L);
		order.setOrderType("BUY");
		order.setQuantity(BigDecimal.valueOf(500));
		order.setPrice(BigDecimal.valueOf(250.78));
		order.setStatus("Open");
		
		TradeOrder saveTradeOrder = repository.save(order);
		
		assertNotNull(saveTradeOrder);
		assertNotNull(saveTradeOrder.getId());
		
		
	}
	
	
	// test Case for the Find trade Order
	@Test
	void testFindTradeOrderById() {
		
		TradeOrder tradeOrder = new TradeOrder();
		
		tradeOrder.setTraderId(215L);
		tradeOrder.setAssetId(21L);
		tradeOrder.setOrderType("BUY");
		tradeOrder.setQuantity(BigDecimal.valueOf(500));
		tradeOrder.setPrice(BigDecimal.valueOf(250.78));
		tradeOrder.setStatus("Open");
		
		TradeOrder savTradeOrder = repository.save(tradeOrder);
		
		Optional<TradeOrder> result = repository.findById(tradeOrder.getId());
		
		assertTrue(result.isPresent());
		assertEquals(result.get().getId(), tradeOrder.getId());
	}
	
	//Test case for the Find All the Trdae Order 
	@Test
	void testFindAllTradeOrder() {
		
		TradeOrder tradeOrder = new TradeOrder();
		
		tradeOrder.setTraderId(215L);
		tradeOrder.setAssetId(21L);
		tradeOrder.setOrderType("BUY");
		tradeOrder.setQuantity(BigDecimal.valueOf(500));
		tradeOrder.setPrice(BigDecimal.valueOf(250.78));
		tradeOrder.setStatus("Open");
		
		TradeOrder tradeOrder2 = new TradeOrder();
		
		tradeOrder2.setTraderId(21L);
		tradeOrder2.setAssetId(1L);
		tradeOrder2.setOrderType("Sell");
		tradeOrder2.setQuantity(BigDecimal.valueOf(500));
		tradeOrder2.setPrice(BigDecimal.valueOf(250.78));
		tradeOrder2.setStatus("Close");
		
		TradeOrder savedTradeOrder = repository.save(tradeOrder);
		TradeOrder savedTradeOrder2 = repository.save(tradeOrder2);
		
		List<TradeOrder> result = repository.findAll();
		
		assertFalse(result.isEmpty());
		assertEquals(2, result.size());
		
	}
	
	

//  Test Case For the Updtae the Trader	
	@Test
	void testUpdateTradeOrderById() {
		
		TradeOrder tradeOrder = new TradeOrder();
		
		tradeOrder.setTraderId(215L);
		tradeOrder.setAssetId(21L);
		tradeOrder.setOrderType("BUY");
		tradeOrder.setQuantity(BigDecimal.valueOf(500));
		tradeOrder.setPrice(BigDecimal.valueOf(250.78));
		tradeOrder.setStatus("Open");
		
		TradeOrder savedOrder = repository.save(tradeOrder);
		
		tradeOrder.setStatus("Close");
		tradeOrder.setOrderType("Sell");
		
		TradeOrder savedTradeOrder = repository.save(tradeOrder);
		
		assertEquals("Sell", tradeOrder.getOrderType());
		assertEquals("Close", tradeOrder.getStatus());
	}
	
	
//	Test Case for delete The Trader
	@Test
	void testDeleteTradeOrderById() {
		
		TradeOrder tradeOrder = new TradeOrder();
		tradeOrder.setTraderId(215L);
		tradeOrder.setAssetId(21L);
		tradeOrder.setOrderType("BUY");
		tradeOrder.setQuantity(BigDecimal.valueOf(500));
		tradeOrder.setPrice(BigDecimal.valueOf(250.78));
		tradeOrder.setStatus("Open");
		
		TradeOrder savedTradeOrder = repository.save(tradeOrder);
		
		repository.deleteById(savedTradeOrder.getId());
		
		Optional<TradeOrder> result = repository.findById(savedTradeOrder.getId());
		
		assertFalse(result.isPresent());
	}
	

}
