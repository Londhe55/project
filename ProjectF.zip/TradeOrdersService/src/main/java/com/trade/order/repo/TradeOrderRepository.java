package com.trade.order.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trade.order.entity.TradeOrder;

@Repository
public interface TradeOrderRepository extends JpaRepository<TradeOrder, Long> {

}
