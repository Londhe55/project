package com.trade.order.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AssetDTO {

    private Long id;

    private String name;

    private String symbol;

    private String type;

    private BigDecimal currentPrice;

    private LocalDate listedSince;

    public AssetDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(BigDecimal currentPrice) {
        this.currentPrice = currentPrice;
    }

    public LocalDate getListedSince() {
        return listedSince;
    }

    public void setListedSince(LocalDate listedSince) {
        this.listedSince = listedSince;
    }

	public AssetDTO(Long id, String name, String symbol, String type, BigDecimal currentPrice, LocalDate listedSince) {
		super();
		this.id = id;
		this.name = name;
		this.symbol = symbol;
		this.type = type;
		this.currentPrice = currentPrice;
		this.listedSince = listedSince;
	}
    
    
}