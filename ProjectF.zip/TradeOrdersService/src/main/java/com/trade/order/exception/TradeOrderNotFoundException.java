package com.trade.order.exception;

public class TradeOrderNotFoundException extends RuntimeException {

	public TradeOrderNotFoundException(String message) {
		super(message);
	}
}
