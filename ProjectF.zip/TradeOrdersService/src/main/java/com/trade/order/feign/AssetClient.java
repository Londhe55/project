package com.trade.order.feign;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.trade.order.dto.AssetDTO;

@FeignClient(name = "ASSET")
public interface AssetClient {

    @GetMapping("/assets/{id}")
    AssetDTO getAssetById(@PathVariable("id") Long id);

}