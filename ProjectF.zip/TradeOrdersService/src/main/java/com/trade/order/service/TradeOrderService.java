package com.trade.order.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trade.order.dto.TradeOrderRequestDTO;
import com.trade.order.dto.TradeOrderResponseDTO;
import com.trade.order.entity.TradeOrder;
import com.trade.order.exception.AssetNotFoundException;
import com.trade.order.exception.TradeOrderListNotFoundException;
import com.trade.order.exception.TradeOrderNotFoundException;
import com.trade.order.exception.TraderNotFoundException;
import com.trade.order.feign.AssetClient;
import com.trade.order.feign.TraderClient;
import com.trade.order.mapper.TradeOrderMapper;
import com.trade.order.repo.TradeOrderRepository;

@Service
public class TradeOrderService {

    @Autowired
    private TradeOrderRepository repo;

    @Autowired
    private TraderClient traderClient;

    @Autowired
    private AssetClient assetClient;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    
    public List<TradeOrderResponseDTO> getTradeOrders() {

        List<TradeOrder> orders = repo.findAll();

        if (orders.isEmpty()) {
            throw new TradeOrderListNotFoundException("No Trade Orders Found");
        }

        return orders.stream()
        			.map(tradeOrderMapper::toResponse)
        			.collect(Collectors.toList());
    }
    
    

    public TradeOrderResponseDTO addTradeOrder(TradeOrderRequestDTO request) {

        try {
            traderClient.getTraderById(request.getTraderId());
            
        } catch (Exception e) {
            throw new TraderNotFoundException("Trader not found with id : "+ request.getTraderId());
        }

        try {
            assetClient.getAssetById(request.getAssetId());
            
        } catch (Exception e) {
            throw new AssetNotFoundException("Asset not found with id : " + request.getAssetId());
        }

        TradeOrder order = tradeOrderMapper.toEntity(request);

        order.setCreatedAt(LocalDateTime.now());

        TradeOrder savedOrder = repo.save(order);

        return tradeOrderMapper.toResponse(savedOrder);
    }

    
    public TradeOrderResponseDTO getTradeOrderById(Long id) {

        TradeOrder order = repo.findById(id).orElseThrow(() ->
                        		new TradeOrderNotFoundException("Trade Order Not Found With Id : "+ id));

        return tradeOrderMapper.toResponse(order);
    }

    
    
    public TradeOrderResponseDTO updateTradeOrder(Long id, TradeOrderRequestDTO request) {

        TradeOrder order = repo.findById(id).orElseThrow(() ->
                        		new TradeOrderNotFoundException("Trade Order Not Found With Id : "+ id));

        order.setTraderId(request.getTraderId());
        order.setAssetId(request.getAssetId());
        order.setOrderType(request.getOrderType());
        order.setQuantity(request.getQuantity());
        order.setPrice(request.getPrice());
        order.setStatus(request.getStatus());

        TradeOrder updatedOrder =  repo.save(order);

        return tradeOrderMapper.toResponse(updatedOrder);
    }
    

    public String deleteTradeOrder(Long id) {

        TradeOrder order = repo.findById(id).orElseThrow(() -> 
        						new TradeOrderNotFoundException("Trade Order Not Found With Id : "+ id));

        repo.delete(order);

        return "Trade Order Deleted Successfully";
    }
}