package com.trade.order.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TradeOrderResponseDTO {
	private Long id;
	private Long traderId;
	private Long assetId;
	private String orderType;
	private BigDecimal quantity;
	private BigDecimal price;
	private String status;
	private LocalDateTime createdAt;

	public TradeOrderResponseDTO() {
		super();
	}

	public TradeOrderResponseDTO(Long id, Long traderId, Long assetId, String orderType, BigDecimal quantity,
			BigDecimal price, String status, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.traderId = traderId;
		this.assetId = assetId;
		this.orderType = orderType;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.createdAt = createdAt;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTraderId() {
		return traderId;
	}

	public void setTraderId(Long traderId) {
		this.traderId = traderId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

}