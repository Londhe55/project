package com.trade.order.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class TradeOrderRequestDTO {

    @NotNull(message = "Trader Id is required")
    private Long traderId;

    @NotNull(message = "Asset Id is required")
    private Long assetId;

    @NotBlank(message = "Order Type is required")
    private String orderType;

    @NotNull(message = "quantity is required")
    @Positive(message = "quantity must be greater than 0")
    private BigDecimal quantity;

    @NotNull(message = "Price is required")
    @Positive(message = "Price must be greater than 0")
    private BigDecimal price;

    @NotBlank(message = "Status is required")
    private String status;

	public Long getTraderId() {
		return traderId;
	}

	public void setTraderId(Long traderId) {
		this.traderId = traderId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TradeOrderRequestDTO() {
		super();
	}

	public TradeOrderRequestDTO(@NotNull(message = "Trader Id is required") Long traderId,
			@NotNull(message = "Asset Id is required") Long assetId,
			@NotBlank(message = "Order Type is required") String orderType,
			@NotNull(message = "quantity is required") @Positive(message = "quantity must be greater than 0") BigDecimal quantity,
			@NotNull(message = "Price is required") @Positive(message = "Price must be greater than 0") BigDecimal price,
			@NotBlank(message = "Status is required") String status) {
		super();
		this.traderId = traderId;
		this.assetId = assetId;
		this.orderType = orderType;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
	}

	@Override
	public String toString() {
		return "TradeOrderRequestDTO [traderId=" + traderId + ", assetId=" + assetId + ", orderType=" + orderType
				+ ", quantity=" + quantity + ", price=" + price + ", status=" + status + "]";
	}




	

}