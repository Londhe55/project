package com.trade.order.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "TradeOrders")
public class TradeOrder {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "traderId", nullable = false )
	private Long traderId;

	@Column(name = "assetId", nullable = false)
	private Long assetId;

	@Column(name = "orderType", nullable = false, length = 50)
	private String orderType;

	@Column(name = "quantity", nullable = false)
	private BigDecimal quantity;

	@Column(name = "price", nullable = false)
	private BigDecimal price;

	@Column(name = "status", nullable = false, length = 50)
	private String status;

	@Column(name = "createdAt")
	private LocalDateTime createdAt;

	public TradeOrder() {
		super();
	}

	public TradeOrder(Long id, Long traderId, Long assetId, String orderType, BigDecimal quantity, BigDecimal price,
			String status, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.traderId = traderId;
		this.assetId = assetId;
		this.orderType = orderType;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.createdAt = createdAt;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTraderId() {
		return traderId;
	}

	public void setTraderId(Long traderId) {
		this.traderId = traderId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	@Override
	public String toString() {
		return "TradeOrders [id=" + id + ", traderId=" + traderId + ", assetId=" + assetId + ", orderType=" + orderType
				+ ", quantity=" + quantity + ", price=" + price + ", status=" + status + ", createdAt=" + createdAt
				+ "]";
	}

}
