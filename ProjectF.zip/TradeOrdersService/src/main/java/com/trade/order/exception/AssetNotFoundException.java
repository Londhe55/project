package com.trade.order.exception;

public class AssetNotFoundException extends RuntimeException {

	public AssetNotFoundException(String message) {
		super(message);
	}
	
	

}
