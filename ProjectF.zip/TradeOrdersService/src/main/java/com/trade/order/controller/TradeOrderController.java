package com.trade.order.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.trade.order.dto.TradeOrderRequestDTO;
import com.trade.order.dto.TradeOrderResponseDTO;
import com.trade.order.service.TradeOrderService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/tradeordersapi")
public class TradeOrderController {

	private final TradeOrderService service;

	public TradeOrderController(TradeOrderService service) {
		this.service = service;
	}

	
	@Operation(summary = "Get All Trade Orders")
	@GetMapping("/tradeorders")
	public ResponseEntity<List<TradeOrderResponseDTO>> getAllTradeOrders() {

		List<TradeOrderResponseDTO> orders = service.getTradeOrders();

		return ResponseEntity.status(HttpStatus.OK).body(orders);
	}
	

	@Operation(summary = "Create Trade Order")
	@PostMapping("/tradeorder")
	public ResponseEntity<TradeOrderResponseDTO> addTradeOrder(@Valid @RequestBody TradeOrderRequestDTO request) {

		TradeOrderResponseDTO response = service.addTradeOrder(request);

		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}

	
	
	@Operation(summary = "Get Trade Order By Id")
	@GetMapping("/tradeorder/{id}")
	public ResponseEntity<TradeOrderResponseDTO> getTradeOrderById(@PathVariable Long id) {

		TradeOrderResponseDTO response = service.getTradeOrderById(id);

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	
	@Operation(summary = "Update Trade Order")
	@PutMapping("/tradeorder/{id}")
	public ResponseEntity<TradeOrderResponseDTO> updateTradeOrder(@PathVariable Long id,
			@Valid @RequestBody TradeOrderRequestDTO request) {

		TradeOrderResponseDTO response = service.updateTradeOrder(id, request);

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	
	@Operation(summary = "Delete Trade Order")
	@DeleteMapping("/tradeorder/{id}")
	public ResponseEntity<String> deleteTradeOrder(@PathVariable Long id) {

		String response = service.deleteTradeOrder(id);

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
	
}