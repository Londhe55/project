package com.trade.order.mapper;

import org.springframework.stereotype.Component;

import com.trade.order.dto.TradeOrderRequestDTO;
import com.trade.order.dto.TradeOrderResponseDTO;
import com.trade.order.entity.TradeOrder;

@Component
public class TradeOrderMapper {
	
	
	public TradeOrder toEntity(TradeOrderRequestDTO requestDTO) {
		
		TradeOrder tradeOrder = new TradeOrder();
		
		tradeOrder.setTraderId(requestDTO.getTraderId());
		tradeOrder.setAssetId(requestDTO.getAssetId());
		tradeOrder.setOrderType(requestDTO.getOrderType());
		tradeOrder.setQuantity(requestDTO.getQuantity());
		tradeOrder.setPrice(requestDTO.getPrice());
		tradeOrder.setStatus(requestDTO.getStatus());
		
		return tradeOrder;
		
	}
	
	
	
	public TradeOrderResponseDTO toResponse(TradeOrder tradeOrder) {
		
		TradeOrderResponseDTO responseDTO = new TradeOrderResponseDTO();
		
		responseDTO.setId(tradeOrder.getId());
		responseDTO.setTraderId(tradeOrder.getTraderId());
		responseDTO.setAssetId(tradeOrder.getAssetId());
		responseDTO.setOrderType(tradeOrder.getOrderType());
		responseDTO.setQuantity(tradeOrder.getQuantity());
		responseDTO.setPrice(tradeOrder.getPrice());
		responseDTO.setStatus(tradeOrder.getStatus());
		responseDTO.setCreatedAt(tradeOrder.getCreatedAt());
		
		return responseDTO;
	}

}
