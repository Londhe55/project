package com.trade.order.exception;

public class TradeOrderListNotFoundException extends RuntimeException {

	public TradeOrderListNotFoundException(String message) {
		super(message);
	}
}
