package com.trader.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.trader.entity.Trader;

import jakarta.validation.constraints.AssertFalse;


@DataJpaTest
public class TraderRepositoryTest {
	
	
	@Autowired
	private TraderRepository repository;
	
	
	
//	Test Case for save Trader
	@Test
	void testSaveTrader() {

		Trader trader = new Trader();
		
		trader.setTradingCompanyId(1L);
		trader.setFirstName("Sham");
		trader.setLastName("Jadhav");
		trader.setEmail("info@gmail.com");
		trader.setPhone("6591234567");
		trader.setCreatedAt(LocalDateTime.now());
		
		Trader savedtTrader = repository.save(trader);
		
		assertNotNull(savedtTrader);
		assertNotNull(savedtTrader.getId());
		
	}
	
	
	@Test
	void testFindTraderById() {
		
		Trader trader = new Trader();
		
		trader.setTradingCompanyId(1L);
		trader.setFirstName("Sham");
		trader.setLastName("Jadhav");
		trader.setEmail("info@gmail.com");
		trader.setPhone("6591234567");
		trader.setCreatedAt(LocalDateTime.now());
		
		Trader savedtTrader = repository.save(trader);
		
		Optional<Trader> result = repository.findById(trader.getId());
		
		assertTrue(result.isPresent());
		assertEquals(result.get().getId(), savedtTrader.getId());
	}
	
	
	
	@Test
	void testFindAllTrader() {
		
		Trader trader = new Trader();
		
		trader.setTradingCompanyId(1L);
		trader.setFirstName("Sham");
		trader.setLastName("Jadhav");
		trader.setEmail("info@gmail.com");
		trader.setPhone("6591234567");
		trader.setCreatedAt(LocalDateTime.now());
		
		Trader trader1 = new Trader();
		
		trader1.setTradingCompanyId(1L);
		trader1.setFirstName("Sham");
		trader1.setLastName("Jadhav");
		trader1.setEmail("info@gmail.com");
		trader1.setPhone("6591234567");
		trader1.setCreatedAt(LocalDateTime.now());
		
		Trader savedTrader  = repository.save(trader);
		Trader savedTrader2 = repository.save(trader1);
		
		List<Trader> results = repository.findAll();
		
		assertFalse(results.isEmpty());
		assertEquals(2, results.size());
	}
	
	
	@Test
	void testUpdateTrdaerById() {
		
		Trader trader = new Trader();
		
		trader.setTradingCompanyId(1L);
		trader.setFirstName("Sham");
		trader.setLastName("Jadhav");
		trader.setEmail("info@gmail.com");
		trader.setPhone("6591234567");
		trader.setCreatedAt(LocalDateTime.now());
		
		Trader savedTrader = repository.save(trader);
		
		trader.setFirstName("Ram");
		trader.setLastName("Sharma");
		
		Trader updaTrader = repository.save(trader);
		
		assertEquals("Ram", updaTrader.getFirstName());
		assertEquals("Sharma", updaTrader.getLastName());
	}

	
	@Test
	void testDeleteTraderById() {
		
		Trader trader = new Trader();
		
		trader.setTradingCompanyId(1L);
		trader.setFirstName("Sham");
		trader.setLastName("Jadhav");
		trader.setEmail("info@gmail.com");
		trader.setPhone("6591234567");
		trader.setCreatedAt(LocalDateTime.now());
		
		Trader savedTrader = repository.save(trader);
		
		
		repository.deleteById(trader.getId());
		
		Optional<Trader> result = repository.findById(trader.getId());
		
		assertFalse(result.isPresent());
		
	}
}
