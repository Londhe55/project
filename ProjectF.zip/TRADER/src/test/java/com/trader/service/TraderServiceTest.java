package com.trader.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import com.trader.dto.TraderRequest;
import com.trader.dto.TraderResponse;
import com.trader.dto.TraderUpdateRequest;
import com.trader.entity.Trader;
import com.trader.exception.ResourceNotFoundException;
import com.trader.feign.CompanyClient;
import com.trader.mapper.TraderMapper;
import com.trader.repository.TraderRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TraderServiceTest {

	@Mock
	private TraderRepository traderRepository;

	@Mock
	private TraderMapper traderMapper;

	@Mock
	private CompanyClient companyClient;

	@InjectMocks
	private TraderService traderService;

	
	// Create Trader
	@Test
	void testCreateTrader() {

		TraderRequest request = new TraderRequest();

		request.setTradingCompanyId(1L);

		Trader trader = new Trader();

		Trader savedTrader = new Trader();

		TraderResponse response = new TraderResponse();

		when(traderMapper.toEntity(request)).thenReturn(trader);

		when(traderRepository.save(trader)).thenReturn(savedTrader);

		when(traderMapper.toResponse(savedTrader)).thenReturn(response);

		TraderResponse result = traderService.createTrader(request);

		assertNotNull(result);

		verify(traderRepository).save(trader);
	}

	
	// Trading Company Not Found
	@Test
	void testCreateTraderCompanyNotFound() {

		TraderRequest request = new TraderRequest();

		request.setTradingCompanyId(1L);

		when(companyClient.getCompanyById(1L)).thenThrow(new RuntimeException());

		assertThrows(ResourceNotFoundException.class, () -> traderService.createTrader(request));
	}

	
	// Get Trader By Id
	@Test
	void testGetTraderById() {

		Trader trader = new Trader();

		TraderResponse response = new TraderResponse();

		when(traderRepository.findById(1L)).thenReturn(Optional.of(trader));

		when(traderMapper.toResponse(trader)).thenReturn(response);

		TraderResponse result = traderService.getTraderById(1L);

		assertNotNull(result);
	}

	
	// Get Trader By Id Not Found
	@Test
	void testGetTraderByIdNotFound() {

		when(traderRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> traderService.getTraderById(1L));
	}

	
	// Get All Traders
	@Test
	void testGetAllTraders() {

		Trader trader = new Trader();

		TraderResponse response = new TraderResponse();

		when(traderRepository.findAll()).thenReturn(List.of(trader));

		when(traderMapper.toResponse(trader)).thenReturn(response);

		List<TraderResponse> result = traderService.getAllTraders();

		assertEquals(1, result.size());
	}
	

	// Update Trader
	@Test
	void testUpdateTrader() {

		Trader trader = new Trader();

		TraderUpdateRequest request = new TraderUpdateRequest();

		request.setFirstName("Virat");
		request.setLastName("Kohli");
		request.setEmail("virat@test.com");
		request.setPhone("9876543210");

		TraderResponse response = new TraderResponse();

		when(traderRepository.findById(1L)).thenReturn(Optional.of(trader));

		when(traderRepository.save(trader)).thenReturn(trader);

		when(traderMapper.toResponse(trader)).thenReturn(response);

		TraderResponse result = traderService.updateTrader(1L, request);

		assertNotNull(result);

		verify(traderRepository).save(trader);
	}

	
	// Update Trader Not Found
	@Test
	void testUpdateTraderNotFound() {

		TraderUpdateRequest request = new TraderUpdateRequest();

		when(traderRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> traderService.updateTrader(1L, request));
	}

	
	// Delete Trader
	@Test
	void testDeleteTrader() {

		Trader trader = new Trader();

		when(traderRepository.findById(1L)).thenReturn(Optional.of(trader));

		String result = traderService.deleteTrader(1L);

		assertEquals("Trader deleted successfully", result);

		verify(traderRepository).delete(trader);
	}

	
	// Delete Trader Not Found
	@Test
	void testDeleteTraderNotFound() {

		when(traderRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> traderService.deleteTrader(1L));
	}
}