package com.trader.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trader.dto.TraderRequest;
import com.trader.dto.TraderResponse;
import com.trader.service.TraderService;

@WebMvcTest(TraderController.class)
public class TraderControllerTest {
	
	
	@Autowired
	MockMvc mockMvc;
	
	@MockitoBean
	private TraderService serviceImpl;
	
	@Autowired
	ObjectMapper objectMapper;
	
	
	
	

	@Test
	void testCreateTrader() throws Exception {

	    TraderResponse response = new TraderResponse();

	    response.setId(1L);
	    response.setTradingCompanyId(101L);
	    response.setFirstName("Sham");
	    response.setLastName("Jadhav");
	    response.setEmail("shamjadhv@globaltrade.com");
	    response.setPhone("1234567890");

	    when(serviceImpl.createTrader(any())).thenReturn(response);

	    TraderRequest request = new TraderRequest();

	    request.setTradingCompanyId(101L);
	    request.setFirstName("Jordan");
	    request.setLastName("Lee");
	    request.setEmail("jordan.lee@globaltrade.com");
	    request.setPhone("6356482173897");

	    String json = objectMapper.writeValueAsString(request);

	    mockMvc.perform(post("/api/traders")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content(json))
	            .andExpect(status().isCreated())
	            .andExpect(jsonPath("$.id").value(1))
	            .andExpect(jsonPath("$.firstName").value("Sham"))
	            .andExpect(jsonPath("$.lastName").value("Jadhav"))
	            .andExpect(jsonPath("$.email").value("shamjadhv@globaltrade.com"));

	    verify(serviceImpl).createTrader(any());
	}
	
	
	
	
	@Test
	void testGetTraderById() throws Exception {

	    TraderResponse response = new TraderResponse();

	    response.setId(1L);
	    response.setTradingCompanyId(101L);
	    response.setFirstName("Jordan");
	    response.setLastName("Lee");
	    response.setEmail("jordan.lee@globaltrade.com");
	    response.setPhone("+65 91234567");

	    when(serviceImpl.getTraderById(1L)).thenReturn(response);

	    mockMvc.perform(get("/api/traders/1"))
	            .andExpect(status().isOk())
	            .andExpect(jsonPath("$.id").value(1))
	            .andExpect(jsonPath("$.firstName").value("Jordan"))
	            .andExpect(jsonPath("$.lastName").value("Lee"));

	    verify(serviceImpl).getTraderById(1L);
	}
	
	
	
	
	
	
	
	
	@Test
	void testGetAllTraders() throws Exception {

	    TraderResponse trader1 = new TraderResponse();

	    trader1.setId(1L);
	    trader1.setFirstName("Jordan");
	    trader1.setLastName("Lee");

	    TraderResponse trader2 = new TraderResponse();

	    trader2.setId(2L);
	    trader2.setFirstName("John");
	    trader2.setLastName("Smith");

	    when(serviceImpl.getAllTraders()).thenReturn(List.of(trader1, trader2));

	    mockMvc.perform(get("/api/traders"))
	            .andExpect(status().isOk())
	            .andExpect(jsonPath("$[0].id").value(1))
	            .andExpect(jsonPath("$[0].firstName")
	                    .value("Jordan"))
	            .andExpect(jsonPath("$[1].id").value(2))
	            .andExpect(jsonPath("$[1].firstName")
	                    .value("John"));

	    verify(serviceImpl).getAllTraders();
	}
		

	
	
	@Test
	void testUpdateTrader() throws Exception {

	    TraderResponse response = new TraderResponse();

	    response.setId(1L);
	    response.setTradingCompanyId(101L);
	    response.setFirstName("Updated");
	    response.setLastName("Trader");
	    response.setEmail("updated@test.com");
	    response.setPhone("+65 99999999");

	    when(serviceImpl.updateTrader(eq(1L),any())).thenReturn(response);

	    TraderRequest request = new TraderRequest();

	    request.setTradingCompanyId(101L);
	    request.setFirstName("Updated");
	    request.setLastName("Trader");
	    request.setEmail("updated@test.com");
	    request.setPhone("+65 99999999");

	    String json = objectMapper.writeValueAsString(request);

	    mockMvc.perform(put("/api/traders/1")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content(json))
	            .andExpect(status().isOk())
	            .andExpect(jsonPath("$.id").value(1))
	            .andExpect(jsonPath("$.firstName").value("Updated"))
	            .andExpect(jsonPath("$.lastName").value("Trader"))
	            .andExpect(jsonPath("$.email").value("updated@test.com"));

	    verify(serviceImpl).updateTrader(eq(1L), any());
	}

	
	@Test
	void testDeleteTraderById() throws Exception {

	    when(serviceImpl.deleteTrader(1L)).thenReturn("Trader deleted successfully");

	    mockMvc.perform(delete("/api/traders/1"))
	            .andExpect(status().isOk())
	            .andExpect(content().string("Trader deleted successfully"));

	    verify(serviceImpl).deleteTrader(1L);
	}
	
	

}
