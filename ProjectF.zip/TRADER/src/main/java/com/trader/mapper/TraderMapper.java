package com.trader.mapper;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import com.trader.dto.TraderRequest;
import com.trader.dto.TraderResponse;
import com.trader.entity.Trader;

@Component
public class TraderMapper {

    public Trader toEntity(TraderRequest request) {

        Trader trader = new Trader();

        trader.setTradingCompanyId(request.getTradingCompanyId());
        trader.setFirstName(request.getFirstName());
        trader.setLastName(request.getLastName());
        trader.setEmail(request.getEmail());
        trader.setPhone(request.getPhone());
        trader.setCreatedAt(LocalDateTime.now());

        return trader;
    }

    public TraderResponse toResponse(Trader trader) {

        TraderResponse response = new TraderResponse();

        response.setId(trader.getId());
        response.setTradingCompanyId(trader.getTradingCompanyId());
        response.setFirstName(trader.getFirstName());
        response.setLastName(trader.getLastName());
        response.setEmail(trader.getEmail());
        response.setPhone(trader.getPhone());
        response.setCreatedAt(trader.getCreatedAt());

        return response;
    }
}