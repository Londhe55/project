package com.trader.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class TraderRequest {

    @NotNull(message = "Trading Company Id is required")
    private Long tradingCompanyId;

    @NotBlank(message = "First Name is required")
    private String firstName;

    @NotBlank(message = "Last Name is required")
    private String lastName;

    @Email(message = "Invalid Email Format")
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Phone Number is required")
    private String phone;

	public Long getTradingCompanyId() {
		return tradingCompanyId;
	}

	public void setTradingCompanyId(Long tradingCompanyId) {
		this.tradingCompanyId = tradingCompanyId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public TraderRequest(@NotNull(message = "Trading Company Id is required") Long tradingCompanyId,
			@NotBlank(message = "First Name is required") String firstName,
			@NotBlank(message = "Last Name is required") String lastName,
			@Email(message = "Invalid Email Format") @NotBlank(message = "Email is required") String email,
			@NotBlank(message = "Phone Number is required") String phone) {
		super();
		this.tradingCompanyId = tradingCompanyId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
	}

	public TraderRequest() {
		super();
	}

    
    
    
}