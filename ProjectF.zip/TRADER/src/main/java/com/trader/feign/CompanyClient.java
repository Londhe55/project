package com.trader.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.trader.dto.CompanyDTO;

@FeignClient(name = "TRADING-COMPANY")
public interface CompanyClient {

    @GetMapping("/companies/{id}")
    CompanyDTO getCompanyById(@PathVariable("id") Long id);

}