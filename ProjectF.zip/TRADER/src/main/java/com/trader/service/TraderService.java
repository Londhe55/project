package com.trader.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.trader.dto.TraderRequest;
import com.trader.dto.TraderResponse;
import com.trader.dto.TraderUpdateRequest;
import com.trader.entity.Trader;
import com.trader.exception.ResourceNotFoundException;
import com.trader.feign.CompanyClient;
import com.trader.mapper.TraderMapper;
import com.trader.repository.TraderRepository;
import com.trader.service.TraderService;

@Service
public class TraderService  {

    @Autowired
    private TraderRepository traderRepository;

    @Autowired
    private TraderMapper traderMapper;

    @Autowired
    private CompanyClient companyClient;
    
    
    
    
    public TraderResponse createTrader(TraderRequest traderRequest) {

    	
        try {
            companyClient.getCompanyById( traderRequest.getTradingCompanyId());   
            
        }
        catch (Exception e) {
            throw new ResourceNotFoundException("Trading Company not found with id : "+ traderRequest.getTradingCompanyId());
        }

        Trader trader = traderMapper.toEntity(traderRequest);
        Trader savedTrader = traderRepository.save(trader);
        
        return traderMapper.toResponse(savedTrader);
    }
    
    

    

    public TraderResponse getTraderById(Long traderId) {

    	Trader trader = traderRepository.findById(traderId)
    	        		.orElseThrow(() -> new ResourceNotFoundException("Trader not found with id : " + traderId));

        return traderMapper.toResponse(trader);
    }

  
    public List<TraderResponse> getAllTraders() {

        return traderRepository.findAll()
                .stream()
                .map(traderMapper::toResponse)
                .collect(Collectors.toList());
    }


    public TraderResponse updateTrader(Long traderId,
            TraderUpdateRequest traderUpdateRequestDTO) {

    	Trader trader = traderRepository.findById(traderId)
    	        		.orElseThrow(() -> new ResourceNotFoundException("Trader not found with id : " + traderId));

        trader.setFirstName(traderUpdateRequestDTO.getFirstName());
        trader.setLastName(traderUpdateRequestDTO.getLastName());
        trader.setEmail(traderUpdateRequestDTO.getEmail());
        trader.setPhone(traderUpdateRequestDTO.getPhone());

        Trader updatedTrader = traderRepository.save(trader);

        return traderMapper.toResponse(updatedTrader);
    }

    

    public String deleteTrader(Long traderId) {

    	Trader trader = traderRepository.findById(traderId)
    	        			.orElseThrow(() -> new ResourceNotFoundException("Trader not found with id : " + traderId));

        traderRepository.delete(trader);

        return "Trader deleted successfully";
    }
}