package com.trader.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trader.entity.Trader;

@Repository
public interface TraderRepository extends JpaRepository<Trader, Long>{
	
	

}
