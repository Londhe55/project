package com.trading.company.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.trading.company.dto.CreateTradingCompanyRequest;
import com.trading.company.dto.TradingCompanyResponse;
import com.trading.company.dto.UpdateTradingCompanyRequest;
import com.trading.company.entity.TradingCompany;
import com.trading.company.exception.ResourceNotFoundException;
import com.trading.company.mapper.TradingCompanyMapper;
import com.trading.company.repository.TradingCompanyRepository;

@ExtendWith(MockitoExtension.class)
public class TradingCompanyServiceTest {

	@Mock
	private TradingCompanyRepository repository;

	@Mock
	private TradingCompanyMapper mapper;

	@InjectMocks
	private TradingCompanyService companyService;

	
	
//	Test Case for the Create the Trading Company
	@Test
	void testCreateTradingCompany() {

		CreateTradingCompanyRequest companyRequest = new CreateTradingCompanyRequest();

		companyRequest.setName("TCS");
		companyRequest.setLicenseNumber("LTC1001");
		companyRequest.setContactEmail("tcs@test.com");
		companyRequest.setAddress("Chennai");

		TradingCompany tradingCompany = new TradingCompany();

		TradingCompany savedTradingCompany = new TradingCompany();

		TradingCompanyResponse companyResponse = new TradingCompanyResponse();

		when(repository.existsByLicenseNumber("LTC1001")).thenReturn(false);

		when(repository.existsByContactEmail("tcs@test.com")).thenReturn(false);

		when(mapper.toEntity(companyRequest)).thenReturn(tradingCompany);

		when(repository.save(tradingCompany)).thenReturn(savedTradingCompany);

		when(mapper.toResponse(savedTradingCompany)).thenReturn(companyResponse);

		TradingCompanyResponse result = companyService.createTradingCompany(companyRequest);

		assertNotNull(result);

		verify(repository).save(tradingCompany);
	}

	// Get Company By Id
	@Test
	void testGetTradingCompanyByID() {

		TradingCompany tradingCompany = new TradingCompany();

		TradingCompanyResponse companyResponse = new TradingCompanyResponse();

		when(repository.findById(1L)).thenReturn(Optional.of(tradingCompany));

		when(mapper.toResponse(tradingCompany)).thenReturn(companyResponse);

		TradingCompanyResponse response = companyService.getTradingCompanyById(1L);

		assertNotNull(response);

	}

	// Get Company By Id Not Found
	@Test
	void testGetTradingCompanyByIdNotFound() {

		when(repository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> companyService.getTradingCompanyById(1L));
	}

//	Test Case For Get the All Trading Company
	@Test
	void GetAllTradingCompany() {

		TradingCompany tradingCompany = new TradingCompany();

		TradingCompanyResponse companyResponse = new TradingCompanyResponse();

		when(repository.findAll()).thenReturn(List.of(tradingCompany));

		when(mapper.toResponse(tradingCompany)).thenReturn(companyResponse);

		List<TradingCompanyResponse> result = companyService.getAllTradingCompanies();

		assertEquals(1, result.size());

	}

//	Test case for Update Trading Company

	@Test
	void testUpdateTradingCompany() {

		UpdateTradingCompanyRequest request = new UpdateTradingCompanyRequest();

		request.setName("Updated Company");
		request.setContactEmail("updated@test.com");
		request.setAddress("Mumbai");

		TradingCompany company = new TradingCompany();

		TradingCompanyResponse response = new TradingCompanyResponse();

		when(repository.findById(1L)).thenReturn(Optional.of(company));

		when(repository.save(company)).thenReturn(company);

		when(mapper.toResponse(company)).thenReturn(response);

		TradingCompanyResponse result = companyService.updateTradingCompany(1L, request);

		assertNotNull(result);

		verify(repository).save(company);
	}

//	Test case for Delete Trading Company By ID
	@Test
	void testDeleteTradingCompany() {

		TradingCompany company = new TradingCompany();

		when(repository.findById(1L)).thenReturn(Optional.of(company));

		companyService.deleteTradingCompany(1L);

		verify(repository).delete(company);
	}

//	Test Case for Delete Trading Company Not Found
	@Test
	void testDeleteTradingCompanyNotFound() {

		when(repository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> companyService.deleteTradingCompany(1L));
	}

//	Test Case for Update Trading Company Not Found
	@Test
	void testUpdateTradingCompanyNotFound() {

		UpdateTradingCompanyRequest request = new UpdateTradingCompanyRequest();

		when(repository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> companyService.updateTradingCompany(1L, request));
	}
}
