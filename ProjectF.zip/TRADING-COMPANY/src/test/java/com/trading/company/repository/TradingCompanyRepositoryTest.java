package com.trading.company.repository;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.trading.company.entity.TradingCompany;
import com.trading.company.repository.TradingCompanyRepository;

@DataJpaTest
public class TradingCompanyRepositoryTest {
	
	@Autowired
	TradingCompanyRepository repository;
	
	
	
//	Test case for Save Trading comapny
	@Test
	void testSaveTradingCompany() {
		
		TradingCompany company = new TradingCompany();
		
		company.setName("Global Trade Crop");
		company.setLicenseNumber("TRD-56789");
		company.setContactEmail("info@globaltrade.com");
		company.setAddress("150 Market Street, Singapore");
		company.setCreatedAt(LocalDateTime.now());
		
		TradingCompany savedTradingCompany = repository.save(company);
		
		assertNotNull(savedTradingCompany);
		assertNotNull(savedTradingCompany.getId());
		assertEquals("Global Trade Crop", savedTradingCompany.getName());
	}
	
	

//	Test case for Find trading Company by id
	@Test
	void testFindTradingCompanyByID() {
		
		TradingCompany company = new TradingCompany();
		
		company.setName("Global Trade Crop");
		company.setLicenseNumber("TRD-56789");
		company.setContactEmail("info@globaltrade.com");
		company.setAddress("150 Market Street, Singapore");
		company.setCreatedAt(LocalDateTime.now());
		
		TradingCompany savedTradingCompany = repository.save(company);
		
		Optional<TradingCompany> result = repository.findById(savedTradingCompany.getId());
		
		
		assertTrue(result.isPresent());
		assertEquals(savedTradingCompany.getId(), result.get().getId());
		
	}
	
	
//	Test case for Finding All Trading Company
	@Test
	void testFindAllTradingCompany() {
		
		TradingCompany company = new TradingCompany();
		
		company.setName("Global Trade Crop");
		company.setLicenseNumber("TRD-56789");
		company.setContactEmail("info@globaltrade.com");
		company.setAddress("150 Market Street, Singapore");
		company.setCreatedAt(LocalDateTime.now());
		
		TradingCompany company2 = new TradingCompany();
		
		company2.setName(" Trade Crop");
		company2.setLicenseNumber("ABD-56789");
		company2.setContactEmail("infotech@globaltrade.com");
		company2.setAddress("250 Market Street, Singapore");
		company2.setCreatedAt(LocalDateTime.now());
		
		TradingCompany savedCompany1 = repository.save(company);
		TradingCompany savedCompany2 = repository.save(company2);
		
		List<TradingCompany> results = repository.findAll();
		
		assertEquals(2, results.size());
		assertFalse(results.isEmpty());
		
	}
	
	
	
//	Test Case for Update trading Comapny
	@Test
	void testupdateTradingCompanyById() {
		
		TradingCompany company = new TradingCompany();
		
		company.setName("Global Trade Crop");
		company.setLicenseNumber("TRD-56789");
		company.setContactEmail("info@globaltrade.com");
		company.setAddress("150 Market Street, Singapore");
		company.setCreatedAt(LocalDateTime.now());
		
		TradingCompany savedCompany = repository.save(company);
		
		
		
		company.setName("Trade Crop");
		company.setLicenseNumber("TRD-1234");
		
		TradingCompany updaCompany = repository.save(company);
		
		assertEquals("Trade Crop", updaCompany.getName());
		assertEquals("TRD-1234", updaCompany.getLicenseNumber());

		
	}

	
	
//	Test Case for delete Trading Company
	@Test
	void testDeleteTradingCompanyById() {
		
		TradingCompany company = new TradingCompany();
		
		company.setName("Global Trade Crop");
		company.setLicenseNumber("TRD-56789");
		company.setContactEmail("info@globaltrade.com");
		company.setAddress("150 Market Street, Singapore");
		company.setCreatedAt(LocalDateTime.now());
		
		TradingCompany savedCompany = repository.save(company);
		
		
		repository.deleteById(savedCompany.getId());
		
		Optional<TradingCompany> result = repository.findById(savedCompany.getId());
		
		assertFalse(result.isPresent());
	}
}
