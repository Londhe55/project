package com.trading.company;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradingCompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
