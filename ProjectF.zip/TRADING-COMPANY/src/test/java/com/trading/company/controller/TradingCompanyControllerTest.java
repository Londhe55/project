package com.trading.company.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trading.company.dto.CreateTradingCompanyRequest;
import com.trading.company.dto.TradingCompanyResponse;
import com.trading.company.dto.UpdateTradingCompanyRequest;
import com.trading.company.service.TradingCompanyService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import org.springframework.http.MediaType;

@WebMvcTest(TradingCompanyController.class)
class TradingCompanyControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockitoBean
	private TradingCompanyService tradingCompanyService;

	// Test Case for Creating Trading Company
	@Test
	void testCreateTradingCompany() throws Exception {

		TradingCompanyResponse response = new TradingCompanyResponse();
		response.setName("Cognizant Trading");
		response.setLicenseNumber("LIC-1001");
		response.setContactEmail("support@tcs.com");
		response.setAddress("Chennai");

		when(tradingCompanyService.createTradingCompany(any())).thenReturn(response);

		CreateTradingCompanyRequest request = new CreateTradingCompanyRequest();

		request.setName("Cognizant Trading");
		request.setLicenseNumber("LIC-1001");
		request.setContactEmail("support@tcs.com");
		request.setAddress("Chennai");

		mockMvc.perform(post("/companies").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(request)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.name").value("Cognizant Trading"))
				.andExpect(jsonPath("$.licenseNumber").value("LIC-1001"))
				.andExpect(jsonPath("$.address").value("Chennai"))
				.andExpect(jsonPath("$.contactEmail").value("support@tcs.com"));

		verify(tradingCompanyService).createTradingCompany(any());
	}

	
	
	
	@Test
	void testGetTradingCompanyById() throws Exception {

		TradingCompanyResponse response = new TradingCompanyResponse();

		response.setId(1L);
		response.setName("Cognizant Trading");
		response.setLicenseNumber("LIC-1001");
		response.setContactEmail("support@tcs.com");
		response.setAddress("Chennai");

		when(tradingCompanyService.getTradingCompanyById(1L)).thenReturn(response);

		mockMvc.perform(get("/companies/1"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.name").value("Cognizant Trading"))
				.andExpect(jsonPath("$.licenseNumber").value("LIC-1001"));

		verify(tradingCompanyService).getTradingCompanyById(1L);
	}

	
	
	
	
	
	
	@Test
	void testGetAllTradingCompanies() throws Exception {

		TradingCompanyResponse response = new TradingCompanyResponse();

		response.setId(1L);
		response.setName("Cognizant");
		response.setLicenseNumber("LIC-2001");

		TradingCompanyResponse response2 = new TradingCompanyResponse();
		response2.setId(2L);
		response2.setName("TCS");
		response2.setLicenseNumber("LIC-3001");

//		"When the controller calls the service, don't run the real service logic. Just return this response object."
		when(tradingCompanyService.getAllTradingCompanies()).thenReturn(List.of(response, response2));

		mockMvc.perform(get("/companies")).andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(1))
				.andExpect(jsonPath("$[0].name").value("Cognizant"))
				.andExpect(jsonPath("$[0].licenseNumber").value("LIC-2001"))

				.andExpect(jsonPath("$[1].id").value(2)).andExpect(jsonPath("$[1].name").value("TCS"))
				.andExpect(jsonPath("$[1].licenseNumber").value("LIC-3001"));

		verify(tradingCompanyService).getAllTradingCompanies();
	}

	// Test Case for Update Trading Company

	@Test
	void testUpdateTradingCompany() throws Exception {

		TradingCompanyResponse response = new TradingCompanyResponse();

		response.setId(1L);
		response.setName("Cognizant");
		response.setLicenseNumber("LIC-1001");
		response.setContactEmail("support@cognizant.com");
		response.setAddress("Pune");

		when(tradingCompanyService.updateTradingCompany(eq(1L), any(UpdateTradingCompanyRequest.class)))
				.thenReturn(response);

		UpdateTradingCompanyRequest request = new UpdateTradingCompanyRequest();

		request.setName("TCS");
		request.setContactEmail("updated@test.com");
		request.setAddress("Chennai");

		String json = objectMapper.writeValueAsString(request);

		mockMvc.perform(put("/companies/1")
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id").value(1))
				.andExpect(jsonPath("$.name").value("Cognizant"))
				.andExpect(jsonPath("$.licenseNumber").value("LIC-1001"))
				.andExpect(jsonPath("$.contactEmail").value("support@cognizant.com"))
				.andExpect(jsonPath("$.address").value("Pune"));

		verify(tradingCompanyService).updateTradingCompany(eq(1L), any(UpdateTradingCompanyRequest.class));
	}

	
	
	
	@Test
	void testDeleteTradingCompany() throws Exception {

	    doNothing().when(tradingCompanyService).deleteTradingCompany(1L);

	    mockMvc.perform(delete("/companies/1"))
	            .andExpect(status().isOk())
	            .andExpect(content().string("Trading Company deleted successfully"));

	    verify(tradingCompanyService).deleteTradingCompany(1L);
	}

}