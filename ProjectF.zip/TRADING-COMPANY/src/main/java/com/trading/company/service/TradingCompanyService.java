package com.trading.company.service;

import com.trading.company.dto.CreateTradingCompanyRequest;
import com.trading.company.dto.TradingCompanyResponse;
import com.trading.company.dto.UpdateTradingCompanyRequest;
import com.trading.company.entity.TradingCompany;
import com.trading.company.exception.DuplicateResourceException;
import com.trading.company.exception.ResourceNotFoundException;
import com.trading.company.mapper.TradingCompanyMapper;
import com.trading.company.repository.TradingCompanyRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TradingCompanyService {

	@Autowired
	TradingCompanyRepository tradingCompanyRepository;
	
	@Autowired
	TradingCompanyMapper tradingCompanyMapper;

	

	
	
	public TradingCompanyResponse createTradingCompany(CreateTradingCompanyRequest request) {

		if (tradingCompanyRepository.existsByLicenseNumber(request.getLicenseNumber())) {

			throw new DuplicateResourceException("License number already exists" + request.getLicenseNumber());
		}

		if (tradingCompanyRepository.existsByContactEmail(request.getContactEmail())) {

			throw new DuplicateResourceException("Email already exists");
		}

		TradingCompany company = tradingCompanyMapper.toEntity(request);

		company.setCreatedAt(LocalDateTime.now());

		TradingCompany savedCompany = tradingCompanyRepository.save(company);

		return tradingCompanyMapper.toResponse(savedCompany);
	}

	
	
	
	public TradingCompanyResponse getTradingCompanyById(Long id) {

		TradingCompany company = tradingCompanyRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Trading Company not found with id :" + id));

		return tradingCompanyMapper.toResponse(company);
	}
	
	
	


	public List<TradingCompanyResponse> getAllTradingCompanies() {

		return tradingCompanyRepository.findAll()
										.stream()
										.map(tradingCompanyMapper::toResponse)
										.collect(Collectors.toList());
	}

	
	public TradingCompanyResponse updateTradingCompany(Long id, UpdateTradingCompanyRequest request) {

		TradingCompany company = tradingCompanyRepository.findById(id)
								.orElseThrow(() -> new ResourceNotFoundException("Trading Company not found"));

		company.setName(request.getName());
		company.setContactEmail(request.getContactEmail());
		company.setAddress(request.getAddress());
		company.setUpdatedAt(LocalDateTime.now());

		TradingCompany updatedCompany = tradingCompanyRepository.save(company);

		return tradingCompanyMapper.toResponse(updatedCompany);
	}


	
	public void deleteTradingCompany(Long id) {

		TradingCompany company = tradingCompanyRepository.findById(id)
								.orElseThrow(() -> new ResourceNotFoundException("Trading Company not found"));

		tradingCompanyRepository.delete(company);
	}
}