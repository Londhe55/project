package com.trading.company.mapper;

import com.trading.company.dto.CreateTradingCompanyRequest;
import com.trading.company.dto.TradingCompanyResponse;
import com.trading.company.entity.TradingCompany;
import org.springframework.stereotype.Component;

@Component
public class TradingCompanyMapper {

    public TradingCompany toEntity(CreateTradingCompanyRequest request) {

        TradingCompany company = new TradingCompany();

        company.setName(request.getName());
        company.setLicenseNumber(request.getLicenseNumber());
        company.setContactEmail(request.getContactEmail());
        company.setAddress(request.getAddress());

        return company;
    }

    public TradingCompanyResponse toResponse(TradingCompany company) {

        TradingCompanyResponse response = new TradingCompanyResponse();

        response.setId(company.getId());
        response.setName(company.getName());
        response.setLicenseNumber(company.getLicenseNumber());
        response.setContactEmail(company.getContactEmail());
        response.setAddress(company.getAddress());
        response.setCreatedAt(company.getCreatedAt());
        response.setUpdatedAt(company.getUpdatedAt());

        return response;
    }
}