package com.trading.company.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;


public class CreateTradingCompanyRequest {

    @NotBlank(message = "Company name is required")
    @Size(max = 150, message = "Company name cannot exceed 150 characters")
    private String name;

    @NotBlank(message = "License number is required")
    private String licenseNumber;

    @NotBlank(message = "Contact email is required")
    @Email(message = "Invalid email format")
    private String contactEmail;

    @NotBlank(message = "Address is required")
    @Size(max = 250, message = "Address cannot exceed 250 characters")
    private String address;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public CreateTradingCompanyRequest(
			@NotBlank(message = "Company name is required") @Size(max = 150, message = "Company name cannot exceed 150 characters") String name,
			@NotBlank(message = "License number is required") String licenseNumber,
			@NotBlank(message = "Contact email is required") @Email(message = "Invalid email format") String contactEmail,
			@NotBlank(message = "Address is required") @Size(max = 250, message = "Address cannot exceed 250 characters") String address) {
		super();
		this.name = name;
		this.licenseNumber = licenseNumber;
		this.contactEmail = contactEmail;
		this.address = address;
	}

	public CreateTradingCompanyRequest() {
		super();
	}
    
    
    
}
