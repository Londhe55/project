package com.trading.company.controller;

import com.trading.company.dto.CreateTradingCompanyRequest;
import com.trading.company.dto.TradingCompanyResponse;
import com.trading.company.dto.UpdateTradingCompanyRequest;
import com.trading.company.service.TradingCompanyService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/companies")
public class TradingCompanyController {

    private final TradingCompanyService tradingCompanyService;

    public TradingCompanyController(TradingCompanyService tradingCompanyService) {
        this.tradingCompanyService = tradingCompanyService;
    }

 
    
    @PostMapping
    @Operation(summary = "Create a new trading company")
    public ResponseEntity<TradingCompanyResponse> createTradingCompany(
            @Valid @RequestBody CreateTradingCompanyRequest request) {

        TradingCompanyResponse response = tradingCompanyService.createTradingCompany(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

  
    
    @GetMapping("/{id}")
    @Operation(summary = "Get trading company by id")
    public ResponseEntity<TradingCompanyResponse> getTradingCompanyById(@PathVariable Long id) {

        TradingCompanyResponse response = tradingCompanyService.getTradingCompanyById(id);

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

   
    
    
    @GetMapping
    @Operation(summary = "Get all trading companies")
    public ResponseEntity<List<TradingCompanyResponse>> getAllTradingCompanies() {

        List<TradingCompanyResponse> companies = tradingCompanyService.getAllTradingCompanies();

        return ResponseEntity.status(HttpStatus.OK).body(companies);
    }


    
    @PutMapping("/{id}")
    @Operation(summary = "Update trading company")
    public ResponseEntity<TradingCompanyResponse> updateTradingCompany(@PathVariable Long id,
    						@Valid @RequestBody UpdateTradingCompanyRequest request) {

        TradingCompanyResponse response = tradingCompanyService.updateTradingCompany(id, request);

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }


    @DeleteMapping("/{id}")
    @Operation(summary = "Delete trading company")
    public ResponseEntity<String> deleteTradingCompany(@PathVariable Long id) {

        tradingCompanyService.deleteTradingCompany(id);

        return ResponseEntity.ok("Trading Company deleted successfully");
    }
    
    
 
}
