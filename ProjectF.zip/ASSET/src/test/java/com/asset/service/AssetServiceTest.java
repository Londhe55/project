package com.asset.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.asset.dto.AssetResponse;
import com.asset.dto.CreateAssetRequest;
import com.asset.dto.UpdateAssetRequest;
import com.asset.entity.Asset;
import com.asset.exception.DuplicateResourceException;
import com.asset.exception.ResourceNotFoundException;
import com.asset.mapper.AssetMapper;
import com.asset.repository.AssetRepository;

@ExtendWith(MockitoExtension.class)
public class AssetServiceTest {

	@Mock
	AssetMapper assetMapper;

	@InjectMocks
	AssetService assetService;

	@Mock
	AssetRepository assetRepository;

//	 Create Asset
	@Test
	void testCreateAsset() {

		CreateAssetRequest request = new CreateAssetRequest();

		request.setSymbol("TCS");

		Asset asset = new Asset();

		Asset savedAsset = new Asset();

		AssetResponse response = new AssetResponse();

		when(assetRepository.existsBySymbol("TCS")).thenReturn(false);

		when(assetMapper.toEntity(request)).thenReturn(asset);

		when(assetRepository.save(asset)).thenReturn(savedAsset);

		when(assetMapper.toResponse(savedAsset)).thenReturn(response);

		AssetResponse result = assetService.createAsset(request);

		assertNotNull(result);

		verify(assetRepository).save(asset);
	}

//    Duplicate Symbol
	@Test
	void testCreateAssetDuplicateSymbol() {

		CreateAssetRequest request = new CreateAssetRequest();

		request.setSymbol("TCS");

		when(assetRepository.existsBySymbol("TCS")).thenReturn(true);

		assertThrows(DuplicateResourceException.class, () -> assetService.createAsset(request));

		verify(assetRepository, never()).save(any());
	}

//    Get Asset By Id
	@Test
	void testGetAssetById() {

		Asset asset = new Asset();

		AssetResponse response = new AssetResponse();

		when(assetRepository.findById(1L)).thenReturn(Optional.of(asset));

		when(assetMapper.toResponse(asset)).thenReturn(response);

		AssetResponse result = assetService.getAssetById(1L);

		assertNotNull(result);
	}

//    Get Asset By Id Not Found
	@Test
	void testGetAssetByIdNotFound() {

		when(assetRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> assetService.getAssetById(1L));
	}

//    Get All Assets

	@Test
	void testGetAllAssets() {

		Asset asset = new Asset();

		AssetResponse response = new AssetResponse();

		when(assetRepository.findAll()).thenReturn(List.of(asset));

		when(assetMapper.toResponse(asset)).thenReturn(response);

		List<AssetResponse> result = assetService.getAllAssets();

		assertEquals(1, result.size());
	}

//    Update Asset
	@Test
	void testUpdateAsset() {

		Asset asset = new Asset();

		UpdateAssetRequest request = new UpdateAssetRequest();

		AssetResponse response = new AssetResponse();

		when(assetRepository.findById(1L)).thenReturn(Optional.of(asset));

		when(assetRepository.save(asset)).thenReturn(asset);

		when(assetMapper.toResponse(asset)).thenReturn(response);

		AssetResponse result = assetService.updateAsset(1L, request);

		assertNotNull(result);

		verify(assetMapper).updateEntity(asset, request);

		verify(assetRepository).save(asset);
	}

//    Update Asset Not Found
	@Test
	void testUpdateAssetNotFound() {

		UpdateAssetRequest request = new UpdateAssetRequest();

		when(assetRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> assetService.updateAsset(1L, request));
	}

//    Delete Asset
	@Test
	void testDeleteAsset() {

		Asset asset = new Asset();

		when(assetRepository.findById(1L)).thenReturn(Optional.of(asset));

		assetService.deleteAsset(1L);

		verify(assetRepository).delete(asset);
	}

//    Delete Asset Not Found

	@Test
	void testDeleteAssetNotFound() {

		when(assetRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> assetService.deleteAsset(1L));
	}
}
