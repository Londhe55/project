package com.asset.repository;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.asset.entity.Asset;





@DataJpaTest
public class AssetRepositoryTest {
	
	
	@Autowired
	private AssetRepository repository;
	
	
	// Test Case for Save Student
	@Test
	void testSaveAsset() {
		
		Asset asset = new Asset();
		
		asset.setName("ABC Corporation");
		asset.setSymbol("ABC");
		asset.setType("Stock");
		asset.setCurrentPrice(BigDecimal.valueOf(250.75));
		asset.setListedSince(LocalDate.now());
		
		Asset savedAsset = repository.save(asset);
		
		assertNotNull(savedAsset);
		assertNotNull(savedAsset.getId());
		
	}
	
	
	// Test case for Find Asset By Id
	@Test
	void testFindAssetById() {
		
		Asset asset = new Asset();
		asset.setName("ABC Corporation");
		asset.setSymbol("ABC");
		asset.setType("Stock");
		asset.setCurrentPrice(BigDecimal.valueOf(250.75));
		asset.setListedSince(LocalDate.now());
		
		Asset savedAsset = repository.save(asset);
		
		Optional<Asset> result = repository.findById(asset.getId());
		
		assertTrue(result.isPresent());
		assertEquals(result.get().getId(), savedAsset.getId());
		
	}
	
	
	// Test Case for Find All Asset 
	@Test
	void testFindAllAsset() {
		
		Asset asset = new Asset();
		
		asset.setName("ABC Corporation");
		asset.setSymbol("ABC");
		asset.setType("Stock");
		asset.setCurrentPrice(BigDecimal.valueOf(250.75));
		asset.setListedSince(LocalDate.now());
		
		Asset asset2 = new Asset();
		
		asset2.setName("DEF Corporation");
		asset2.setSymbol("DEF");
		asset2.setType("Stock");
		asset2.setCurrentPrice(BigDecimal.valueOf(250.75));
		asset2.setListedSince(LocalDate.now());
		
		repository.save(asset);
		repository.save(asset2);
		
		
		List<Asset> assets = repository.findAll();
		
		assertFalse(assets.isEmpty());
		assertTrue(assets.size() >= 2);
		
		
	}
	
	
	
//	Test Case For Update The Asset
	@Test
	void testUpdateAssetById() {
		
		Asset asset = new Asset();
		asset.setName("DEF Corporation");
		asset.setSymbol("DEF");
		asset.setType("Stock");
		asset.setCurrentPrice(BigDecimal.valueOf(250.75));
		asset.setListedSince(LocalDate.now());
		
		Asset savedAsset = repository.save(asset);
		
		asset.setType("Stock Type");
		asset.setSymbol("ABC");
		
		Asset save = repository.save(asset);
		
		assertEquals("ABC", save.getSymbol());
		assertEquals("Stock Type", save.getType());
		
		
	}
	
//	Test Case For Delete the Asset By Id
	@Test
	void testDeletAsseteByID() {
		
		Asset asset = new Asset();
		asset.setName("DEF Corporation");
		asset.setSymbol("DEF");
		asset.setType("Stock");
		asset.setCurrentPrice(BigDecimal.valueOf(250.75));
		asset.setListedSince(LocalDate.now());
		
		Asset savedAsset = repository.save(asset);
		
		repository.deleteById(asset.getId());
		
		Optional<Asset> result = repository.findById(asset.getId());
		
		assertFalse(result.isPresent());
	}
	

}
