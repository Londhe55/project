package com.asset.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.asset.dto.AssetResponse;
import com.asset.dto.CreateAssetRequest;
import com.asset.service.AssetService;
import com.asset.service.AssetService;

@WebMvcTest(AssetController.class)
public class AssetControllerTest {
	
	
	@Autowired
	MockMvc mockMvc;
	
	
	@MockitoBean
	private AssetService assetServiceImpl;
	
	
	@Autowired
	private ObjectMapper objectMapper;
	
	
	
	
	
	
	
	@Test
	void addAsset() throws Exception {

	    AssetResponse assetResponse = new AssetResponse();
	    
	    assetResponse.setId(1L);
	    assetResponse.setName("DEF Corporation");
	    assetResponse.setSymbol("DEF");
	    assetResponse.setCurrentPrice(BigDecimal.valueOf(1000));

	    when(assetServiceImpl.createAsset(any())).thenReturn(assetResponse);

	    CreateAssetRequest request = new CreateAssetRequest();

	    request.setName("ABC Corporation");
	    request.setSymbol("ABC");
	    request.setType("STOCK");
	    request.setCurrentPrice(BigDecimal.valueOf(250.75));
	    request.setListedSince(LocalDate.parse("2020-01-15"));

	    mockMvc.perform(post("/assets")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content(objectMapper.writeValueAsString(request)))
	            .andExpect(status().isCreated())
	            .andExpect(jsonPath("$.id").value(1))
	            .andExpect(jsonPath("$.name").value("DEF Corporation"))
	            .andExpect(jsonPath("$.symbol").value("DEF"))
	            .andExpect(jsonPath("$.currentPrice").value(1000));

	    verify(assetServiceImpl).createAsset(any());
	}
	
	
	
	
	@Test
	void getAssetByID() throws Exception {
		
		
		AssetResponse assetResponse = new AssetResponse();
	    
	    assetResponse.setId(1L);
	    assetResponse.setName("DEF Corporation");
	    assetResponse.setSymbol("DEF");
	    assetResponse.setCurrentPrice(BigDecimal.valueOf(1000));
		
		when(assetServiceImpl.getAssetById(1L)).thenReturn(assetResponse);
		
		mockMvc.perform(get("/assets/1"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id").value(1))
	            .andExpect(jsonPath("$.name").value("DEF Corporation"))
	            .andExpect(jsonPath("$.symbol").value("DEF"))
	            .andExpect(jsonPath("$.currentPrice").value(1000));
		
		verify(assetServiceImpl).getAssetById(1L);
	}
	
	
	
	
	
	@Test
	void getAssetAll() throws Exception {
		
		AssetResponse assetResponse = new AssetResponse();
	
	    assetResponse.setId(1L);
	    assetResponse.setName("DEF Corporation");
	    assetResponse.setSymbol("DEF");
	    assetResponse.setCurrentPrice(BigDecimal.valueOf(1000));
	    
	    
	    AssetResponse assetResponse2 = new AssetResponse();
	    
	    assetResponse2.setId(2L);
	    assetResponse2.setName("ABC Corporation");
	    assetResponse2.setSymbol("ABC");
	    assetResponse2.setCurrentPrice(BigDecimal.valueOf(10000));
		
		
		List<AssetResponse> results = List.of(assetResponse2, assetResponse);
		when(assetServiceImpl.getAllAssets()).thenReturn(results);
		
		mockMvc.perform(get("/assets"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id").value(2))
				.andExpect(jsonPath("$[0].name").value("ABC Corporation"))
				.andExpect(jsonPath("$[0].symbol").value("ABC"))
				.andExpect(jsonPath("$[0].currentPrice").value(10000))
				
				.andExpect(jsonPath("$[1].id").value(1))
				.andExpect(jsonPath("$[1].name").value("DEF Corporation"))
				.andExpect(jsonPath("$[1].symbol").value("DEF"))
				.andExpect(jsonPath("$[1].currentPrice").value(1000));
				
		
		verify(assetServiceImpl).getAllAssets();
	}
	
	
	
	
	
	
	
	
	
	@Test
	void updateAssetById() throws Exception {
		
		AssetResponse assetResponse = new AssetResponse();
		
	    assetResponse.setId(1L);
	    assetResponse.setName("DEF Corporation");
	    assetResponse.setSymbol("DEF");
	    assetResponse.setCurrentPrice(BigDecimal.valueOf(1000));
	    
	    
	    CreateAssetRequest request = new CreateAssetRequest();

	    request.setName("ABC Corporation");
	    request.setSymbol("ABC");
	    request.setType("STOCK");
	    request.setCurrentPrice(BigDecimal.valueOf(250.75));
	    request.setListedSince(LocalDate.parse("2020-01-15"));
		
		when(assetServiceImpl.updateAsset(eq(1L), any())).thenReturn(assetResponse);
		
		
		mockMvc.perform(put("/assets/1")
					.contentType(MediaType.APPLICATION_JSON)
					.content(objectMapper.writeValueAsBytes(request)))
					.andExpect(status().isOk())
					.andExpect(jsonPath("$.id").value(1))
					.andExpect(jsonPath("$.name").value("DEF Corporation"))
		            .andExpect(jsonPath("$.symbol").value("DEF"))
		            .andExpect(jsonPath("$.currentPrice").value(1000));

		
		verify(assetServiceImpl).updateAsset(eq(1L), any());
	}
	
	
	
	
	
	@Test
	void testDeleteByID() throws Exception {
		
		doNothing().when(assetServiceImpl).deleteAsset(1L);
		
		mockMvc.perform(delete("/assets/1"))
				.andExpect(status().isOk())
				.andExpect(content().string("Asset deleted successfully"));
		
		verify(assetServiceImpl).deleteAsset(1L);
		
	}
	
	

}
