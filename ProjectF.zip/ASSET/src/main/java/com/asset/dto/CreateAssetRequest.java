package com.asset.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CreateAssetRequest {

    @NotBlank(message = "Asset name is required")
    @Size(max = 150, message = "Asset name cannot exceed 150 characters")
    private String name;

    @NotBlank(message = "Asset symbol is required")
    @Size(max = 20, message = "Asset symbol cannot exceed 20 characters")
    private String symbol;

    @NotBlank(message = "Asset type is required")
    private String type;

    @NotNull(message = "Current price is required")
    @DecimalMin(value = "0.01", message = "Current price must be greater than 0")
    private BigDecimal currentPrice;

    @NotNull(message = "Listed since date is required")
    private LocalDate listedSince;

    public CreateAssetRequest() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(BigDecimal currentPrice) {
        this.currentPrice = currentPrice;
    }

    public LocalDate getListedSince() {
        return listedSince;
    }

    public void setListedSince(LocalDate listedSince) {
        this.listedSince = listedSince;
    }
}