package com.asset.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AssetResponse {

    private Long id;

    private String name;

    private String symbol;

    private String type;

    private BigDecimal currentPrice;

    private LocalDate listedSince;

    public AssetResponse() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(BigDecimal currentPrice) {
        this.currentPrice = currentPrice;
    }

    public LocalDate getListedSince() {
        return listedSince;
    }

    public void setListedSince(LocalDate listedSince) {
        this.listedSince = listedSince;
    }
}