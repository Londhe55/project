package com.asset.mapper;

import com.asset.dto.AssetResponse;
import com.asset.dto.CreateAssetRequest;
import com.asset.dto.UpdateAssetRequest;
import com.asset.entity.Asset;
import org.springframework.stereotype.Component;

@Component
public class AssetMapper {

    public Asset toEntity(CreateAssetRequest request) {

        Asset asset = new Asset();

        asset.setName(request.getName());
        asset.setSymbol(request.getSymbol());
        asset.setType(request.getType());
        asset.setCurrentPrice(request.getCurrentPrice());
        asset.setListedSince(request.getListedSince());

        return asset;
    }

    public void updateEntity(
            Asset asset,
            UpdateAssetRequest request) {

        asset.setName(request.getName());
        asset.setType(request.getType());
        asset.setCurrentPrice(request.getCurrentPrice());
        asset.setListedSince(request.getListedSince());
    }

    public AssetResponse toResponse(Asset asset) {

        AssetResponse response = new AssetResponse();

        response.setId(asset.getId());
        response.setName(asset.getName());
        response.setSymbol(asset.getSymbol());
        response.setType(asset.getType());
        response.setCurrentPrice(asset.getCurrentPrice());
        response.setListedSince(asset.getListedSince());

        return response;
    }
}