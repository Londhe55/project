package com.settlement.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.settlement.dto.TraderDTO;

@FeignClient(name = "TRADER")
public interface TraderClient {

    @GetMapping("/api/traders/{id}")
    TraderDTO getTraderById(@PathVariable("id") Long id);

}