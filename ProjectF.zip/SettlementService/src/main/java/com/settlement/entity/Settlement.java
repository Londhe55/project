package com.settlement.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name = "settlements")
public class Settlement {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "trade_order_id", nullable = false)
	private Long tradeOrderId;

	@Column(name = "settlement_date", nullable = false)
	private LocalDateTime settlementDate;

	@Column(name = "amount", nullable = false, precision = 10, scale = 2)
	private BigDecimal amount;

	@Column(name = "status", nullable = false, length = 50)
	private String status;

	@Column(name = "payment_reference", nullable = false, length = 100)
	private String paymentReference;

	public Settlement() {
	}

	public Settlement(Long id, Long tradeOrderId, LocalDateTime settlementDate, BigDecimal amount, String status,
			String paymentReference) {

		this.id = id;
		this.tradeOrderId = tradeOrderId;
		this.settlementDate = settlementDate;
		this.amount = amount;
		this.status = status;
		this.paymentReference = paymentReference;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTradeOrderId() {
		return tradeOrderId;
	}

	public void setTradeOrderId(Long tradeOrderId) {
		this.tradeOrderId = tradeOrderId;
	}

	public LocalDateTime getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(LocalDateTime settlementDate) {
		this.settlementDate = settlementDate;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPaymentReference() {
		return paymentReference;
	}

	public void setPaymentReference(String paymentReference) {
		this.paymentReference = paymentReference;
	}

	@Override
	public String toString() {
		return "Settlement [id=" + id + ", tradeOrderId=" + tradeOrderId + ", settlementDate=" + settlementDate
				+ ", amount=" + amount + ", status=" + status + ", paymentReference=" + paymentReference + "]";
	}
}