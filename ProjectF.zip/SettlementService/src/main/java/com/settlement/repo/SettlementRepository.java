package com.settlement.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.settlement.entity.Settlement;

@Repository
public interface SettlementRepository extends JpaRepository<Settlement, Long> {

}

