package com.settlement.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.settlement.dto.SettlementRequestDTO;
import com.settlement.dto.SettlementResponseDTO;
import com.settlement.entity.Settlement;
import com.settlement.exception.SettlementNotFoundException;
import com.settlement.exception.TraderNotFoundException;
import com.settlement.feign.TraderClient;
import com.settlement.mapper.SettlementMapper;
import com.settlement.repo.SettlementRepository;

@Service
public class SettlementService {

	@Autowired
	private SettlementRepository settlementRepository;

	@Autowired
	private TraderClient traderClient;

	@Autowired
	private SettlementMapper settlementMapper;

	
	// Create Settlement
	public SettlementResponseDTO createSettlement(SettlementRequestDTO request) {

		try {
			traderClient.getTraderById(request.getTradeOrderId());
		} catch (Exception e) {

			throw new TraderNotFoundException("Trader not found with id : " + request.getTradeOrderId());
		}

		Settlement settlement = settlementMapper.toEntity(request);

		Settlement saved = settlementRepository.save(settlement);

		return settlementMapper.toResponse(saved);
	}
	

	// Get Settlement By Id
	public SettlementResponseDTO getSettlementById(Long id) {

		Settlement settlement = settlementRepository.findById(id)
				.orElseThrow(() -> new SettlementNotFoundException("Settlement not found with id : " + id));

		return settlementMapper.toResponse(settlement);
	}

	
	
	// Get All Settlements
	public List<SettlementResponseDTO> getAllSettlements() {

		return settlementRepository.findAll().
									stream().map(settlementMapper::toResponse)
									.collect(Collectors.toList());
	}
	
	

	// Update Settlement
	public SettlementResponseDTO updateSettlement(Long id, SettlementRequestDTO request) {

		Settlement settlement = settlementRepository.findById(id)
				.orElseThrow(() -> new SettlementNotFoundException("Settlement not found with id : " + id));

		settlement.setTradeOrderId(request.getTradeOrderId());
		settlement.setSettlementDate(request.getSettlementDate());
		settlement.setAmount(request.getAmount());
		settlement.setStatus(request.getStatus());
		settlement.setPaymentReference(request.getPaymentReference());

		Settlement updated = settlementRepository.save(settlement);

		return settlementMapper.toResponse(updated);
	}

	
	
	
	// Delete Settlement
	public void deleteSettlement(Long id) {

		Settlement settlement = settlementRepository.findById(id)
				.orElseThrow(() -> new SettlementNotFoundException("Settlement not found with id : " + id));

		settlementRepository.delete(settlement);
	}
}