package com.settlement.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.settlement.dto.SettlementRequestDTO;
import com.settlement.dto.SettlementResponseDTO;
import com.settlement.service.SettlementService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/settlements")
public class SettlementController {

    @Autowired
    private SettlementService settlementService;

    

    @PostMapping
    @Operation(summary = "Create a new settlement")
    public ResponseEntity<SettlementResponseDTO>createSettlement(
                    @Valid @RequestBody SettlementRequestDTO request) {

        SettlementResponseDTO responseDTO = settlementService.createSettlement(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
    }

    
    
    @GetMapping
    @Operation(summary = "Retrieve all settlements")
    public ResponseEntity<List<SettlementResponseDTO>>getAllSettlements() {
    	
        List<SettlementResponseDTO> responseDTO = settlementService.getAllSettlements();

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    
    
    @GetMapping("/{id}")
    @Operation(summary = "Retrieve settlement by ID")
    public ResponseEntity<SettlementResponseDTO> getSettlementById(@PathVariable Long id) {

        SettlementResponseDTO responseDTO = settlementService.getSettlementById(id);

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    

    @PutMapping("/{id}")
    @Operation(summary = "Update settlement by ID")
    public ResponseEntity<SettlementResponseDTO> updateSettlement(@PathVariable Long id, 
    						@Valid @RequestBody SettlementRequestDTO request) {

        SettlementResponseDTO responseDTO = settlementService.updateSettlement(id,request);

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }
    



    @DeleteMapping("/{id}")
    @Operation(summary = "Delete settlement by ID")
    public ResponseEntity<String>deleteSettlement(@PathVariable Long id) {

        settlementService.deleteSettlement(id);

        return ResponseEntity.ok("Settlement deleted successfully");
    }
}