package com.settlement.advice;

import java.time.LocalDateTime;
import java.time.chrono.ChronoLocalDate;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.settlement.dto.ErrorResponse;
import com.settlement.exception.SettlementNotFoundException;
import com.settlement.exception.TraderNotFoundException;

import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SettlementNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(SettlementNotFoundException ex, HttpServletRequest request) {
        
    	ErrorResponse response = new ErrorResponse(
    			ex.getMessage(),
    			HttpStatus.NOT_FOUND.value(),
    			LocalDateTime.now(),
    			request.getRequestURI()
    			);
    	
    	return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    
    @ExceptionHandler(TraderNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleTraderNotFound(TraderNotFoundException ex, HttpServletRequest request) {
    	
    	ErrorResponse response = new ErrorResponse(
    			ex.getMessage(),
    			HttpStatus.NOT_FOUND.value(),
    			LocalDateTime.now(),
    			request.getRequestURI()
    			);
    	
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception ex, HttpServletRequest request) {
        
    	ErrorResponse response = new ErrorResponse(
    			ex.getMessage(),
    			HttpStatus.BAD_REQUEST.value(),
    			LocalDateTime.now(),
    			request.getRequestURI()
    			);
    	
    	
    	return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    	
    }
}
