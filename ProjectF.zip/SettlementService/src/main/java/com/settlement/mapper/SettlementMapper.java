package com.settlement.mapper;

import org.springframework.stereotype.Component;
import com.settlement.controller.SettlementController;
import com.settlement.dto.SettlementRequestDTO;
import com.settlement.dto.SettlementResponseDTO;
import com.settlement.entity.Settlement;

@Component
public class SettlementMapper {
	
	
	public Settlement toEntity(SettlementRequestDTO requestDTO) {
		
		Settlement settlement = new Settlement();
		
		settlement.setTradeOrderId(requestDTO.getTradeOrderId());
		settlement.setSettlementDate(requestDTO.getSettlementDate());
		settlement.setAmount(requestDTO.getAmount());
		settlement.setStatus(requestDTO.getStatus());
		settlement.setPaymentReference(requestDTO.getPaymentReference());
		
		return settlement;
		
	}

	
	public SettlementResponseDTO toResponse(Settlement settlement) {
		
		SettlementResponseDTO responseDTO = new SettlementResponseDTO();
		
		responseDTO.setId(settlement.getId());
		responseDTO.setTradeOrderId(settlement.getTradeOrderId());
		responseDTO.setSettlementDate(settlement.getSettlementDate());
		responseDTO.setAmount(settlement.getAmount());
		responseDTO.setStatus(settlement.getStatus());
		responseDTO.setPaymentReference(settlement.getPaymentReference());
		
		return responseDTO;
		
	}
}
