package com.settlement.repo;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.settlement.entity.Settlement;

@DataJpaTest
class SettlementRepositoryTest {

    @Autowired
    private SettlementRepository settlementRepository;

    
//    Test case for Save Student
    @Test
    void testSaveSettlement() {

        Settlement settlement = new Settlement();

        settlement.setTradeOrderId(5002L);
        settlement.setSettlementDate(LocalDateTime.now());
        settlement.setAmount(BigDecimal.valueOf(10000.00));
        settlement.setStatus("COMPLETED");
        settlement.setPaymentReference("PAY123");

        Settlement saved = settlementRepository.save(settlement);

        assertNotNull(saved);
        assertNotNull(saved.getId());
    }
    
    
//    Test Case for the Find Settlement By Id
    @Test
    void testFindSettlementById() {
    	
    	Settlement settlement = new Settlement();
    	
    	settlement.setTradeOrderId(20L);
    	settlement.setSettlementDate(LocalDateTime.now());
    	settlement.setAmount(BigDecimal.valueOf(10000.00));
    	settlement.setStatus("Completed");
    	settlement.setPaymentReference("Pay123");
    	
    	Settlement savedSettlement = settlementRepository.save(settlement);
    	
    	Optional<Settlement> result = settlementRepository.findById(savedSettlement.getId());
    	
    	assertTrue(result.isPresent());
    	assertEquals(savedSettlement.getId(), result.get().getId());
    }
    
   
//   Test Case for Find All Settlement 
    @Test
    void testFindAllSettlements() {

        Settlement settlement1 = new Settlement();

        settlement1.setTradeOrderId(5001L);
        settlement1.setSettlementDate(LocalDateTime.now());
        settlement1.setAmount(BigDecimal.valueOf(10000));
        settlement1.setStatus("COMPLETED");
        settlement1.setPaymentReference("PAY111");

        Settlement settlement2 = new Settlement();

        settlement2.setTradeOrderId(5002L);
        settlement2.setSettlementDate(LocalDateTime.now());
        settlement2.setAmount(BigDecimal.valueOf(20000));
        settlement2.setStatus("SETTLED");
        settlement2.setPaymentReference("PAY222");

        settlementRepository.save(settlement1);
        settlementRepository.save(settlement2);

        List<Settlement> settlements = settlementRepository.findAll();

        assertFalse(settlements.isEmpty());
        assertEquals(2, settlements.size());
    }
    
    
    
//	Test case for the delete the Settlement By id
    @Test
    void testDeleteSettlement() {

        Settlement settlement = new Settlement();

        settlement.setTradeOrderId(5002L);
        settlement.setSettlementDate(LocalDateTime.now());
        settlement.setAmount(BigDecimal.valueOf(10000));
        settlement.setStatus("COMPLETED");
        settlement.setPaymentReference("PAY123");

        Settlement saved =settlementRepository.save(settlement);

        settlementRepository.deleteById(saved.getId());

        Optional<Settlement> result =
                settlementRepository.findById(saved.getId());

        assertFalse(result.isPresent());
    }
    
    
//    Test Case for the Update Settlement By Id
    @Test
    void testUpdateSettlement() {

        // Create

        Settlement settlement = new Settlement();

        settlement.setTradeOrderId(5002L);
        settlement.setSettlementDate(LocalDateTime.now());
        settlement.setAmount(BigDecimal.valueOf(10000));
        settlement.setStatus("PENDING");
        settlement.setPaymentReference("PAY123");

        Settlement saved = settlementRepository.save(settlement);

        // Update

        saved.setStatus("COMPLETED");
        saved.setAmount(BigDecimal.valueOf(20000));
        
        Settlement updated = settlementRepository.save(saved);

        assertEquals("COMPLETED",updated.getStatus());
        assertEquals(BigDecimal.valueOf(20000), updated.getAmount());
    }
    
}