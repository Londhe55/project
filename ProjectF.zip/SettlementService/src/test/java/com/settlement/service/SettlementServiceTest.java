
package com.settlement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.settlement.dto.SettlementRequestDTO;
import com.settlement.dto.SettlementResponseDTO;
import com.settlement.entity.Settlement;
import com.settlement.exception.SettlementNotFoundException;
import com.settlement.exception.TraderNotFoundException;
import com.settlement.feign.TraderClient;
import com.settlement.mapper.SettlementMapper;
import com.settlement.repo.SettlementRepository;

@ExtendWith(MockitoExtension.class)
class SettlementServiceTest {

	@Mock
	private SettlementRepository settlementRepository;

	@Mock
	private SettlementMapper settlementMapper;

	@Mock
	private TraderClient traderClient;

	@InjectMocks
	private SettlementService settlementService;

	public SettlementServiceTest() {
		MockitoAnnotations.openMocks(this);
	}

//    Create Settlement Test
	@Test
	void testCreateSettlement() {

		SettlementRequestDTO request = new SettlementRequestDTO();

		request.setTradeOrderId(1L);

		Settlement settlement = new Settlement();

		Settlement savedSettlement = new Settlement();

		savedSettlement.setId(1L);

		SettlementResponseDTO response = new SettlementResponseDTO();

		response.setId(1L);

		when(traderClient.getTraderById(1L)).thenReturn(null);

		when(settlementMapper.toEntity(request)).thenReturn(settlement);

		when(settlementRepository.save(settlement)).thenReturn(savedSettlement);

		when(settlementMapper.toResponse(savedSettlement)).thenReturn(response);

		SettlementResponseDTO result = settlementService.createSettlement(request);

		assertNotNull(result);
		assertEquals(1L, result.getId());

		verify(settlementRepository).save(settlement);
	}

//    Create Settlement - Trader Not Found
	@Test
	void testCreateSettlementTraderNotFound() {

		SettlementRequestDTO request = new SettlementRequestDTO();

		request.setTradeOrderId(1L);

		when(traderClient.getTraderById(1L)).thenThrow(new RuntimeException());

		assertThrows(TraderNotFoundException.class, () -> settlementService.createSettlement(request));

		verify(settlementRepository, never()).save(any());
	}

//    Get Settlement By Id
	@Test
	void testGetSettlementById() {

		Settlement settlement = new Settlement();

		settlement.setId(1L);

		SettlementResponseDTO response = new SettlementResponseDTO();

		response.setId(1L);

		when(settlementRepository.findById(1L)).thenReturn(Optional.of(settlement));

		when(settlementMapper.toResponse(settlement)).thenReturn(response);

		SettlementResponseDTO result = settlementService.getSettlementById(1L);

		assertNotNull(result);
		assertEquals(1L, result.getId());
	}

//    Get Settlement By Id Not Found
	@Test
	void testGetSettlementByIdNotFound() {

		when(settlementRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(SettlementNotFoundException.class, () -> settlementService.getSettlementById(1L));
	}

//    Get All Settlements
	@Test
	void testGetAllSettlements() {

		Settlement settlement = new Settlement();

		SettlementResponseDTO response = new SettlementResponseDTO();

		when(settlementRepository.findAll()).thenReturn(List.of(settlement));

		when(settlementMapper.toResponse(settlement)).thenReturn(response);

		List<SettlementResponseDTO> result = settlementService.getAllSettlements();

		assertEquals(1, result.size());
	}

//    Update Settlement

	@Test
	void testUpdateSettlement() {

		SettlementRequestDTO request = new SettlementRequestDTO();

		request.setTradeOrderId(10L);

		Settlement settlement = new Settlement();

		settlement.setId(1L);

		SettlementResponseDTO response = new SettlementResponseDTO();

		response.setId(1L);

		when(settlementRepository.findById(1L)).thenReturn(Optional.of(settlement));

		when(settlementRepository.save(settlement)).thenReturn(settlement);

		when(settlementMapper.toResponse(settlement)).thenReturn(response);

		SettlementResponseDTO result = settlementService.updateSettlement(1L, request);

		assertNotNull(result);

		verify(settlementRepository).save(settlement);
	}

//    Update Settlement Not Found
	@Test
	void testUpdateSettlementNotFound() {

		SettlementRequestDTO request = new SettlementRequestDTO();

		when(settlementRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(SettlementNotFoundException.class, () -> settlementService.updateSettlement(1L, request));
	}

//    Delete Settlement
	@Test
	void testDeleteSettlement() {

		Settlement settlement = new Settlement();

		settlement.setId(1L);

		when(settlementRepository.findById(1L)).thenReturn(Optional.of(settlement));

		settlementService.deleteSettlement(1L);

		verify(settlementRepository).delete(settlement);
	}

//    Delete Settlement Not Found
	@Test
	void testDeleteSettlementNotFound() {

		when(settlementRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(SettlementNotFoundException.class, () -> settlementService.deleteSettlement(1L));
	}

}