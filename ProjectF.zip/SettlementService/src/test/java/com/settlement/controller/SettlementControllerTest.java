package com.settlement.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.settlement.controller.SettlementController;
import com.settlement.dto.SettlementRequestDTO;
import com.settlement.dto.SettlementResponseDTO;
import com.settlement.service.SettlementService;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.assertArg;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SettlementController.class)
class SettlementControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private SettlementService settlementService;

    @Autowired
    ObjectMapper objectMapper;
    


    @Test
    void testCreateSettlement() throws Exception {

    	
    	SettlementResponseDTO responseDTO = new SettlementResponseDTO();
    	
    	responseDTO.setId(1L);
    	responseDTO.setAmount(BigDecimal.valueOf(10000));
    	responseDTO.setStatus("Setteled");
    	responseDTO.setTradeOrderId(2L);
    	
    	when(settlementService.createSettlement(any())).thenReturn(responseDTO);
    	
    	
        SettlementRequestDTO request = new SettlementRequestDTO();
        
        request.setTradeOrderId(1L);
        request.setSettlementDate(LocalDateTime.now());
        request.setAmount(BigDecimal.valueOf(10000));
        request.setStatus("COMPLETED");
        request.setPaymentReference("PAY999");

        
        mockMvc.perform(post("/settlements")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                		.andExpect(status().isCreated())
                		.andExpect(jsonPath("$.id").value(1))
                		.andExpect(jsonPath("$.amount").value(10000))
                		.andExpect(jsonPath("$.status").value("Setteled"));
        
        verify(settlementService).createSettlement(any());
    }
    
    
    
    
    
    
    
    
// 	Test Case for Get Settlement By Id 
    @Test
    void testGetSettlementById() throws Exception {
    	
    	SettlementResponseDTO responseDTO = new SettlementResponseDTO();
    	
    	responseDTO.setId(1L);
    	responseDTO.setAmount(BigDecimal.valueOf(10000));
    	responseDTO.setStatus("Setteled");
    	responseDTO.setTradeOrderId(2L);
    	
    	when(settlementService.getSettlementById(1L)).thenReturn(responseDTO);
    	
    	mockMvc.perform(get("/settlements/1"))
    			.andExpect(status().isOk())
    			.andExpect(jsonPath("$.id").value(1))
    			.andExpect(jsonPath("$.amount").value(10000))
    			.andExpect(jsonPath("$.status").value("Setteled"))
    			.andExpect(jsonPath("$.tradeOrderId").value(2));

    			
    	verify(settlementService).getSettlementById(1L);
    }
    
    
//    Test Case for Getting All the Settlements
    @Test
    void testGetAllSettlement() throws Exception {
    	
    	SettlementResponseDTO responseDTO = new SettlementResponseDTO();
    	
    	responseDTO.setId(1L);
    	responseDTO.setAmount(BigDecimal.valueOf(10000));
    	responseDTO.setStatus("Setteled");
    	responseDTO.setTradeOrderId(2L);
    	
    	SettlementResponseDTO responseDTO2 = new SettlementResponseDTO();
    	
    	responseDTO2.setId(2L);
    	responseDTO2.setAmount(BigDecimal.valueOf(1000));
    	responseDTO2.setStatus("Setteled");
    	responseDTO2.setTradeOrderId(5L);
    	
    	List<SettlementResponseDTO> results = List.of(responseDTO, responseDTO2);
    	
    	when(settlementService.getAllSettlements()).thenReturn(results);
    	
    	mockMvc.perform(get("/settlements"))
    			.andExpect(status().isOk())
    			.andExpect(jsonPath("$[0].id").value(1))
    			.andExpect(jsonPath("$[0].amount").value(10000))
    			.andExpect(jsonPath("$[0].status").value("Setteled"))
    			.andExpect(jsonPath("$[0].tradeOrderId").value(2))
    			
    			.andExpect(jsonPath("$[1].id").value(2))
    			.andExpect(jsonPath("$[1].amount").value(1000))
    			.andExpect(jsonPath("$[1].status").value("Setteled"))
    			.andExpect(jsonPath("$[1].tradeOrderId").value(5));
    			
    	
    	verify(settlementService).getAllSettlements();
    }
    
    
    

    
    
    @Test
    void testUpdateSettlementById() throws Exception {
    	
    	SettlementResponseDTO responseDTO = new SettlementResponseDTO();
    	
    	responseDTO.setId(1L);
    	responseDTO.setAmount(BigDecimal.valueOf(10000));
    	responseDTO.setStatus("Setteled");
    	responseDTO.setTradeOrderId(2L);
    	
    	when(settlementService.updateSettlement(eq(1L), any())).thenReturn(responseDTO);
    	
    	SettlementRequestDTO dto = new SettlementRequestDTO();
    	
    	dto.setTradeOrderId(1L);
        dto.setSettlementDate(LocalDateTime.now());
        dto.setAmount(BigDecimal.valueOf(10000));
        dto.setStatus("COMPLETED");
        dto.setPaymentReference("PAY999");
    	

    	mockMvc.perform(put("/settlements/1")
    			.contentType(MediaType.APPLICATION_JSON)
    			.content(objectMapper.writeValueAsBytes(dto)))
    			.andExpect(status().isOk())
    			.andExpect(jsonPath("$.id").value(1))
    			.andExpect(jsonPath("$.amount").value(10000))
    			.andExpect(jsonPath("$.status").value("Setteled"))
    			.andExpect(jsonPath("$.tradeOrderId").value(2));
    			
    	
    	verify(settlementService).updateSettlement(eq(1L), any());
    }
    
    
    
    
  
//    Test Case for the Deleting the Settlement By Id
    @Test
    void testDeleteSettlementById() throws Exception {

        doNothing().when(settlementService).deleteSettlement(1L);

        mockMvc.perform(delete("/settlements/1"))
                .andExpect(status().isOk());

        verify(settlementService).deleteSettlement(1L);
    }
}
