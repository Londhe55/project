package com.training;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.MyConifg;
import com.training.service.AccountService;
import com.training.service.CalculatorService;

public class App 
{
    public static void main( String[] args )
    {
       
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConifg.class);
    	
    	
    	AccountService service = context.getBean(AccountService.class);
    	
    	System.out.println(service.deposite(2000));
    	
    	
    	
    	System.out.println(service.withdrw(200));
    	
    	
    	CalculatorService cs = (CalculatorService) context.getBean("calculatorService");
    	
    	
    	System.out.println(cs.add(10, 20));
    	
    	System.out.println(cs.Sub(10, 5));
    	
    	
    }
}
