package com.training.aspect;
 
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
 
@Aspect
@Component
public class PerformanceAspect {
 
	
	@Around("execution(* com.training.service.AccountService.*(..))")
	
	public Object f1(ProceedingJoinPoint jp) {
		
		long start=System.currentTimeMillis();
		Object obj=null;
		try {
			 obj=jp.proceed();
			
		} catch (Throwable e) {
			
			e.printStackTrace();
		}
		
		long executionTime=System.currentTimeMillis()-start;
		System.out.println("It tooks "+executionTime+" ms");
		return obj;
	}
}