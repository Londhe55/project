package com.training.aspect;

import org.aopalliance.intercept.Joinpoint;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyAspect1 {
	
	
	// 
	@Before("execution(* com.training.service.CalculatorService.*(..))")
	public void f1(JoinPoint jp) {
		
		Object[] args = jp.getArgs(); 
		Object target = jp.getTarget();
		System.out.println(target + "is invoked with " + args[0] + "," + args[1]);
	}
	
	
	// After Advice
	@After("execution(* com.training.service.CalculatorService.*(..))")   // PointCut
	public void f2(JoinPoint jp) {
		
		Object[] args = jp.getArgs(); 
		Object target = jp.getTarget();
		System.out.println("After");
		System.out.println(target + "is invoked with " + args[0] + "," + args[1]);
	}

}
