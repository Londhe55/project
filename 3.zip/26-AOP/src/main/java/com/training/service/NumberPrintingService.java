package com.training.service;

import java.util.Iterator;

public class NumberPrintingService {
	
	public void print(int upto) {
		for (int i = 0; i <= upto; i++) {
			System.out.println(i);
			
		}
	}

}
