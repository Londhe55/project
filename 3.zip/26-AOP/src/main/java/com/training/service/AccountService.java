package com.training.service;

import org.springframework.stereotype.Service;

@Service
public class AccountService {
	
	
	double balance = 10000;
	
	public double deposite(double amount) {
		
		balance += amount;
		return  balance;
	}
	
	public double withdrw(double amount) {
		
		balance -= amount;
		return  balance;
	}
	
	

}
