package com.training.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorService {
	
	public int add(int a, int b) {
		
		int c = a+b;
		
		return c;
		
	}
	

	public int Sub(int a, int b) {
		int c = a+b;
		
		return c;
	}
	
	
	

}
