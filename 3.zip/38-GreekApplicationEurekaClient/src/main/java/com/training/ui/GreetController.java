package com.training.ui;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/greetapi")
public class GreetController 
{
	@GetMapping("/greet")
 public String f1()
 {
	 return  "Greet";
 }
}
