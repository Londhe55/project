package com.training.ui;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/greetapi")
public class GreetController 
{

	@GetMapping("/greet/{name}")
	public String f1(@PathVariable String name)
	{
		return name.toUpperCase()+" How are you? ";
	}
	
	
	@GetMapping("/sum/{a}/{b}")
	public int calculate(@PathVariable int a, @PathVariable int b) {
	    return a + b;
	}
	
	@GetMapping("/add")
	public int sum(@RequestParam int a, @RequestParam int b) {
		return a+b;
	}
}

































//
//Option 1: Passing them as Path Variables (Recommended for REST hierarchy)
//If Service B's endpoint looks like /greet/{a}/{b}, you should construct your URL using path segments.
//
//Service A (Your current service):
//
//Java
//String url = "http://localhost:9090/greetapi/greet/" + a + "/" + b;
//int result = restTemplate.getForObject(url, Integer.class);
//Service B (The target service):
//
//Java
//@GetMapping("/greetapi/greet/{a}/{b}")
//public int handleGreet(@PathVariable int a, @PathVariable int b) {
//    // Service B's logic
//    return a + b; 
//}
//Option 2: Passing them as Query Parameters
//If Service B expects them as standard request parameters (like ?a=5&b=10), you need to format the URL query string.
//
//Service A (Your current service):
//
//Java
//String url = "http://localhost:9090/greetapi/greet?a=" + a + "&b=" + b;
//int result = restTemplate.getForObject(url, Integer.class);
//Service B (The target service):
//
//Java
//@GetMapping("/greetapi/greet")
//public int handleGreet(@RequestParam int a, @RequestParam int b) {
//    return a + b;