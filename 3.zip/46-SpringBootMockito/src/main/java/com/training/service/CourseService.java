package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.db.CourseRepository;
import com.training.model.Course;

@Service
public class CourseService {
	
	@Autowired
	CourseRepository repository;
	
	
	
	public List<Course> getAllCourses() {
		return this.repository.findAll();
		
	}
	
	public Course getOneCourse(int id) {
		return this.repository.findById(id).get();
	}

}
