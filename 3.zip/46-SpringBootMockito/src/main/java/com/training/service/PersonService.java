package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.db.PersonRepository;
import com.training.model.Person;

@Service
public class PersonService {
	
	
	@Autowired
	PersonRepository repository;
	
	public List<Person> getAllPersons() {
		return this.repository.findAll();
		
	}
	
	
	
	
	
	

}
