package com.training.ui;

import com.training.db.PersonRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PersonController {

    private final PersonRepository personRepository;


    PersonController(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }
	
	
	@GetMapping("/hello")
	public String f1() {
		return "hello World";
	}
	
	
	@GetMapping("/greet")
	public String f2() {
		return "Hello How Are You ? ";
		
	}
	

}
