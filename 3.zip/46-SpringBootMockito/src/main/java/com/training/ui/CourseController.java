package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Course;
import com.training.service.CourseService;

@RestController
@RequestMapping("/api")
public class CourseController {
	
	@Autowired
	CourseService courseService;
	
	
	@GetMapping("/find/{id}")
	public Course f1(@PathVariable int id) {
		
		return  this.courseService.getOneCourse(id);
		
	}
	

}
