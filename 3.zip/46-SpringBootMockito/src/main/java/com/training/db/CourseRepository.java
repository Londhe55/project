package com.training.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.model.Course;

public interface CourseRepository extends JpaRepository<Course, Integer>{

}
