package com.training.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.db.CourseRepository;
import com.training.db.PersonRepository;
import com.training.model.Course;
import com.training.model.Person;

@ExtendWith(MockitoExtension.class)
public class CourseServiceTest {
	
	
	@Mock
	CourseRepository repository;
	
	@InjectMocks
	CourseService service;
	
	
	
	@Test
	public void findALlTesting() {
		Course course1 = new Course(1, "Java", 20);
		Course course2 = new Course(2, "Python", 10);
		Course course3 = new Course(3, "Spring", 25);
		
		
// 		You can use below code also  for this line --> given(this.repository.findAll()).willReturn(List.of(course1, course2,course3));
//		List<Course> allCourses = new LinkedList<>();
//		allCourses.add(course1);
//		allCourses.add(course2);
//		allCourses.add(course3);
		
		given(this.repository.findAll()).willReturn(List.of(course1, course2,course3));
		
		List<Course> courses = this.service.getAllCourses();
		
		assertThat(courses).isNotNull();
		assertThat(courses.size()).isEqualTo(3);
		verify(this.repository).findAll();
		
		
	}

}
