package com.training.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import static org.mockito.BDDMockito.verify;

import java.util.List;

import com.training.db.PersonRepository;
import com.training.model.Person;

@ExtendWith(MockitoExtension.class)
public class PersonServiceTest {
	
	@Mock
	PersonRepository repository;
	
	@InjectMocks
	PersonService service;
	
	
	
	@Test
	public void findALlTesting() {
		Person person1 = new Person(1, "Kiran", "Delhi");
		Person person2 = new Person(2, "Ram", "Pune");
		
		given(this.repository.findAll()).willReturn(List.of(person1,person2));
		
		List<Person> persons = this.service.getAllPersons();
		
		assertThat(persons).isNotNull();
		assertThat(persons.size()).isEqualTo(2);
		verify(this.repository.count());
		
		
	}

}
