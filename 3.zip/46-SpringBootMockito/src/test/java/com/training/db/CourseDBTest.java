package com.training.db;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.training.model.Course;
import com.training.model.Person;

@DataJpaTest
public class CourseDBTest {
	
	@Autowired
	CourseRepository repository;
	
	@Test
	public void insertTesting() {		
		Course course = new Course("Sham", 10);
		repository.save(course);
		boolean exist = this.repository.existsById(course.getId());
		assertThat(exist).isTrue();
		
		
	}

}
