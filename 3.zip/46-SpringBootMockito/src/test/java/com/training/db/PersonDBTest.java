package com.training.db;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.jdbc.DataJdbcTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.training.model.Person;

@DataJpaTest
public class PersonDBTest {

	@Autowired
	PersonRepository repository;
	
	@Test
	public void insertTesting() {		
		Person person = new Person("Kiran", "Mumbai");
		repository.save(person);
		boolean exist = this.repository.existsById(person.getPersonId());
		assertThat(exist).isTrue();
		
		
	}
}
