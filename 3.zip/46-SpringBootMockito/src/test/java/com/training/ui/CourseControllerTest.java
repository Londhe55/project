package com.training.ui;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.training.db.CourseRepository;
import com.training.db.PersonRepository;
import com.training.model.Course;
import com.training.service.CourseService;
import com.training.service.PersonService;

@WebMvcTest(value = CourseController.class)
public class CourseControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	
	@Mock
	CourseService service;
	
	
	
	
	@Test
	public void doTest() throws Exception{
		
		when(service.getOneCourse(1)).thenReturn(new Course(1, "Spring", 30));
		
		mockMvc.perform(get("/api/find/1"))
				.andExpect(status().isOk());
				
	}
	
	
	

}
