package com.training.ui;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.training.db.PersonRepository;
import com.training.service.PersonService;


@WebMvcTest(value = PersonController.class)
public class HelloTester {
	
	@Autowired
	private MockMvc mockMvc;
	
	
	@MockitoBean
	private PersonService service;
	
	@MockitoBean
	private PersonRepository repository;
	
	
	@Test
	public void doTest() throws Exception{
		
		mockMvc.perform(get("/api/hello"))
		.andExpect(status().isOk())
		.andExpect(content().string("hello World"));	
	}
	
	
	@Test
	public void doTestGreet() throws Exception{
		
		mockMvc.perform(get("/api/greet"))
		.andExpect(status().isOk())
		.andExpect(content().string("Hello How Are You ? "));
	}
	
	

}
