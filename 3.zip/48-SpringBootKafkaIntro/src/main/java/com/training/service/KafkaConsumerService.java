package com.training.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {

	
	@KafkaListener(topics = "demo_topic", groupId = "group-id")
	public void consume(String message) {
		System.out.println("Message Received : "+ message);
	}
}
