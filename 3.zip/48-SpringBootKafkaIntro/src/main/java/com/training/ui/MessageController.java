package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.service.KafkaProducerService;

@RestController
@RequestMapping("/api")
public class MessageController {

	
	@Autowired
	KafkaProducerService producerService;
	
	@GetMapping("/send/{message}")
	public String f1(@PathVariable(name = "message") String message) {
		this.producerService.sendMessage(message);
		return "Sent Successfully";
	}

}
