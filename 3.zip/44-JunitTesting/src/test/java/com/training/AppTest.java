package com.training;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.training.model.Employee;

/**
 * Unit test for simple App.
 */
public class AppTest {

	
	@Test
	public void shouldAnswerWithTrue() {
		assertTrue(true);
	}

	
}
