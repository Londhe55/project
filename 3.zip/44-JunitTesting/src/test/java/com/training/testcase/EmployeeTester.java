package com.training.testcase;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import com.training.model.Employee;



public class EmployeeTester {
	
	Employee employee;
	
	
	@BeforeEach
	public void setUp() {
		employee = new Employee();
		employee.setBasic(10000.00);
	}
	
	@AfterEach
	public void cleanup() {
		employee = null;
	}
	
	
	@BeforeAll
	public void f1() {
		System.out.println("This code Executes Once");
	}
	
	
	@BeforeEach
	public void f2() {
		System.out.println("this code executes After All");
	}
	
	@Test
	public void testForAGrade() {
		
		employee.setGrade('A');
		
		double expectedAllowence = 5000;
		
		double actualAllowence = employee.computeAllowence();
		
		Assertions.assertEquals(expectedAllowence, actualAllowence);
		
		
	}
	
	@Test
	public void testForBGrade() {
		
		employee.setGrade('B');
		double expectedAllowence = 2500;
		double actualAllowence = employee.computeAllowence();
		Assertions.assertEquals(expectedAllowence, actualAllowence);
		
	}
	
	
	@Test
	public void testForCGrade() {
		
		employee.setGrade('C');
		double expectedAllowence = 1000;
		double actualAllowence = employee.computeAllowence();
		Assertions.assertEquals(expectedAllowence, actualAllowence);
		
		
	}

}
