package com.training.model;


public class Employee {
	
	String name;
	double basic;
	char grade;
	public Employee(String name, double basic, char grade) {
		super();
		this.name = name;
		this.basic = basic;
		this.grade = grade;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBasic() {
		return basic;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	public char getGrade() {
		return grade;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	
	
	public double computeAllowence() {
		
		if(this.grade == 'A') {
			return this.basic*0.5;
		}
		if (this.grade == 'B') {
			return this.basic*0.25;
		}
		if (this.grade == 'C') {
			return this.basic*0.10;
		}
		
		return 0.0;
	}
	public Employee() {
		super();
	}

}
