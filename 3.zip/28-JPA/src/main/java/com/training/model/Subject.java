package com.training.model;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "course_subjects")
public class Subject {
	
	
	@Id
	int subjectId;
	
	@Column
	String subjectName;
	
	
	@Column
	int duration;


	@ManyToOne(cascade = CascadeType.ALL)
	Course course;


	public Subject(int subjectId, String subjectName, int duration) {
		super();
		this.subjectId = subjectId;
		this.subjectName = subjectName;
		this.duration = duration;
		
	}


	public Subject() {
		super();
	}


	@Override
	public String toString() {
		return "\n Subject [subjectId=" + subjectId + ", subjectName=" + subjectName + ", duration=" + duration + "]";
	}


	public int getSubjectId() {
		return subjectId;
	}


	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}


	public String getSubjectName() {
		return subjectName;
	}


	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	public Course getCourse() {
		return course;
	}


	public void setCourse(Course course) {
		this.course = course;
	}
	
	
	
	
	
	
	
	
	

}
