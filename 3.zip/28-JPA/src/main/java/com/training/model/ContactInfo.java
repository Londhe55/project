package com.training.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "contactInfo")
public class ContactInfo {
	
	@Id
	
	int contactid;
	
	@Column
	String email;
	
	@Column
	String phone;

	@OneToOne(cascade = CascadeType.ALL, mappedBy = "contactInfo")   // using the mapped By we can create the bidirectional relation
	Person person;

	public ContactInfo(int contactid, String email, String phone, Person person) {
		super();
		this.contactid = contactid;
		this.email = email;
		this.phone = phone;
		this.person = person;
	}

	public ContactInfo() {
		super();
	}

	public int getContactid() {
		return contactid;
	}

	public void setContactid(int contactid) {
		this.contactid = contactid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	
	// Here person is avoide because of cyclic process person --> contactinfo  then contactinfo --> person
	@Override
	public String toString() {
		return "ContactInfo [contactid=" + contactid + ", email=" + email + ", phone=" + phone + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
