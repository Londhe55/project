package com.training.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name =  "courses")
public class Course {
	
	
	
	@Id
	int courseId;
	
	@Column
	String courseName;
	
	@Column
	double courseFees;
	
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "course")     // while storing and retriving and removing both tables changed
	List<Subject> subjectList = new ArrayList<>();


	public Course(int courseId, String courseName, double courseFees) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.courseFees = courseFees;
		
	}


	public Course() {
		super();
	}


	public int getCourseId() {
		return courseId;
	}


	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}


	public String getCourseName() {
		return courseName;
	}


	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}


	public double getCourseFees() {
		return courseFees;
	}


	public void setCourseFees(double courseFees) {
		this.courseFees = courseFees;
	}


	public List<Subject> getSubjectList() {
		return subjectList;
	}


	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}


	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", courseFees=" + courseFees
				+ ", subjectList=" + subjectList + "]";
	}
	
	
	
	
	
	public void addSubject(int id, String subjectName, int duration) {
		
		if(subjectList == null) {
			subjectList = new ArrayList<>();
			
		}
		
		subjectList.add(new Subject(id, subjectName, duration));
		
	}
	
	
	
	

}
