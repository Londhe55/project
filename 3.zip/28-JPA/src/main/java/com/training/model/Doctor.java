package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "doctors")
public class Doctor {
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	
	@Column
	String name;
	
	@Column
	String specility;
	
	@Column
	double fees;

	
	@Column
	String gender;


	public Doctor(String name, String specility, double fees, String gender) {
		super();
		this.name = name;
		this.specility = specility;
		this.fees = fees;
		this.gender = gender;
	}


	public Doctor() {
		super();
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getSpecility() {
		return specility;
	}


	public void setSpecility(String specility) {
		this.specility = specility;
	}


	public double getFees() {
		return fees;
	}


	public void setFees(double fees) {
		this.fees = fees;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	@Override
	public String toString() {
		return "\n Doctor [id=" + id + ", name=" + name + ", specility=" + specility + ", fees=" + fees + ", gender="
				+ gender + "]";
	}
	
	
	
	
	

}
