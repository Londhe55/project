package com.training;

import java.util.List;

import com.training.model.Doctor;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Main3 {
	
	static void insert() {
		
		Doctor d1 = new Doctor("Prabha", "ENT", 500, "Female");
		Doctor d2 = new Doctor("Banu", "General", 400, "Female");
		Doctor d3 = new Doctor("John", "Ortho", 800, "Male");
		Doctor d4 = new Doctor("Suresh", "General", 700, "Male");
		Doctor d5 = new Doctor("Wasin", "Ortho", 1200, "Male");
		Doctor d6 = new Doctor("Siddharth", "ENT", 500, "Male");
		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		
		em.getTransaction().begin();
		em.persist(d1);
		em.persist(d2);
		em.persist(d3);
		em.persist(d4);
		em.persist(d5);
		em.persist(d6);
		em.getTransaction().commit();
		
		em.close();
		emf.close();

	}
	
	
	static void readAll() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		String qry = "select d from Doctor d";
		
		Query query = em.createQuery(qry);
		
		
		List<Doctor> allDoctors = query.getResultList();
		System.out.println(allDoctors);
		
	}
	
	
		static void readFees() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		// JPQL Query
		
//		String qry = "select d from Doctor d where d.fees = 500";   // Hardcodded
		
		String qry = "select d from Doctor d where d.fees>:cutoff";

		
		Query query = em.createQuery(qry);
		
		query.setParameter("cutoff", 1000);
		List<Doctor> allDoctors = query.getResultList();
		System.out.println(allDoctors);
		
	}
		
		
		static void readOrtho() {
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
//			String qry = "select d from Doctor d where d.fees = 500";   // Hardcodded
			
			String qry = "select d from Doctor d where d.specility:cutoff";

			
			Query query = em.createQuery(qry);
			
			query.setParameter("cutoff", "ortho");
			List<Doctor> allDoctors = query.getResultList();
			System.out.println(allDoctors);
			
		}
		
		static void readAllMale() {
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
//			String qry = "select d from Doctor d where d.fees = 500";   // Hardcodded
			
			String qry = "select d from Doctor d where d.gender:cutoof";

			
			Query query = em.createQuery(qry);
			
			query.setParameter("cutoff", "ortho");
			List<Doctor> allDoctors = query.getResultList();
			System.out.println(allDoctors);
			
		}
		
		
		static void readAll4() {
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
			// JPQL Query
			
//			String qry = "select d from Doctor d where d.fees = 500";   // Hardcodded
			
			
			// This is called ==> Native Query and we use method createNativeQuery to execute
			String qry = "select * from Doctors";

			
			Query query = em.createNativeQuery(qry, Doctor.class);
			
			
			List<Doctor> allDoctors = query.getResultList();
			System.out.println(allDoctors);		
			
			
		}
		
	
		

	
	public static void main(String[] args) {
		
//		insert();
		
//		readAll();
		
//		readFees();
		
//		readOrtho();

		
		readAll4();
		
		
		
	}

}
