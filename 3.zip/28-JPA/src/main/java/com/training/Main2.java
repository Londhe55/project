package com.training;

import java.util.stream.IntStream;

import com.training.model.Course;
import com.training.model.Subject;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main2 {
	
	static void insert() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		
		Course course = new Course(1, "java Backend", 10000.00);
		Subject s1 = new Subject(6001, "Java", 12);
		Subject s2 = new Subject(6002, "AI", 32);
		Subject s3 = new Subject(6003, "JPA", 20);
		Subject s4 = new Subject(6004, "JDBC", 17);
		
		course.getSubjectList().add(s1);
		course.getSubjectList().add(s2);
		course.getSubjectList().add(s3);
		course.getSubjectList().add(s4);
		
		
		s1.setCourse(course);
		s2.setCourse(course);
		s3.setCourse(course);
		s4.setCourse(course);
		
		
		
		
		
		em.getTransaction().begin();
		em.persist(course);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	static void read1() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Subject subject = em.find(Subject.class, 6002);
		
		System.out.println(subject.getSubjectName());
		System.out.println(subject.getDuration());
		System.out.println(subject.getCourse().getCourseName());
		System.out.println(subject.getCourse().getCourseFees());
		System.out.println(subject.getCourse().getCourseId());
		
		em.close();
		emf.close();
		
		
	}
	
	
	
	static void read2() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		 Course course = em.find(Course.class, 1);
		
		System.out.println(course.getCourseName());
		System.out.println(course.getCourseFees());
		System.out.println(course.getSubjectList());
		
		course.getSubjectList().stream().forEach(s -> System.out.println(s));
		
		
		System.out.println("Total Subjects");
		System.out.println(course.getSubjectList().stream().count());
		
		System.out.println("Total Duration for All Subjects");
		long totalduration = course.getSubjectList().stream().mapToInt(s -> s.getDuration()).sum();
		
		System.out.println(totalduration);
		
		em.close();
		emf.close();
		
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
//		insert();
		
//		read1();
		
		read2();
		
		
	}

}
