package com.training;

import java.beans.PersistenceDelegate;

import com.training.model.ContactInfo;
import com.training.model.Person;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class App {
	
	static void insert() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		
		Person person = new Person(1001, "Sri ram", 20, null);
		ContactInfo contactInfo = new ContactInfo(5001, "sri@gmail.com", "18789883909", person);
		
		em.getTransaction().begin();
		em.persist(person);                      // you can use both person and contactInfo
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	static void read1() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		
		Person person = em.find(Person.class, 1001);
		System.out.println(person.getContactInfo().getEmail());
		System.out.println(person.getContactInfo().getPhone());
		
		
		
		
		em.close();
		emf.close();
	}
	
    public static void main(String[] args) {
    	
    	
    	
//    	insert();
    	
    	read1();
    }
}
