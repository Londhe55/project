package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api")
public class MyController
{
	@Autowired
   RestTemplate template;
	
	@GetMapping("/result")
	public String f1()
	{
		String url_1="http://38-GREEKAPPLICATIONEUREKACLIENT/greetapi/greet";
		String result1=this.template.getForObject(url_1, String.class);
		
		String url_2="http://39-HELLOAPPLICATIONEUREKACLIENT/helloapi/hello";
		String result2=this.template.getForObject(url_2, String.class);
		
		return result1+" "+result2;
	}
}
