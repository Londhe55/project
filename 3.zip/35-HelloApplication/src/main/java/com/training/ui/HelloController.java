package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/helloapi")
public class HelloController {
	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/hello")
	public String f1(@RequestParam(name="name")String name) {
		String url = "http://localhost:9090/greetapi/greet/"+name;
		String result = restTemplate.getForObject(url, String.class);
		return "Hello " + result;
	}
	
//	@GetMapping("/hello")
//	public String f2(@PathVariable(name="name")String name) {
//		String url = "http://localhost:9090/greetapi/greet/"+name;
//		String result = restTemplate.getForObject(url, String.class);
//		return "Hello" + result;
//	}
	
	
	
	@GetMapping("/sum")
	public int sum(@RequestParam int a, @RequestParam int b) {
	    String url = "http://localhost:9090/greetapi/sum/" + a + "/" + b;
	    int result = restTemplate.getForObject(url, Integer.class);
	    return result;
	}
	
	
	@GetMapping("/add")
	public int add(@RequestParam int a, @RequestParam int b) {
		String url = "http://localhost:9090/greetapi/add?a=" + a + "&b=" + b;
		int result = restTemplate.getForObject(url, Integer.class);
	    return result;
	}
}
