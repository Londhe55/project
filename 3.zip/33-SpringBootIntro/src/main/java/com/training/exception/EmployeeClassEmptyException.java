package com.training.exception;

public class EmployeeClassEmptyException extends Exception{

	public EmployeeClassEmptyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeClassEmptyException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EmployeeClassEmptyException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmployeeClassEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmployeeClassEmptyException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
