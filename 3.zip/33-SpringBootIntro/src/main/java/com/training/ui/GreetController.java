package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.service.GreetService;

@RestController
@RequestMapping("/greetapi")
public class GreetController {
	
	@Autowired
	GreetService gs;
	
	@GetMapping("/greet/{nm}")
	public String f1(@PathVariable(name="nm") String name) {
		return this.gs.sayHello(name);
	}
	
	

}
