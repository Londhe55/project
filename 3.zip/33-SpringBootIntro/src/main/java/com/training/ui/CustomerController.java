package com.training.ui;

import java.security.PublicKey;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Customer;
import com.training.service.CustomerService;

// add annotation
@RestController
@RequestMapping("/customer")
public class CustomerController {
	// fill code
	
	@Autowired
	CustomerService service;
	
	@PostMapping("/saveCustomer")
	public Customer saveCustomer(@RequestBody Customer customer) {
		return this.service.saveCustomer(customer);
		
	}
	
	
	@GetMapping("/read")
	public List<Customer> readAll(){
		return this.service.readAllCustomer();
	}
	
	
	@GetMapping("/read/{id}")
	public Customer readById(@PathVariable int id) {
		return this.service.readCustomerById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteById(@PathVariable int id) {
		return this.service.deleteCustomerById(id);
	}
	
	@PutMapping("/update")
	public Customer updateCustomer(@RequestBody Customer customer) {
		return this.service.updateCustomer(customer);
		
	}
}
