package com.training.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.exception.EmployeeClassEmptyException;
import com.training.exception.EmployeeNotFoundException;
import com.training.model.Employee;
import com.training.service.EmployeeService;

@RestController
@RequestMapping("/employeeapi")
public class EmployeeController {

	@Autowired
	EmployeeService es;
	
	
	@PostMapping("/saveEmployee")
	public Employee f1(@RequestBody  Employee emp) {
		return this.es.saveEmployee(emp);
	}
	
	@GetMapping("/fetchAll")
	public List<Employee> f2() throws EmployeeClassEmptyException{
		
		List<Employee> allEmps = this.es.readAll();
		
		if (allEmps.isEmpty()) {
			throw new EmployeeClassEmptyException("No Employees Found");
		}
		else {
			return allEmps;
		}
	}
	
	@DeleteMapping("/remove/{eid}")
	public String f3(@PathVariable(name="eid")   int id) {
		return this.es.deleteById(id);
	}
	
	@PutMapping("/updateEmp")
	public Employee f4(@RequestBody Employee emp) {
		return this.es.updateEmployee(emp);
	}
	
	@GetMapping("/findEmp/{eid}")
	public Employee f5(@PathVariable(name="eid")  int id) throws EmployeeNotFoundException {
		
		Employee employee = this.es.findEmployee(id);
		
		if(employee == null) {
			throw new EmployeeNotFoundException("Employee with id :" + id + "Not found");
		}
		else {
			return employee;
		}
	}
}
