package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.service.GoodByeService;

@RestController
@RequestMapping("/goodbyeapi")
public class GoodByeController {
	
	@Autowired
	GoodByeService gbs;
	
	@PostMapping("/goodbye/{nm}")
	public String f1(@PathVariable(name="nm") String name) {
		return gbs.sayGoodBye(name);
	}

}
