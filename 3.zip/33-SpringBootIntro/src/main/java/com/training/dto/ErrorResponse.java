package com.training.dto;

public class ErrorResponse {
	
	int httpStatusCode;
	String errorMessage;
	public ErrorResponse(int httpStatusCode, String errorMessage) {
		super();
		this.httpStatusCode = httpStatusCode;
		this.errorMessage = errorMessage;
	}
	public ErrorResponse() {
		super();
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
	

}
