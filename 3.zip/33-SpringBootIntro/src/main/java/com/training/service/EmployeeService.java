package com.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.training.db.EmployeeRepository;
import com.training.model.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository repo;
	
	public Employee saveEmployee(Employee emp) {
		Employee temp=repo.save(emp);
		return temp;
	}
	
	public List<Employee> readAll(){
		return this.repo.findAll();
	}
	
	public String deleteById(int id) {
		this.repo.deleteById(id);
		return "Successfully Deleted";
	}
	
	public Employee updateEmployee(Employee emp) {
		return this.repo.save(emp);
	}
	
	public Employee findEmployee(int id) {
		Optional<Employee>result=this.repo.findById(id);
		if(result.isPresent())
			return result.get();
		
		return null;
		
	}

}
