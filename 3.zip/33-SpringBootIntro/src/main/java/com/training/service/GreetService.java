package com.training.service;

import org.springframework.stereotype.Service;

@Service
public class GreetService {
	
	public String sayHello(String name) {
		return name.toUpperCase() + " How are you?";
	}

}
