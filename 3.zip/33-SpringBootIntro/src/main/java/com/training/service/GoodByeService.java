package com.training.service;

import org.springframework.stereotype.Service;

@Service
public class GoodByeService {
	
	public String sayGoodBye(String name) {
		return "Hello "+name.toUpperCase()+ " Good Bye";
	}

}
