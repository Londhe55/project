package com.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.db.CustomerRepository;
import com.training.model.Customer;
import com.training.model.Employee;

//add annotation
@Service
public class CustomerService {

	// fill the code
	
	@Autowired
	CustomerRepository repository;
	
	
	public Customer saveCustomer(Customer customer) {
		return this.repository.save(customer);
	}
	
	public List<Customer> readAllCustomer() {
		return this.repository.findAll();
	}
	
	public Customer readCustomerById(int id) {
		Optional<Customer> result = repository.findById(id);
		
		if(result.isPresent()) {
			return result.get();
		}
		
		return null;
	}
	
	
	public String deleteCustomerById(int id) {
		this.repository.deleteById(id);
		return "Successfully Deleted";
	}
	
	
	public Customer updateCustomer(Customer customer) {
		return this.repository.save(customer);
	}
	
	
	
	
	
	
	
}
