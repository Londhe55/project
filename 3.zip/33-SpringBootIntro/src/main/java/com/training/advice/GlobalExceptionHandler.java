package com.training.advice;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.training.dto.ErrorResponse;
import com.training.exception.EmployeeClassEmptyException;
import com.training.exception.EmployeeNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	
	@ExceptionHandler(exception = EmployeeNotFoundException.class)
	public ErrorResponse handleException1(Exception e) {
		
		ErrorResponse response = new ErrorResponse(404, e.getMessage());
		
		return response;
	}
	
	@ExceptionHandler(exception = EmployeeClassEmptyException.class)
	public ErrorResponse handleException2(Exception e) {
		
		ErrorResponse response = new ErrorResponse(404, e.getMessage());
		
		return response;
	}
	
	
	

}
