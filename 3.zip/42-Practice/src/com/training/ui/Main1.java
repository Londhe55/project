package com.training.ui;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.training.model.SalesPerson;

public class Main1 {
	public static void main(String[] args) {
		
		List<SalesPerson> allPersons;
		
		allPersons = new LinkedList<>();
		
		allPersons.add(new SalesPerson(110, "Niranjan", "Pune", 125000,26));
		allPersons.add(new SalesPerson(112, "Ram", "Chennai", 25000,21));
		allPersons.add(new SalesPerson(111, "Sham", "Hydrabad", 15000,22));
		allPersons.add(new SalesPerson(113, "Vikas", "Delhi", 25000,29));
		allPersons.add(new SalesPerson(114, "Raj", "Delhi", 25000,20));

		allPersons.stream().forEach(s -> System.out.println(s));
		System.out.println();
		
		
		System.out.println("only the names of all SalesPersons");
		allPersons.stream().map(s -> s.getName()).forEach(s ->System.out.println(s));
		
		System.out.println();
		System.out.println(" only the names of all SalesPersons in capital letters");
		allPersons.stream().map(s -> s.getName().toUpperCase()).forEach(s -> System.out.println(s));
		
		System.out.println();
		System.out.println("all the sales person details in ascending order of id");
		allPersons.stream().sorted((s1,s2) -> s1.getId() - s2.getId()).forEach(s -> System.out.println(s));
			
		System.out.println();
		System.out.println("all the sales person details in ascending order of name");
		allPersons.stream().sorted(Comparator.comparing(SalesPerson::getName)).forEach(s -> System.out.println(s));
		
		
		System.out.println();
		System.out.println("all the sales person details in descending order of name");
		allPersons.stream().sorted(Comparator.comparing(SalesPerson::getName).reversed()).forEach(s -> System.out.println(s));

		
		
		
		System.out.println();
		System.out.println("the total of salesAchieved by all sales persons");
		allPersons.stream().map(s -> s.getSalesAchieved()).count();
		
		System.out.println();
		System.out.println("the sales person name who has achieved the least sales");
		Optional<SalesPerson> first = allPersons.stream().sorted(Comparator.comparing(SalesPerson::getSalesAchieved)).findFirst();
		System.out.println(first);
		
		System.out.println();
		System.out.println("the sales person name who has achieved the best sales");
		Optional<SalesPerson> first2 = allPersons.stream().sorted(Comparator.comparing(SalesPerson::getSalesAchieved).reversed()).findFirst();
		System.out.println(first2);
		
		
		System.out.println();
		System.out.println("all the salesPerson details grouped by city");
		System.out.println(allPersons.stream().collect(Collectors.groupingBy(SalesPerson::getCity)));
		
		System.out.println();
		System.out.println("all the salesPerson details from 'Delhi' city");
		System.out.println(allPersons.stream().collect(Collectors.groupingBy(s -> s.getCity() == "Delhi")));
		
		
		System.out.println();
		System.out.println("print the youngest sales person");
		System.out.println(allPersons.stream().sorted(Comparator.comparing(SalesPerson::getAge)).findFirst());
		
		System.out.println();
		System.out.println("print the eldest sales person");
		System.out.println(allPersons.stream().sorted(Comparator.comparing(SalesPerson::getAge).reversed()).findFirst());
		
		System.out.println();
		System.out.println("the total of Sales Achieved in 'Delhi' City");
		System.out.println(allPersons.stream().filter(s -> "Delhi".equals(s.getCity())).count());
		
		System.out.println();
		System.out.println("the total sales achieved citywise");
		allPersons.stream().sorted(Comparator.comparing(SalesPerson::getCity).thenComparing(SalesPerson::getSalesAchieved)).forEach(System.out::println);
	
		
		System.out.println();
		System.out.println("name and salesAchieved in the ascending order of SalesAchieved");
		Map<String, List<Double>> salesByName = allPersons.stream()
			    					.collect(Collectors.groupingBy(
			    						SalesPerson::getName,
			    					Collectors.mapping(SalesPerson::getSalesAchieved, Collectors.toList())
			    ));
		
		
		System.out.println();
		System.out.println("print name,age,salesAchived in the ascending order of age");
		allPersons.stream()
		          .sorted(Comparator.comparing(SalesPerson::getAge))
		          .forEach(s -> System.out.println(
		              "Name: " + s.getName() + ", Age: " + s.getAge() + ", Sales: " + s.getSalesAchieved()
		          ));
		
	}

}
