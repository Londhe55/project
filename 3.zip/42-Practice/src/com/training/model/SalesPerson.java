package com.training.model;
 
import java.util.Objects;
 
public class SalesPerson {
 
	int id;
	String name;
	String city;
	double salesAchieved;
	int age;
	public SalesPerson(int id, String name, String city, double salesAchieved, int age) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
		this.salesAchieved = salesAchieved;
		this.age = age;
	}
	public SalesPerson() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getSalesAchieved() {
		return salesAchieved;
	}
	public void setSalesAchieved(double salesAchieved) {
		this.salesAchieved = salesAchieved;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "SalesPerson [id=" + id + ", name=" + name + ", city=" + city + ", salesAchieved=" + salesAchieved
				+ ", age=" + age + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SalesPerson other = (SalesPerson) obj;
		return id == other.id;
	}
	
}