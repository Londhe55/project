package com.training.ui;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/goodbyeapi")
public class GoodByController {
	
	
	@GetMapping("goodbye")
	public String f1() {
		return "Good Bye";
	}

}
