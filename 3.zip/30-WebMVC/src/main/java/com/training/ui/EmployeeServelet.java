package com.training.ui;

import java.io.IOException;

import com.training.model.Employee;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EmployeeServelet extends HttpServlet{
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String p1 = req.getParameter("txt_id");
		String p2 = req.getParameter("txt_name");
		String p3 = req.getParameter("txt_salary");
		String p4 = req.getParameter("rad_grade");
		
		int id = Integer.parseInt(p1);
		String name = p2;
		double basic = Double.parseDouble(p3);
		char grade = p4.charAt(0);
		
		

		
		
		Employee employee = new Employee(id,name,basic,grade);
		
		RequestDispatcher rs = req.getRequestDispatcher("employeeoutput.jsp");
		req.setAttribute("emp", employee);
		
		rs.forward(req, resp);
	}
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		doPost(req, resp);
	}
	

}
