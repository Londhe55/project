package com.training.ui;

import java.io.IOException;
import java.time.LocalTime;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class FrontControllerServelet extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		LocalTime time = LocalTime.now();
		System.out.println(time);
		
		System.out.println(req.getRequestURI());
		
		String uri = req.getRequestURI();
//		System.out.println(uri.stripTrailing());
		
		
		int lastindex = uri.indexOf(".do");   // return the indexof 
		
		String path = uri.substring(11, lastindex);         // return substring 
		System.out.println(path);
		
		
		RequestDispatcher rd = req.getRequestDispatcher(path);
		rd.forward(req, resp);
		
		
	}

}




// One Front controller must be prsent

