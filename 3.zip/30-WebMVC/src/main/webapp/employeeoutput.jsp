<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Employee Details</title>
</head>
<body>

    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <td><strong>Employee Id</strong></td>
            <td>${requestScope.emp.id}</td>
        </tr>
        <tr>
            <td><strong>Employee Name</strong></td>
            <td>${requestScope.emp.name}</td>
        </tr>
        <tr>
            <td><strong>Employee Grade</strong></td>
            <td>${requestScope.emp.grade}</td>
        </tr>
        <tr>
            <td><strong>Employee Basic Salary</strong></td>
            <td>${requestScope.emp.basic}</td>
        </tr>
        <tr>
            <td><strong>Employee Allowance</strong></td>
            <td>${requestScope.emp.allowance}</td>
        </tr>
        <tr>
            <td><strong>Employee Deduction</strong></td>
            <td>${requestScope.emp.deduction}</td>
        </tr>
        <tr>
            <td><strong>Employee Net Salary</strong></td>
            <td>${requestScope.emp.netSalary}</td>
        </tr>
    </table>
    
</body>
</html>