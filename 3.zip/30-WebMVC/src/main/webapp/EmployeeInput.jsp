<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

	<table>
		<form action="es" method="post">
			<tr>
				<td><label>Employee Id</label></td>
				<td><input name="txt_id"></td>
			</tr>
			
			<tr>
				<td><label>Employee name</label></td>
				<td><input name="txt_name"></td>
			</tr>
			
			<tr>
				<td><label>Employee Salary</label></td>
				<td><input name="txt_salary"></td>
			</tr>
			
			<tr>
				<td><label>Employee Grade</label></td>
				
				<td>
					<input type="radio" name = "rad_grade" value="A">A
					<input type="radio" name = "rad_grade" value="B">B
					<input type="radio" name = "rad_grade" value="C">C
				</td>
			</tr>
			
			<tr>
				<td colspan = '2'>
			
					<input type="submit" value="submit">
				</td>
			</tr>
		</form>
		
	</table>

</body>
</html>