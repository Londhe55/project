<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
		
		<a href="gs.do">Grret</a>
		<br>
		<a href="eis.do">Employee Input</a>
		<br>
		
</body>
</html>