package com.training;

import com.training.model.ContactInfo;
import com.training.model.Person;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main3 {
	static void insertOne() {
		
		ContactInfo contactInfo =  new ContactInfo(5001, "anupuma@gmail.com", "67869839282");
		
		Person person = new Person(1001, "Anumpama", 25, contactInfo);
		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(person);
		em.persist(contactInfo);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
	}
	
	
		static void inserttwo() {
		
		
		
		Person person = new Person(1002, "Jpohn", 35, null);
		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(person);

		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
	}
		
		
		
		static void insertThree() {
			
			
			
			
			ContactInfo contactInfo = new ContactInfo(5002, "john@gmail.com", "8826982983");
			
			
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
			em.getTransaction().begin();
			em.persist(contactInfo);

			em.getTransaction().commit();
			
			em.close();
			emf.close();
			
		}
		
		
		static void associate() {
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
			Person person = em.find(Person.class, 1002);
			ContactInfo contactInfo = em.find(ContactInfo.class, 5002);
			
			person.setContactInfo(contactInfo);  	// Association
			
			em.getTransaction().begin();
			em.merge(person);

			em.getTransaction().commit();
			
			em.close();
			emf.close();
		}
		
		
		
		static void insertFour() {
			
			ContactInfo contactInfo = new ContactInfo(5003, "jaya@gmail.com", "12898737467");
			Person person = new Person(1003, "Jaya", 22, contactInfo);
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
			
			em.getTransaction().begin();
			em.persist(person);   // here vwe are persit only person still contact info will be stored

			em.getTransaction().commit();
			
			em.close();
			emf.close();
			
		}
	
		
		static void radOne() {
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
			Person person = em.find(Person.class, 1001);
			
			System.out.println(person);
			
			
			em.close();
			emf.close();
			
			
		}
		
		static void delete() {
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
			Person person = em.find(Person.class, 1003);
			
			
			em.getTransaction().begin();
			em.remove(person);
			em.getTransaction().commit();
			
			em.close();
			emf.close();
			
			
		}
		
		
		// By defualt is unidirectional 
		
		static void printPhone() {
			
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
			
			EntityManager em = emf.createEntityManager();
			
			Person person = em.find(Person.class, 1002);
			
			System.out.println(person.getContactInfo().getPhone());
			
			System.out.println(person.getContactInfo().getEmail());
			
			
	
			
			em.close();
			emf.close();
			
			
		}
		
		
		
		
		
		
	
	
	public static void main(String[] args) {
		
		
//		insertOne();
		
//		inserttwo();
		
//		insertThree();
		
//		associate();
		
		
//		insertFour();
		
		
//		radOne();
		
//		delete();
		
		printPhone();
		
	}

}
