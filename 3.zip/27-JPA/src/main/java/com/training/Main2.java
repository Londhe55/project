package com.training;

import java.time.LocalDate;

import com.training.model.Bill;
import com.training.model.Order;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main2 {
	
	static void insertOrder() {
		
		
		
		
		
		Bill bill = new Bill(LocalDate.of(2020, 2, 23), 20000);
		
		bill.addPayment(LocalDate.of(2020, 1, 12), 30000, "Offline");
		
		
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = entityManagerFactory.createEntityManager();
		
		
		em.getTransaction().begin();
		
		em.persist(bill);
		
		em.getTransaction().commit();
		
		em.close();
		entityManagerFactory.close();
	}
	
	
	public static void main(String[] args) {
		
		insertOrder();
		
	}

}
