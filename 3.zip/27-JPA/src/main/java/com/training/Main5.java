package com.training;

import com.training.model.Course;
import com.training.model.SalesTeam;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main5 {
	
	static void insertOne() {
		
		SalesTeam salesTeam = new SalesTeam(101, "Sinhgad", "Pune", null);
	
		
		salesTeam.addSales(1, "A", "Solapur");
		salesTeam.addSales(2, "B", "Chennai");
		salesTeam.addSales(3, "c", "delhi");
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		
		em.getTransaction().begin();
		em.persist(salesTeam);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
		
	}
	
	
	
	static void readOne() {
		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		SalesTeam salesTeam = em.find(SalesTeam.class, 101);
		
		
		System.out.println(salesTeam);
		
		em.close();
		emf.close();
		
		
	}
	
	
	static void delete() {
		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		 SalesTeam salesTeam = em.find(SalesTeam.class, 101);
		
		
		em.getTransaction().begin();
		em.remove(salesTeam);
		em.getTransaction().commit();
		
		
		em.close();
		emf.close();
		
		
	}
	
	public static void main(String[] args) {
		
		
		
		
		insertOne();
		
//		readOne();
		
//		delete();
		
		
	}

}
