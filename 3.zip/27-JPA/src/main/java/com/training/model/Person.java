package com.training.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "person")
public class Person {
	
	
	@Id
	int person;
	
	@Column
	String personName;
	
	@Column
	int age;
	
//	@OneToOne(cascade = CascadeType.PERSIST)   // (cascade = CascadeType.PERSIST) this is used for to endure that person with contactInfo also must be saved
	@OneToOne(cascade =  CascadeType.ALL)     // 
	ContactInfo contactInfo;

	public Person(int person, String personName, int age, ContactInfo contactInfo) {
		super();
		this.person = person;
		this.personName = personName;
		this.age = age;
		this.contactInfo = contactInfo;
	}

	public Person() {
		super();
	}

	public int getPerson() {
		return person;
	}

	public void setPerson(int person) {
		this.person = person;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public ContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	@Override
	public String toString() {
		return "Person [person=" + person + ", personName=" + personName + ", age=" + age + ", contactInfo="
				+ contactInfo + "]";
	}
	
	
	

}
