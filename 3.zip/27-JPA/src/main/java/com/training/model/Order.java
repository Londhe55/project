package com.training.model;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")
public class Order {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int orderId;
	
	@Column(name = "customerName")
	String customerName;
	
	@Column(name = "orderDate")
	LocalDate orderDate;
	
	@ElementCollection            //  Tells JPA: “This is NOT a separate entity  	It is just a collection of values”
	@CollectionTable(name =  "order-items")     //  used for define the table name : Defines table name for collection
	@OrderColumn(name = "idx")               //  Maintains order of list ✅  @OrderColumn works ONLY with:   List  NOT with: Set
//	Table already created before adding @OrderColumn   in such case it will not create the idx column 
	List<OrderItem> itemList;


	public Order(String customerName, LocalDate orderDate) {
		super();
		this.customerName = customerName;
		this.orderDate = orderDate;
	}

	public Order() {
		super();
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderItem> getItemList() {
		return itemList;
	}

	public void setItemList(List<OrderItem> itemList) {
		this.itemList = itemList;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customerName=" + customerName + ", orderDate=" + orderDate
				+ ", itemList=" + itemList + "]";
	}
	
	
	
	// here we need this method because Encapsulation , Business Logic Handling, Maintain Consistency,  Object Creation Simplified
	public void add(String itemname, double price, int quantity) {
		
		if(itemList == null) {
			itemList = new LinkedList<>();
			
			
		}
		OrderItem oi = new OrderItem(itemname, price, quantity);
		itemList.add(oi);
	}

	
	
	
	
	
	
	
	

}
