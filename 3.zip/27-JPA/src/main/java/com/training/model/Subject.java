package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "course_subjects")
public class Subject {
	
	
	@Id
	int subjectId;
	
	@Column
	String subjectName;
	
	
	@Column
	int duration;


	public Subject(int subjectId, String subjectName, int duration) {
		super();
		this.subjectId = subjectId;
		this.subjectName = subjectName;
		this.duration = duration;
	}


	public Subject() {
		super();
	}


	public int getSubjectId() {
		return subjectId;
	}


	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}


	public String getSubjectName() {
		return subjectName;
	}


	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	@Override
	public String toString() {
		return "\n Subject [subjectId=" + subjectId + ", subjectName=" + subjectName + ", duration=" + duration + "]";
	}
	
	
	
	
	
	
	

}
