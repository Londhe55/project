package com.training.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OrderColumn;

@Entity
public class Bill {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int billId;
	
	
	@Column(name = "billdate")
	LocalDate billDate;
	
	@Column(name = "billAmount")
	double billAmount;
	
	@ElementCollection
	@CollectionTable(name =  "payment")
	@OrderColumn(name = "idx")
	List<Payment> paymentList;


	



	public LocalDate getBiDate() {
		return billDate;
	}

	public void setBiDate(LocalDate biDate) {
		this.billDate = biDate;
	}

	public double getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}


	public Bill(LocalDate billDate, double billAmount) {
		super();
		this.billDate = billDate;
		this.billAmount = billAmount;
	}

	public Bill() {
		super();
	}

	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", billDate=" + billDate + ", billAmount=" + billAmount + ", paymentList="
				+ paymentList + "]";
	}
	
	
	
	
	public void addPayment(LocalDate paymentDate, double amount, String payMode) {
		
		if(paymentList == null) {
			paymentList = new ArrayList<>();
		}
		
		Payment py = new Payment(paymentDate, amount, payMode);
		
		paymentList.add(py);
	}
	
	

}
