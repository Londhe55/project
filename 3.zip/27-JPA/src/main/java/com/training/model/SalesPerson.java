package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name =  "salesPerson")
public class SalesPerson {
	
	
	
	@Id
	int salesPersonId;
	
	
	@Column
	String name;
	
	@Column
	String cityName;

	public SalesPerson(int salesPersonId, String name, String cityName) {
		super();
		this.salesPersonId = salesPersonId;
		this.name = name;
		this.cityName = cityName;
	}

	public SalesPerson() {
		super();
	}

	public int getSalesPersonId() {
		return salesPersonId;
	}

	public void setSalesPersonId(int salesPersonId) {
		this.salesPersonId = salesPersonId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	@Override
	public String toString() {
		return "SalesPerson [salesPersonId=" + salesPersonId + ", name=" + name + ", cityName=" + cityName + "]";
	}
	
	
	
	
	

}
