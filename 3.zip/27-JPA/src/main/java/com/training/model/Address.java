package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class Address {
	
	
	@Column
	String doorNumber;
	
	@Column
	String areaName;
	
	@Column
	String city;
	
	@Column
	String pincode;

	public Address(String doorNumber, String areaName, String city, String pincode) {
		super();
		this.doorNumber = doorNumber;
		this.areaName = areaName;
		this.city = city;
		this.pincode = pincode;
	}

	public Address() {
		super();
	}

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "\n Address [doorNumber=" + doorNumber + ", areaName=" + areaName + ", city=" + city + ", pincode="
				+ pincode + "]";
	}
	
	
	

}
