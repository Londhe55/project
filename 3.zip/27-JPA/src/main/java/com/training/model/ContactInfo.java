package com.training.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "contactInfo")
public class ContactInfo {
	
	@Id
	
	int contactid;
	
	@Column
	String email;
	
	@Column
	String phone;

	public ContactInfo(int contactid, String email, String phone) {
		super();
		this.contactid = contactid;
		this.email = email;
		this.phone = phone;
	}

	public ContactInfo() {
		super();
	}

	@Override
	public String toString() {
		return "ContactInfo [contactid=" + contactid + ", email=" + email + ", phone=" + phone + "]";
	}

	public int getContactid() {
		return contactid;
	}

	public void setContactid(int contactid) {
		this.contactid = contactid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	
	
	
	

}
