package com.training.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class Payment {
	
	@Column
	LocalDate paymentDate;
	
	@Column
	double paidAmount;
	
	@Column
	String paymentMode;

	public LocalDate getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}

	public double getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(double paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	@Override
	public String toString() {
		return "Payment [paymentDate=" + paymentDate + ", paidAmount=" + paidAmount + ", paymentMode=" + paymentMode
				+ "]";
	}

	public Payment(LocalDate paymentDate, double paidAmount, String paymentMode) {
		super();
		this.paymentDate = paymentDate;
		this.paidAmount = paidAmount;
		this.paymentMode = paymentMode;
	}

	public Payment() {
		super();
	}
	
	
	
	

}
