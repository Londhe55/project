package com.training.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "salesteam")
public class SalesTeam {

	@Id
	int teamId;

	@Column
	String teamName;

	@Column
	String region;

	@OneToMany(cascade = CascadeType.ALL)
	List<SalesPerson> personList;

	public SalesTeam(int teamId, String teamName, String region, List<SalesPerson> personList) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		this.region = region;
		this.personList = personList;
	}

	public SalesTeam() {
		super();
	}

	@Override
	public String toString() {
		return "\n SalesTeam [teamId=" + teamId + ", teamName=" + teamName + ", region=" + region + ", personList="
				+ personList + "]";
	}

	public int getTeamId() {
		return teamId;
	}

	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public List<SalesPerson> getPersonList() {
		return personList;
	}

	public void setPersonList(List<SalesPerson> personList) {
		this.personList = personList;
	}

	public void addSales(int teamId, String teamName, String region) {

		if (personList == null) {
			personList = new ArrayList<>();

		}

		personList.add(new SalesPerson(teamId, teamName, region));

	}

}
