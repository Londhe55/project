package com.training;

import java.awt.datatransfer.SystemFlavorMap;

import com.mysql.cj.x.protobuf.MysqlxCrud.Order;
import com.training.model.Address;
import com.training.model.Customer;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class App {
	
	
	static void insert() {
		
		Address address = new Address("D-28", "T nagar", "Chennai", "423894");
		
		Customer customer = new Customer(102, "Shri", "Female", address);
		
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = entityManagerFactory.createEntityManager();
		
		
		em.getTransaction().begin();
		
		em.persist(customer);
		
		em.getTransaction().commit();
		
		em.close();
		entityManagerFactory.close();
	}
	
	
	static void read() {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = entityManagerFactory.createEntityManager();
		
		Customer customer = em.find(Customer.class, 102);
		System.out.println(customer);
		
		em.close();
		entityManagerFactory.close();
		
	}
	
	
	
	
	
	
	
	
	
    public static void main(String[] args) {
        
        
//        insert();
    	read();
    }
}
