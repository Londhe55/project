package com.training;

import com.training.model.Course;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main4 {
	
	
	
	static void insertOne() {
		
		Course course = new Course(1, "Webtechnologies", 12000, null);
		
		course.addSubject(6001, "HTML", 12);
		course.addSubject(6002, "java", 20);
		course.addSubject(6003, "Java", 6);
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		
		em.getTransaction().begin();
		em.persist(course);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
		
	}
	
	
	
	static void readOne() {
		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Course course = em.find(Course.class, 1);
		
		
		System.out.println(course);
		
		em.close();
		emf.close();
		
		
	}
	
	
	static void delete() {
		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Course course = em.find(Course.class, 1);
		
		
		em.getTransaction().begin();
		em.remove(course);
		em.getTransaction().commit();
		
		
		em.close();
		emf.close();
		
		
	}
	
	
	
	
	public static void main(String[] args) {
		
		
//		insertOne();
		
//		readOne();
		
		
		delete();
		
	}

}
