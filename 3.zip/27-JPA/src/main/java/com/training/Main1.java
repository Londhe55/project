package com.training;

import java.time.LocalDate;

import com.training.model.Order;
import com.training.model.OrderItem;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main1 {
	
		static void insertOrder() {
		
		
		Order order = new Order("Veer", LocalDate.of(2022, 10, 15));
		
		order.add("Dell", 40000, 10);
		order.add("lenveo", 20060, 32);
		
		
		Order order1 = new Order("Veer", LocalDate.of(2022, 10, 15));
		OrderItem orderItem = new OrderItem("A", 278378, 1);
		
		
		
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = entityManagerFactory.createEntityManager();
		
		
		em.getTransaction().begin();
		
		em.persist(order1);
		
		em.getTransaction().commit();
		
		em.close();
		entityManagerFactory.close();
	}
	
	public static void main(String[] args) {
		
		insertOrder();
		
	}

}
