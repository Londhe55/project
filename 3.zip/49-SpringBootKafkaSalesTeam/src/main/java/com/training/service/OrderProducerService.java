package com.training.service;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.training.model.Order;

@Service
public class OrderProducerService {
	
	
	private static final String TOPIC = "order_topic";
    private final KafkaTemplate<String, Order> kafkaTemplate;
 
    public OrderProducerService(KafkaTemplate<String, Order> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }
 
    public void sendMessage(Order order) {
        kafkaTemplate.send(TOPIC, order);
        System.out.println();
        System.out.println("Message sent: " + order);
    }

}
