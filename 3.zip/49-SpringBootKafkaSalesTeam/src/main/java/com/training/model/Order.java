package com.training.model;

import java.time.LocalDate;

import org.springframework.stereotype.Component;


public class Order {

	int id;
	
	LocalDate orderDate;
	
	String orderItem;
	
	int quantity;
	
	LocalDate deliveryDate;

	public Order(int id, LocalDate orderDate, String orderItem, int quantity, LocalDate deliveryDate) {
		super();
		this.id = id;
		this.orderDate = orderDate;
		this.orderItem = orderItem;
		this.quantity = quantity;
		this.deliveryDate = deliveryDate;
	}

	public Order() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(String orderItem) {
		this.orderItem = orderItem;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public LocalDate getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(LocalDate deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", orderDate=" + orderDate + ", orderItem=" + orderItem + ", quantity=" + quantity
				+ ", deliveryDate=" + deliveryDate + "]";
	}
	
	
	
	
	
}
