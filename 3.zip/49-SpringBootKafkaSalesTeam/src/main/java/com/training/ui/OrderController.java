package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Order;
import com.training.service.OrderProducerService;

@RestController
@RequestMapping("/api")
public class OrderController {

	@Autowired
	OrderProducerService service;
	
	
	
	@PostMapping("/sendOrder")
	public void sendOrder(@RequestBody Order order) {
		
		this.service.sendMessage(order);
		System.out.println("Order" + order + " Sent from sales Team ");
		
	}
}
