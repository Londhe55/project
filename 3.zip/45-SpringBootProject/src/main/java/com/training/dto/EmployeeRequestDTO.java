package com.training.dto;

import com.training.model.Employee;

public class EmployeeRequestDTO {
	
	Employee employee;

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	


}


