package com.training.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.dto.EmployeeListResponseDtO;
import com.training.dto.EmployeeRequestDTO;
import com.training.dto.EmployeeResponseDTO;
import com.training.model.Employee;
import com.training.service.CustomerService;
import com.training.service.EmployeeService;

@RestController
@RequestMapping("/empapi")
public class EmployeeController {

    
	
	
	@Autowired
	EmployeeService service;


   
	
    
    
    // Insert
	
	@PostMapping("/saveEmployee")
	public ResponseEntity<EmployeeResponseDTO> f1(@RequestBody EmployeeRequestDTO dto) {
		
		Employee other = this.service.saveEmployee(dto.getEmployee());
		EmployeeResponseDTO responseDTO = new EmployeeResponseDTO();
		responseDTO.setEmployee(other);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage("Employee Saved Successfully");
		
		return ResponseEntity.ok(responseDTO);
		
		
	}
	
	
	// Fetch All
	
	@GetMapping("/fetchAll")
	public ResponseEntity<EmployeeListResponseDtO> f2() {
		
		List<Employee> employees = this.service.readAll();
		EmployeeListResponseDtO dto = new EmployeeListResponseDtO();
		
		if(employees.size() > 0) {
			dto.setHttpStatusCode(200);
			dto.setMessage(employees.size() + "Employees Objects fetched");
			dto.setEmployees(employees);
			return ResponseEntity.ok(dto);
			
		}else {
			dto.setHttpStatusCode(404);
			dto.setMessage("No Employees found");
			dto.setEmployees(null);
		}
		
		return ResponseEntity.notFound().build();
	}
	
	
	
	
	

	// Update 
	
	@PutMapping("/update")
	public ResponseEntity<EmployeeResponseDTO> updateEmployeeById(@RequestBody EmployeeRequestDTO dto) {
		int id = dto.getEmployee().getId();
		Employee temp= this.service.updateEmployee(dto.getEmployee());
		
		EmployeeResponseDTO responseDTO = new EmployeeResponseDTO();
		
		if(temp == null) {
			responseDTO.setEmployee(null);
			responseDTO.setHttpStatusCode(404);
			responseDTO.setMessage("Employee With id " + id +" Not Found");
			
		}
		else {
			responseDTO.setEmployee(temp);
			responseDTO.setHttpStatusCode(200);
			responseDTO.setMessage("Employee Found Successfully");
		}
		
		return ResponseEntity.ok(responseDTO);
	}
	
	
	
	// Fetch By ID
	
	@GetMapping("/fetch/{id}")
	public ResponseEntity<EmployeeResponseDTO> f4(@PathVariable int id){

		Employee temp = this.service.findEmployee(id);
		EmployeeResponseDTO responseDTO = new EmployeeResponseDTO();
		
		if(temp == null) {
			responseDTO.setEmployee(null);
			responseDTO.setHttpStatusCode(404);
			responseDTO.setMessage("Employee With id " + id +" Not Found");
			
		}
		else {
			responseDTO.setEmployee(temp);
			responseDTO.setHttpStatusCode(200);
			responseDTO.setMessage("Employee Found");
		}
		
		return ResponseEntity.ok(responseDTO);
	}
	
	
	// Delete By ID
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<EmployeeResponseDTO> f5(@PathVariable int id){
		
		Employee temp = this.service.deleteById(id);
		EmployeeResponseDTO responseDTO = new EmployeeResponseDTO();
		
		if(temp == null) {
			responseDTO.setEmployee(null);
			responseDTO.setHttpStatusCode(404);
			responseDTO.setMessage("Employee With id " + id +" Not Found");
			
		}
		else {
			responseDTO.setEmployee(temp);
			responseDTO.setHttpStatusCode(200);
			responseDTO.setMessage("Employee deleted");
			
			
		}

		
		return ResponseEntity.ok(responseDTO);	
	}

	
	// Find By UserName
	
	
	@GetMapping("/fetch")
	public ResponseEntity<EmployeeResponseDTO> fetchByName(@RequestParam String name){
		
		Employee employee = this.service.findEmployeeByName(name);
		
		EmployeeResponseDTO responseDTO = new EmployeeResponseDTO();
		
		if(employee == null) {
			responseDTO.setEmployee(null);
			responseDTO.setHttpStatusCode(404);
			responseDTO.setMessage("Employee With id " + name +" Not Found");
			
		}
		else {
			responseDTO.setEmployee(employee);
			responseDTO.setHttpStatusCode(200);
			responseDTO.setMessage("Employee Found");
			
			
		}

		
		return ResponseEntity.ok(responseDTO);
		
	}
	
}
