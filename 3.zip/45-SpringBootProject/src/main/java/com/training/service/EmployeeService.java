package com.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.training.db.EmployeeRepository;
import com.training.model.Employee;

@Service
public class EmployeeService {

    private final CustomerService customerService;
	
	@Autowired
	EmployeeRepository repo;

    EmployeeService(CustomerService customerService) {
        this.customerService = customerService;
    }
	
	public Employee saveEmployee(Employee emp) {
		Employee temp=repo.save(emp);
		return temp;
	}
	
	public List<Employee> readAll(){
		return this.repo.findAll();
	}
	
	public Employee deleteById(int id) {
		Employee employee = this.repo.findById(id).orElse(null);
		if(employee == null) {
			return null;
		}
		this.repo.deleteById(id);
		return employee;
	}
	
	public Employee updateEmployee(Employee emp) {
		return this.repo.save(emp);
	}
	
	public Employee findEmployee(int id) {
		Optional<Employee>result=this.repo.findById(id);
		if(result.isPresent())
			return result.get();
		
		return null;
		
	}

	public Employee findEmployeeByName(String name) {
		Employee employee = this.repo.findByname(name);
		if(employee == null) {
			return null;
		}
		return employee;
	}

}
