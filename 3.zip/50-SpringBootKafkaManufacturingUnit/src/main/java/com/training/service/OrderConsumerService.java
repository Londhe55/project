package com.training.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.training.model.Order;

@Service
public class OrderConsumerService {
	
	@KafkaListener(topics = "order_topic")
	public void consume(Order order) {

		 System.out.println("Message Received : " + order);

	    System.out.println(order.getId());
	    System.out.println(order.getOrderItem());
	}

}
