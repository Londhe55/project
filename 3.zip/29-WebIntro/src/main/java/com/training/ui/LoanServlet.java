package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class LoanServlet extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int loanId=101;
		String customerName="Reshmi";
		double loanAmount=30000;
		int tenure=12;
		float interestrate = 0.09F;
		
		
		double interestAmount = loanAmount*tenure*interestrate;
		
		double total = loanAmount + interestAmount;
		
		double emi = total / tenure;
		
		PrintWriter out = resp.getWriter();
		out.print("<table border = '1'>");
		
		out.print("<tr>");
		out.print("<td>Loan Id</td>");
		out.print("<td>" + loanId +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>Loan Amount</td>");
		out.print("<td>" + loanAmount +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>Tenure</td>");
		out.print("<td>" + tenure +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>Interest rate</td>");
		out.print("<td>" + loanId +"</td>");
		out.print("<tr>");
		
		
		out.print("<tr>");
		out.print("<td>Total Payable</td>");
		out.print("<td>" + total +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>EMI</td>");
		out.print("<td>" + emi +"</td>");
		out.print("<tr>");
		
		out.print("</table>");
		
		
		
	}

}
