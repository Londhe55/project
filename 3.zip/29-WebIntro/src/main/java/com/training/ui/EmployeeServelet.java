package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EmployeeServelet extends HttpServlet{
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		int empId = 1001;
		String employeeName = "Shalini";
		double basicSalary = 18000.00;
		
		
		double allowence = (40.0 / 100.0)*basicSalary;
		
		double tax = (10.0/ 100.0) * basicSalary;
		
		double netSalary = basicSalary + allowence - tax;
		
		
		PrintWriter out = resp.getWriter();
		out.print("<table border = '1'>");
		
		out.print("<tr>");
		out.print("<td>Emp Id</td>");
		out.print("<td>" + empId +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>Employee Name</td>");
		out.print("<td>" + employeeName +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>Employee Basic Salary</td>");
		out.print("<td>" + basicSalary +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>Allowence</td>");
		out.print("<td>" + allowence +"</td>");
		out.print("<tr>");
		
		
		out.print("<tr>");
		out.print("<td>Tax</td>");
		out.print("<td>" + tax +"</td>");
		out.print("<tr>");
		
		out.print("<tr>");
		out.print("<td>Net Salary</td>");
		out.print("<td>" + netSalary +"</td>");
		out.print("<tr>");
		
		out.print("</table>");
		
	}

}
