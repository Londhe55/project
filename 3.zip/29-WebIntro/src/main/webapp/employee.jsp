<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

	<%
		int empid= 1001;
		String name = "Sham";
		double basic=8000.00;
		
	%>
	
	
	<p> Emp id : <%=empid %></p>
	<p> Emp Name : <%=name %></p>
	<p> Emp Basic Salary : <%=basic %></p>
	
	<p>Allowence <%= basic*(40.0/100.0)%></p>
	<p>Deduction <%=basic*(10.0/100.0) %></p>
	<p>Net Salary <%=  basic + basic*(40.0/100.0) - basic*(10.0/100.0 )%></p>

</body>
</html>