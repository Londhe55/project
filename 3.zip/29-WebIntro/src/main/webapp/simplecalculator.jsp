<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

	<%
		int a = 50;
		int b = 100;
		
	%>
	<h1>Result is <%= a+b %></h1>
	<h1>Result is  <%= a-b %></h1>
	<h1>Result is <%= a*b %></h1>
	<h1>Result is <%= a/b %></h1>

</body>
</html>