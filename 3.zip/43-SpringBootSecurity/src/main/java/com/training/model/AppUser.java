package com.training.model;

import java.util.List;

import java.util.Objects;

import jakarta.persistence.Column;

import jakarta.persistence.ElementCollection;

import jakarta.persistence.Entity;

import jakarta.persistence.FetchType;

import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;


@Entity

public class AppUser {

	@Id

	@GeneratedValue(strategy=GenerationType.IDENTITY)

	int id;

	@Column

	String userName;

	@Column

	String password;

	@ElementCollection(fetch = FetchType.EAGER)

	List<String> roles;

	@Override

	public String toString() {

		return "AppUser [id=" + id + ", userName=" + userName + ", password=" + password + ", roles=" + roles + "]";

	}

	@Override

	public int hashCode() {

		return Objects.hash(id);

	}

	@Override

	public boolean equals(Object obj) {

		if (this == obj)

			return true;

		if (obj == null)

			return false;

		if (getClass() != obj.getClass())

			return false;

		AppUser other = (AppUser) obj;

		return id == other.id;

	}

	public int getId() {

		return id;

	}

	public void setId(int id) {

		this.id = id;

	}

	public String getUserName() {

		return userName;

	}

	public void setUserName(String userName) {

		this.userName = userName;

	}

	public String getPassword() {

		return password;

	}

	public void setPassword(String password) {

		this.password = password;

	}

	public List<String> getRoles() {

		return roles;

	}

	public void setRoles(List<String> roles) {

		this.roles = roles;

	}

}
 