package com.training.dto;
 
public class LoginResponse {
	
	String userName;
	String password;
	String jwtToken;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	@Override
	public String toString() {
		return "LoginResponse [userName=" + userName + ", password=" + password + ", jwtToken=" + jwtToken + "]";
	}
	public LoginResponse(String userName, String password, String jwtToken) {
		super();
		this.userName = userName;
		this.password = password;
		this.jwtToken = jwtToken;
	}
 
}