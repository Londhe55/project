package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.training.db.AppUserRepository;
import com.training.model.AppUser;

@Service
public class AppUserService {
	
	@Autowired
	AppUserRepository repository;
	
	@Autowired
	PasswordEncoder encoder;
	
	public AppUser saveAppUser(AppUser user) {
		String encode = this.encoder.encode(user.getPassword());
		user.setPassword(encode);
		return this.repository.save(user);
		
	}
	
	
	public AppUser findAppuser(String userName) {
		
		return this.repository.findAppUserByName(userName);
		
	}
	
	
	

}
