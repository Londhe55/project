package com.training.service;

import java.util.Collection;

import java.util.List;

import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import org.springframework.security.core.userdetails.UserDetails;

import com.training.model.AppUser;

public class UserDetailsImpl implements UserDetails {

	private static final long serialVersionUID = 1L;

	  private String username;

	  private String password;

	  private Collection<? extends GrantedAuthority> authorities;

	  public UserDetailsImpl( String username,  String password,

	      Collection<? extends GrantedAuthority> authorities) {

	    this.username = username;

	    this.password = password;

	    this.authorities = authorities;

	  }

	  public UserDetailsImpl build(AppUser user) {
 


	    List<GrantedAuthority> authorities=user.getRoles().stream()

	    	.map(role->new SimpleGrantedAuthority("ROLE_" + role))

	    	.collect(Collectors.toList());

	    return new UserDetailsImpl(

	        user.getUserName(),

	        user.getPassword(),

	        authorities);

	  }

	  @Override

	  public Collection<? extends GrantedAuthority> getAuthorities() {

	    return authorities;

	  }



	  @Override

	  public String getPassword() {

	    return password;

	  }

	  @Override

	  public String getUsername() {

	    return username;

	  }

	  @Override

	  public boolean isAccountNonExpired() {

	    return true;

	  }

	  @Override

	  public boolean isAccountNonLocked() {

	    return true;

	  }

	  @Override

	  public boolean isCredentialsNonExpired() {

	    return true;

	  }

	  @Override

	  public boolean isEnabled() {

	    return true;

	  }

	  public UserDetailsImpl() {

		super();

	  }

}
 