package com.training.service;

import java.util.ArrayList;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.GrantedAuthority;

import org.springframework.security.core.userdetails.User;

import org.springframework.security.core.userdetails.UserDetails;

import org.springframework.security.core.userdetails.UserDetailsService;

import org.springframework.security.core.userdetails.UsernameNotFoundException;

import org.springframework.stereotype.Service;

import com.training.db.AppUserRepository;

import com.training.model.AppUser;

@Service

public class UserDetailsImplService implements UserDetailsService{

	@Autowired

	AppUserRepository repo;

	@Override

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		AppUser appuser=repo.findAppUserByName(username);

		//return new User(appuser.getUserName(),appuser.getPassword(),new ArrayList<>()).builder().build();

		return new UserDetailsImpl().build(appuser);

	}


}
 