package com.training.jwt;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
 
import org.springframework.security.core.context.SecurityContextHolder;
 
import org.springframework.security.core.userdetails.UserDetails;
 
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
 
import org.springframework.stereotype.Component;
 
import org.springframework.web.filter.OncePerRequestFilter;
import com.training.service.UserDetailsImplService;
import jakarta.servlet.FilterChain;
 
import jakarta.servlet.ServletException;
 
import jakarta.servlet.http.HttpServletRequest;
 
import jakarta.servlet.http.HttpServletResponse;

@Component
 
public class JwtFilter extends OncePerRequestFilter{
	@Autowired
 
	JwtUtil jwtUtil;
 
	@Autowired
 
	UserDetailsImplService service;
 
 
	@Override
 
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
 
			throws ServletException, IOException {
 
		System.out.println("Filter Code runs");
 
		System.out.println(request.getRequestURL());
 
		String header=request.getHeader("Authorization");
 
		System.out.println(header);
 
		if(header!=null && header.startsWith("Bearer ")) {//-----
 
			String token=header.substring(7);
 
			System.out.println(token);
 
			String username=jwtUtil.extractUserName(token);
 
			System.out.println(username);
 
			System.out.println(jwtUtil.getClaims(token));
 
			UserDetails userDetails = service.loadUserByUsername(username);
 
			System.out.println(userDetails.getAuthorities());
 
			   UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails,
 
			                   null, userDetails.getAuthorities());
 
			   authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
 
			   SecurityContextHolder.getContext().setAuthentication(authenticationToken);
 
		}
 
 
		filterChain.doFilter(request, response);
 
	}

}