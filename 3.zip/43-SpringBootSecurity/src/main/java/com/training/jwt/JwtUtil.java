package com.training.jwt;
 
import java.nio.charset.StandardCharsets;
 
import java.security.Key;
 
import java.util.Date;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Value;
 
import org.springframework.security.core.Authentication;
 
import org.springframework.security.core.userdetails.UserDetails;
 
import org.springframework.stereotype.Component;
import com.training.service.UserDetailsImpl;
import io.jsonwebtoken.Claims;
 
import io.jsonwebtoken.Jwts;
 
import io.jsonwebtoken.SignatureAlgorithm;
 
import io.jsonwebtoken.io.Decoders;
 
import io.jsonwebtoken.security.Keys;

@Component
 
public class JwtUtil {
    private final String SECRET = "mysecretkeymysecretkeymysecretkey123456";
    private final int jwtExpirationMs = 86400000;
    private Key key() {
 
        return Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));
 
    }
 
    public String generateJwtToken(Authentication authentication) {
        UserDetailsImpl userPrincipal = (UserDetailsImpl) authentication.getPrincipal();
        return Jwts.builder()
 
                .setSubject(userPrincipal.getUsername())
 
                .setIssuedAt(new Date())
 
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationMs))
 
                .signWith(key(), SignatureAlgorithm.HS256)
 
                .compact();
 
    }

public Claims getClaims(String token) {
 
    return Jwts.parser()
 
            .verifyWith((javax.crypto.SecretKey) key())   // ✅ new API
 
            .build()
 
            .parseSignedClaims(token)
 
            .getPayload();
 
}

    public String extractUserName(String token) {
 
        return getClaims(token).getSubject();
 
    }
 
}