package com.training.db;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.training.model.AppUser;

@Repository
public interface AppUserRepository extends JpaRepository<AppUser, Integer>{

	@Query("select au from AppUser au where au.userName = :userName")
	AppUser findAppUserByName(String userName);

}
