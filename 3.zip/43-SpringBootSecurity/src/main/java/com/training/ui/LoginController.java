package com.training.ui;
 
import java.util.List;
import java.util.stream.Collectors;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.training.db.AppUserRepository;
import com.training.dto.LoginResponse;
import com.training.jwt.JwtUtil;
import com.training.model.AppUser;
import com.training.service.UserDetailsImpl;
 
@RestController
@RequestMapping("/loginapi")
public class LoginController {
	
	
	@Autowired
	  AuthenticationManager authenticationManager;
 
	  @Autowired
	  AppUserRepository userRepository;
	
	@Autowired
	  JwtUtil jwtUtils;
	
	@GetMapping("/login")
	  public ResponseEntity<?> authenticateUser(@RequestBody AppUser appuser) {
		System.out.println(appuser);
		
	    Authentication authentication = authenticationManager.authenticate(
	        new UsernamePasswordAuthenticationToken(appuser.getUserName(), appuser.getPassword()));
	    
      System.out.println("authentication success");
	    SecurityContextHolder.getContext().setAuthentication(authentication);
	    String jwt = jwtUtils.generateJwtToken(authentication);
	    System.out.println(jwt);
	    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();    
	    List<String> roles = userDetails.getAuthorities().stream()
	        .map(item -> item.getAuthority())
	        .collect(Collectors.toList());
	    
	    LoginResponse response=new LoginResponse(appuser.getUserName(), appuser.getPassword(), jwt);
	    
 
	    return ResponseEntity.ok(response);
	  }
 
}