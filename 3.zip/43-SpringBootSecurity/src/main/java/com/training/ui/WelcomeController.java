package com.training.ui;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.config.SecurityConfig;

@RestController
@RequestMapping("/welcome")
public class WelcomeController {

    private final SecurityConfig securityconfig;


    WelcomeController(SecurityConfig securityconfig) {
        this.securityconfig = securityconfig;
    }
	
	
	@GetMapping("/api")
	public String f1() {
		return "Welcome";
		
	}
	
	

}
