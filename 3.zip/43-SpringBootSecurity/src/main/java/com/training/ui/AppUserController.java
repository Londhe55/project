package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.AppUser;
import com.training.service.AppUserService;

@RestController
@RequestMapping("/appuserapi")
public class AppUserController {
	
	@Autowired
	AppUserService service;
	
	@PostMapping("/add")
	public AppUser f1(@RequestBody AppUser appUser) {

		return this.service.saveAppUser(appUser);
	}

}
