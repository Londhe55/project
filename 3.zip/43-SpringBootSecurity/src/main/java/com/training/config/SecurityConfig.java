package com.training.config;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;

import org.springframework.security.authentication.AuthenticationManager;

import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;

import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;


import com.training.jwt.JwtFilter;
import com.training.service.UserDetailsImplService;

@Configuration

@EnableWebSecurity

public class SecurityConfig {

	@Autowired

	private JwtFilter jwtFilter;


	@Bean

	public PasswordEncoder passwordEncoder() {

		return new BCryptPasswordEncoder();

	}

	@Bean

	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

		System.out.println("Security Config filter chain");

		http

		.csrf(csrf->csrf.disable())

		.authorizeHttpRequests(auth->auth

				.requestMatchers("/appuserapi/**","/loginapi/login")//permitted for all users like add appusers 

				.permitAll()

				.requestMatchers("/welcome/api").hasAnyRole("admin")//these want authentication ,403 error without authentiaction if you run daily run

				.requestMatchers("/goodbye/api").hasAnyRole("admin","user")

				.anyRequest().authenticated()

		).addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

		return http.build();

	}

	@Bean

    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {

        return config.getAuthenticationManager();

    }

	@Autowired//---

	private UserDetailsImplService userDetailsService;
 


}
 