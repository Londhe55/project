package com.training.db;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.training.model.Customer;

public class CustomerDAO {
	
	
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	
	
	
	public String saveCustomer(Customer customer) {
		
		String insertQuery = "insert into Customer values(?,?,?,?)";
		
		
		this.jdbcTemplate.update(insertQuery,
				customer.getId(), 
				customer.getName(), 
				customer.getAge(), 
				customer.getCity());
		return "Successfully Saved";
	}
	

	public String updateCustomer(Customer customer) {
		
		String updateQuery = "update Customer set customername = ?, customerage = ?, customercity=? where customerid=?";		
		
		this.jdbcTemplate.update(updateQuery, 
				customer.getName(), 
				customer.getAge(), 
				customer.getCity(),
				customer.getId());
		return "Successfully Updated";
	}
	
	
	
public String deleteCustomer(int id) {
		
		String deleteQuery = "delete from Customer where customerid=?";		
		
		this.jdbcTemplate.update(deleteQuery,id);
		return "Successfully Deleted";
	}


public List<Customer> readAll(){
	
	String qrey = "select * from customer";
	
	List<Customer> list = this.jdbcTemplate.query(qrey, new CustomerRowMapper());
	return list;
}
	
public Customer searchCustomer(int id) {
    
    String qry = "select * from customer where customerid = ?";
    
    Customer c = this.jdbcTemplate.queryForObject(qry, new CustomerRowMapper(), id);
    
    return c;
}
	
	

	
}