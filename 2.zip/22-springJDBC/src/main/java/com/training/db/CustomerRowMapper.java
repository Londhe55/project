package com.training.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.model.Customer;

public class CustomerRowMapper implements RowMapper<Customer>{

	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Customer c = new Customer();
		c.setId(rs.getInt(1));
		c.setName(rs.getString(2));
		c.setAge(rs.getInt(3));
		c.setCity(rs.getString(4));
		
		return c;
	}

}
