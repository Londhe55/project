package com.training.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.db.CustomerDAO;
import com.training.model.Customer;

public class App {
	
	static void newCustomer() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Customer ID ");
		int id = Integer.parseInt(scanner.nextLine());
		
		System.out.print("Enter name");
		String name = scanner.nextLine();
		
		System.out.print("Enter Age");
		int age = Integer.parseInt(scanner.nextLine());
		
		System.out.print("Enter city");
		String city = scanner.nextLine();
		
		
		Customer customer = new Customer(id, name, age, city);
		System.out.println(customer);
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		
		CustomerDAO dao = (CustomerDAO) context.getBean("customerDAO");
		System.out.println(dao.saveCustomer(customer));
	}
	
	
	
	static void updateCustomer() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Customer ID ");
		int id = Integer.parseInt(scanner.nextLine());
		
		System.out.print("Enter name");
		String name = scanner.nextLine();
		
		System.out.print("Enter Age");
		int age = Integer.parseInt(scanner.nextLine());
		
		System.out.print("Enter city");
		String city = scanner.nextLine();
		
		
		Customer customer = new Customer(id, name, age, city);
		System.out.println(customer);
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		
		CustomerDAO dao = (CustomerDAO) context.getBean("customerDAO");
		System.out.println(dao.updateCustomer(customer));
	}
	
	
	
	static void deleteCustomer() {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Customer ID ");
		int id = Integer.parseInt(scanner.nextLine());
		

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		
		CustomerDAO dao = (CustomerDAO) context.getBean("customerDAO");
		System.out.println(dao.deleteCustomer(id));
	}
	
	static void displayAllCustomers() {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

		CustomerDAO dao = (CustomerDAO) context.getBean("customerDAO");
		System.out.println(dao.readAll());
	}
	
	

	static void findCustomer() {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Customer ID ");
		int id = Integer.parseInt(scanner.nextLine());
		

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		
		CustomerDAO dao = (CustomerDAO) context.getBean("customerDAO");
		System.out.println(dao.searchCustomer(id));
	}
	
	
	
	
    public static void main(String[] args) {
    	
//    	newCustomer();
    	
//    	updateCustomer();
    	
//    	deleteCustomer();
    	
//    	displayAllCustomers();
    	
    	findCustomer();
    	

    	
    }
}
