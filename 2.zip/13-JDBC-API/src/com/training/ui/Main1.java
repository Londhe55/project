package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.training.bean.Student;



public class Main1 {

	public static void main(String[] args) {

		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter the Student Roll Number :");
		int rollNumber = Integer.parseInt(scanner.nextLine());
		
		System.out.print("Enter the Student Name :");
		String name = scanner.nextLine();
		
		System.out.print("Enter the Student Marks :");
		double marks = Double.parseDouble(scanner.nextLine());
		
		
		Student student = new Student(rollNumber, name, marks);

		
		String  str= "INSERT INTO Student VALUES(?,?,?)";
		
		
		
		// Step 1
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");   // Driver Class
			System.out.println("Driver Loaded Successfully ");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		 
		
		// Step 2  : Establish a connection with database
		
		
		String url = "jdbc:mysql://localhost:3306/ctsdb";
		String username = "root";
		String password = "root";

		Connection connection = null;
		try {
			 connection= DriverManager.getConnection(url,username,password);
			System.out.println(" DB Connection Eastablished Successfully");

		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		// Step 3 : Execute a Query
		
		
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(str);
			System.out.println("PreparedStatement Created Successfully");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 4 : Run the Query 
		
		try {
			
			preparedStatement.setInt(1, student.getRollNumber());
			preparedStatement.setString(2, student.getName());
			preparedStatement.setDouble(3, student.getMarks());
			
			
			int result = preparedStatement.executeUpdate();
			
			if (result > 0) {
				System.out.println("Student Added Successfully");
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 5 ; Close the connection
		
		
		try {
			preparedStatement.close();
			connection.close();
			System.out.println("Connection Closed");
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

}
