package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Main3 {
	
	public static void main(String[] args) {
		
		// No Input read all Student and display
		
		

		String  str= "SELECT * FROM Student";
		
		
		
		// Step 1
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");   // Driver Class
			System.out.println("Driver Loaded Successfully ");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		 
		
		
		// Step 2  : Establish a connection with database
		
		String url = "jdbc:mysql://localhost:3306/ctsdb";
		String username = "root";
		String password = "root";

		Connection connection = null;
		try {
			 connection= DriverManager.getConnection(url,username,password);
			System.out.println(" DB Connection Eastablished Successfully");

		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 3 : Execute a Query
		
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(str);
			System.out.println("PreparedStatement Created Successfully");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 4 : Run the Query 
		
		ResultSet resultSet = null;
		
		try {
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				
				System.out.print(resultSet.getInt("rollNumber") + "  ");
				System.out.print(resultSet.getString("name") +"  ");
				System.out.println(resultSet.getDouble("marks")+"  ");
			}
			
			
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 5 ; Close the connection
		
		
		try {
			preparedStatement.close();
			connection.close();
			System.out.println("Connection Closed");
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
