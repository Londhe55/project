package pack2;

public class Main2 {
	
	public static void main(String[] args) {
		
		
		int[] arr = {1,2,3,4};
		
		System.out.println(arr[2]);
		
		
		try {
			System.out.println(arr[20]);
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("Finally Block");
		}
	}

}

// We can add multiple catch block

// one try block may contain multiple catch block

// The Exception which extends Runtime Exception are called as the UnChecked Exception


