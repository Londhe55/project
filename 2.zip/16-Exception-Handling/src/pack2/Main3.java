
package pack2;

import pack1.Employee;

public class Main3 {
	
	public static void main(String[] args) throws Exception{
		
		
		// Here you have to use throws or try catch otherswise it will give an error for 		emp.setSalary(5000);

		Employee emp = new Employee();
		emp.setSalary(5000);
		System.out.println(emp.getSalary());
		
		
		emp.setSalary(-5000);
		System.out.println(emp.getSalary());
	}

}


// try can not stand alone