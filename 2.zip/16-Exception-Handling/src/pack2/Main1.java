package pack2;

public class Main1 {

	public static void main(String[] args) {
		
		System.out.println("program Begins");
		
		int a = 100;
		int b = 0;
		
		int c =0;
		try {
			c = a/b;
			System.out.println(c);
		}catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		
	
		
		System.out.println("Program Ends");
	}
}
