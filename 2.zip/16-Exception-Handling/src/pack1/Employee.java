package pack1;

public class Employee {
	
	double salary;

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) throws Exception {
		
//		if(salary < 0) {
//			RuntimeException exception = new RuntimeException("Negative Salary");
//			throw exception;
//		}
//		
		
		
		// Only for Checked Exception
		if(salary < 0) {
			Exception exception = new Exception("Negative Salary");
			throw exception;
		}
		
		
//		if(salary < 0) {
//			Exception exception = new Exception("Negative Salary");
//			try {
//				throw exception;
//			}catch (Exception e) {
//				System.out.println(e.getMessage());
//			}
//		}
//		
		
		
		this.salary = salary;
	}
	
	
	
	

}
