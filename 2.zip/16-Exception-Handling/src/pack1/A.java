package pack1;

import java.io.IOException;
import java.sql.SQLException;

class A {
	
	public void m1() throws IOException , SQLException{
		
	}

}

class B extends A{
	
	@Override
	public void m1() throws SQLException{
		
	}
}

// Overriddin method need not to throws Exception  
 // ANy Number of Runtime Exception
// Need not to throws all Excpetion