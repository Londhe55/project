package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.training.bean.Employee;

public class Main9 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter the Employee Id to view Details :");
		int id = Integer.parseInt(scanner.nextLine());
		
		
		
		
		
		

		
		String  str= "SELECT * FROM EMPLOYEE WHERE id =?";
		
		// Step 1
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");   // Driver Class
			System.out.println("Driver Loaded Successfully ");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		 
		// Step 2  : Establish a connection with database
		
		
		String url = "jdbc:mysql://localhost:3306/ctsdb";
		String username = "root";
		String password = "root";

		Connection connection = null;
		try {
			 connection= DriverManager.getConnection(url,username,password);
			System.out.println(" DB Connection Eastablished Successfully");

		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		// Step 3 : Execute a Query
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(str);
			System.out.println("PreparedStatement Created Successfully");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 4 : Run the Query 
		
		ResultSet resultSet = null;
		
		try {
			
			preparedStatement.setInt(1, id);
			resultSet = preparedStatement.executeQuery();
			
			 
			
			if(resultSet.next()) {
				System.out.print(resultSet.getInt("id") + "  ");
				System.out.print(resultSet.getString("name") +"  ");
				System.out.print(resultSet.getString("city")+"  ");
				System.out.print(resultSet.getString("gender")+"  ");
				System.out.println(resultSet.getDouble("salary")+"  ");
				
				
				int eid = resultSet.getInt(1);
				String eName = resultSet.getString(2);
				String eCity = resultSet.getString(3);
				String eGender = resultSet.getString(4);
				double eSalary = resultSet.getDouble(5);
				
				Employee e = new Employee(eid, eName, eCity, eGender, eSalary);
				System.out.println(e);
			}else {
				System.out.println("Record Not Found");
			}
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 5 ; Close the connection
		
		
		try {
			preparedStatement.close();
			connection.close();
			System.out.println("Connection Closed");
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
