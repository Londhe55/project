package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.training.bean.Employee;

public class Main7 {

	public static void main(String[] args) {

		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter the Employee Id :");
		int id = Integer.parseInt(scanner.nextLine());
		
		System.out.print("Enter the Employee Name :");
		String name = scanner.nextLine();
		
		System.out.print("Enter the Employee City :");
		String city = scanner.nextLine();
		
		System.out.print("Enter the Employee Gender :");
		String gender = scanner.nextLine();
		
		
		System.out.print("Enter the Employee Salary :");
		double salary = Double.parseDouble(scanner.nextLine());
		
		
		Employee employee = new Employee(id, name, city, gender, salary);
		System.out.println(employee);
		
		
		
		

		
		String  str= "UPDATE EMPLOYEE set name = ?, city =? , gender =?, salary = ? where id= ?";
		
		// Step 1
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");   // Driver Class
			System.out.println("Driver Loaded Successfully ");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		 
		// Step 2  : Establish a connection with database
		
		
		String url = "jdbc:mysql://localhost:3306/ctsdb";
		String username = "root";
		String password = "root";

		Connection connection = null;
		try {
			 connection= DriverManager.getConnection(url,username,password);
			System.out.println(" DB Connection Eastablished Successfully");

		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		// Step 3 : Execute a Query
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(str);
			System.out.println("PreparedStatement Created Successfully");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 4 : Run the Query 
		
		try {
			
			preparedStatement.setString(1, employee.getEmpName());
			preparedStatement.setString(2, employee.getEmpCity());
			preparedStatement.setString(3, employee.getEmpGender());
			preparedStatement.setDouble(4, employee.getEmpSalary());
			preparedStatement.setInt(5, employee.getEmpId());

			
			
			int result = preparedStatement.executeUpdate();
			
			if (result > 0) {
				System.out.println("Employee Updated Successfully");
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 5 ; Close the connection
		
		
		try {
			preparedStatement.close();
			connection.close();
			System.out.println("Connection Closed");
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
