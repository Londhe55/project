package com.training.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Main3 {

	public static void main(String[] args) {

		
String  str= "UPDATE EMPLOYEE SET city = 'Mumbai' where id =102";
		
		// Step 1
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");   // Driver Class
			System.out.println("Driver Loaded Successfully ");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		 
		// Step 2  : Establish a connection with database
		
		
		String url = "jdbc:mysql://localhost:3306/ctsdb";
		String username = "root";
		String password = "root";

		Connection connection = null;
		try {
			 connection= DriverManager.getConnection(url,username,password);
			System.out.println(" DB Connection Eastablished Successfully");

		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		// Step 3 : Execute a Query
		Statement statement = null;
		
		try {
			statement = connection.createStatement();
			System.out.println("Statement Created Successfully");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 4 : Run the Query 
		
		try {
			int result = statement.executeUpdate(str);
			
			if(result > 0) {
				System.out.println("Recored Updated Successfully");
			}else {
				System.out.println("Recored Not Added");
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		
		// Step 5 ; Close the connection
		
		
		try {
			statement.close();
			connection.close();
			System.out.println("Connection Closed");
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
