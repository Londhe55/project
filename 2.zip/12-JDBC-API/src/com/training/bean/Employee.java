package com.training.bean;

import java.util.Objects;

public class Employee {
	
	private int empId;
	private String empName;
	private String empCity;
	private String empGender;
	private Double empSalary;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpCity() {
		return empCity;
	}
	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(Double empSalary) {
		this.empSalary = empSalary;
	}
	
	
	@Override
	public String toString() {
		return "\n Employee [empId=" + empId + ", empName=" + empName + ", empCity=" + empCity + ", empGender=" + empGender
				+ ", empSalary=" + empSalary + "]";
	}
	
	
	
	
	public Employee(int empId, String empName, String empCity, String empGender, double salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
		this.empGender = empGender;
		this.empSalary = salary;
	}
	@Override
	public int hashCode() {
		return Objects.hash(empId);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return empId == other.empId;
	}
	
	
	
	
	
	
	

}
