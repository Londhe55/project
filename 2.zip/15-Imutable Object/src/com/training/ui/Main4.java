package com.training.ui;

public class Main4 {

	
	public static void main(String[] args) {
		
		
		StringBuilder str = new StringBuilder("abc");    // Not Thread  Safe
		str.append("xyz");
		
		System.out.println(str);
		
		str.append(100);
		
		System.out.println(str);
		
		
		StringBuffer str1 = new StringBuffer("abc");  // Thread Safe 
		
		str1.append(100);
		
		System.out.println(str1);
	}
}
