package com.training.ui;

public class Main2 {
	
	public static void main(String[] args) {
		
		String s = new String("Welcome");
		
		System.out.println(s.toUpperCase());
		
		System.out.println(s);
		
		String x = new String("CTS");
		String y = new String("CTS");
		
		System.out.println(x == y);
		
		System.out.println(x.equals(y));
		System.out.println(x.equalsIgnoreCase(y));
		
		String a = "welcome";
		String b = "welcome";
		System.out.println(a == b);
	}

}
