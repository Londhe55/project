package com.training.ui;

public class Main3 {
	
	public static void main(String[] args) {
		
		Integer i1 = Integer.valueOf(10);    // Imutable Object
		
		
		Integer i2 = Integer.valueOf(20);
		
		System.out.println(i1.equals(i2));
		
		System.out.println(i1 == i2);
		
		int r = i1.compareTo(i2);
		System.out.println(r);
		
		// String , Integer , Double all are Imutable Objject
		
		
		
	}

}
