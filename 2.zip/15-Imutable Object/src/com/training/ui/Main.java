package com.training.ui;

import com.training.bean.Circle;
public class Main {

	public static void main(String[] args) {

		
		// Imutable Object 
		// because we can't change the Object
		Circle circle = new Circle(10);
		
		System.out.println(circle);
		
		
//		public Circle enLarge(int size) {
////			this.radius = this.radius +size;
//			Circle = temp new Circle(this.radius +size);
//			return temp;
//		}
		
		
	}

}
