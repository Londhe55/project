package com.training.bean;

public class Circle {
	
	final int radius;

	
	
	public Circle(int radius) {
		super();
		this.radius = radius;
	}

	public int getRadius() {
		return radius;
	}



	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}
	
	
	

}
