package com.training.ui;

import com.training.model.IdGenerator;

public class Main1 {

	public static void main(String[] args) {

		IdGenerator generator = IdGenerator.getInstance();
		System.out.println(generator.getnext());
		System.out.println(generator.getnext());
		System.out.println(generator.getnext());
		System.out.println(generator.getnext());
		
		
		
		IdGenerator generator2 = IdGenerator.getInstance();
		System.out.println(generator2.getnext());
		System.out.println(generator2.getnext());
		System.out.println(generator2.getnext());
		System.out.println(generator2.getnext());
		
		
		IdGenerator generator3 = IdGenerator.getInstance();
		System.out.println(generator3.getnext());
		System.out.println(generator3.getnext());
		System.out.println(generator3.getnext());
		System.out.println(generator3.getnext());

	}
}
