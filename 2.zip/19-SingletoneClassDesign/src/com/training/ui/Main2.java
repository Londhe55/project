package com.training.ui;

import com.training.model.RollNumberGenerator;

public class Main2 {

	public static void main(String[] args) {

		// Return the Instance of RollNumberGenerator
		RollNumberGenerator generator1 = RollNumberGenerator.getInstance();
		
		System.out.println(generator1.getNextRollNumber());
		System.out.println(generator1.getNextRollNumber());
		System.out.println(generator1.getNextRollNumber());
		System.out.println(generator1.getNextRollNumber());
		System.out.println(generator1.getNextRollNumber());
		
		
		
		RollNumberGenerator generator2 =RollNumberGenerator.getInstance();
		
		System.out.println(generator2.getNextRollNumber());
		System.out.println(generator2.getNextRollNumber());
		System.out.println(generator2.getNextRollNumber());
		System.out.println(generator2.getNextRollNumber());
		System.out.println(generator2.getNextRollNumber());
		
		
		
		
		
		
		RollNumberGenerator generator3 = RollNumberGenerator.getInstance();
		
		System.out.println(generator3.getNextRollNumber());
		System.out.println(generator3.getNextRollNumber());
		System.out.println(generator3.getNextRollNumber());
		System.out.println(generator3.getNextRollNumber());
		System.out.println(generator3.getNextRollNumber());
	}

}
