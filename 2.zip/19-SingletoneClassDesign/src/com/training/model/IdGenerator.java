package com.training.model;


public class IdGenerator {
	
	int num =0;
	
	// Step 2
	static IdGenerator instance = null;
	
	
	// Step 3 
	static public IdGenerator getInstance() {
		if(instance == null) {
			instance = new IdGenerator();
		}
		return instance;
	}
	
	
	public int getnext() {
		
		return ++num;
	}
	
	// Step 1   ==> To make the class as the Singletone
	// You can't create of Object
	private IdGenerator() {
		
	}
	

}
