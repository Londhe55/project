package com.training.model;

public class RollNumberGenerator {
	
	int rollNumber=100;
	
	static RollNumberGenerator instance=null;
	
	
	static public RollNumberGenerator getInstance() {
		if(instance == null) {
			instance = new RollNumberGenerator();
		}
		return instance;
	}
	
	
	
	public int getNextRollNumber() {
		return ++rollNumber;
	}
	
	
	
	private RollNumberGenerator() {
		
	}

}
