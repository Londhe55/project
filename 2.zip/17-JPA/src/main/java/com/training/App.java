package com.training;
 
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

import java.util.List;

import com.training.model.Employee;
 

public class App {
	
	static void insert() {
		Employee e = new Employee(103,"Rohit","Male",8500.00);
		
		// EntityManagerFactory is responsible for reading persistence.xml file 
		// and also create the connection to the database
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		// EntityManager is interface responsible to talk to the database.
		// and using instance of EntityManager we can perform Insert (persist), Update, Delete, Fetch
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(e);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	
	// Read 
	static void read() {
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Employee e = em.find(Employee.class, 101);
		
		System.out.println(e);
		
		em.close();
	}
	
	// Upadte 
	static void update() {
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Employee e = em.find(Employee.class, 101);
		
		e.setSalary(10000.00);
		
		em.getTransaction().begin();
		em.merge(e);
		em.getTransaction().commit();
		
		
		em.close();
		emf.close();
	}
	
	
	
	// Delete
	
	static void delete() {
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Employee e = em.find(Employee.class, 101);
		
		em.getTransaction().begin();
		em.remove(e);
		em.getTransaction().commit();
		
		
		em.close();
		emf.close();
	}
	
	
	
	
	// Read  All
	static void readAll() {
		
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		String jpql ="select e from Employee e";
		
		Query q = em.createQuery(jpql);
		
		List<Employee> empList = q.getResultList();
		
		System.out.println(empList);
		
		Employee e = em.find(Employee.class, 101);
		
		System.out.println(e);
		
		em.close();
	}
	
	
	
	
	
    public static void main(String[] args) {
//        insert();
    	
    	
//    	read();
    	
//    	update();
    	
//    	delete();
    	
    	readAll();
        
    }
}
 