package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class Main2 {
	
	public static void main(String[] args) {
		
		List<String> countries = new LinkedList<String>();
		
		countries.add("India");
		countries.add("Afghanistan");
		countries.add("Russia");
		countries.add("Uk");
		
		
		// filter takes predictor Object
		countries.stream().filter((c) -> c.length() >6).forEach((c) -> System.out.println(c));
		
		
		
		
		List<String> filteredList = countries
										.stream()
										.filter((c) -> c.length() >= 5)
										.collect(Collectors.toList());
		
		
		System.out.println(filteredList);
	}

}
