package com.training.ui;

import java.util.List;

public class Main7 {

	public static void main(String[] args) {

		
		List<Integer> ints = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 99);
		
		
		boolean result =  ints
			.stream()
			.anyMatch((i) -> i>=100);
			
		System.out.println(result);
		
		
		boolean result2 = ints
							.stream()
							.allMatch((i) -> i>0);
		System.out.println(result2);
		
		
		
	}

}
