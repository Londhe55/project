
package com.training.ui;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.training.model.Sale;

public class Main6 {
	
	public static void main(String[] args) {
		
		
		Sale sale1 = new Sale(101, "Mohan", "Hydrabad", 5000.00, "Male");
		Sale sale2 = new Sale(102, "Sham", "Pune", 1000.00, "Male");
		Sale sale3 = new Sale(103, "Ram", "Mumbai", 6000.00, "Male");
		Sale sale4 = new Sale(104, "Vikas", "Hydrabad", 3000.00, "Male");
		Sale sale5 = new Sale(105, "Ashwini", "Solapur", 2000.00, "Female");
		Sale sale15 = new Sale(106, "Veer", "Delhi", 4000.00, "Male");
		Sale sale6 = new Sale(107, "Virat", "Chennai", 9000.00, "Male");
		Sale sale7 = new Sale(108, "Rohit", "Hydrabad", 8000.00, "Male");
		Sale sale8 = new Sale(109, "Sachin", "Bangalore", 7000.00, "Male");
		Sale sale9 = new Sale(110, "Sharmila", "Hydrabad", 5000.00, "Female");
		Sale sale10 = new Sale(111, "Surya", "Bangalore", 10000.00, "Male");
		
		
		
		Set<Sale> allSales = new HashSet<Sale>();
		
		allSales.add(sale1);
		allSales.add(sale2);
		allSales.add(sale3);
		allSales.add(sale4);
		allSales.add(sale5);
		allSales.add(sale6);
		allSales.add(sale7);
		allSales.add(sale8);
		allSales.add(sale9);
		allSales.add(sale10);
		allSales.add(sale15);
		
		
		
		double totalSales = allSales
								.stream()
								.mapToDouble(Sale :: getSalesAmount)
								.sum();
		
		System.out.println(totalSales);
		
		
		double maleTotalSales = allSales
									.stream()
									.filter( s -> s.getGender() == "Male")
									.mapToDouble(Sale :: getSalesAmount)
									.sum();
		
		
		System.out.println(maleTotalSales);
		
		
		
		
		double citySales = allSales
							.stream()
							.filter(s -> s.getCityName() == "Delhi")
							.mapToDouble(Sale :: getSaleId)
							.count();
		
		System.out.println(citySales);
		
		
		
		Map<String, List<Sale>> salesCityMap = allSales
											.stream()
											.collect(Collectors.groupingBy(Sale :: getCityName));
		
		System.out.println(salesCityMap);
		
		
		Map<String,Long> salesCityMap1 = allSales
												.stream()
												.collect(Collectors.groupingBy(Sale :: getCityName , Collectors.counting()));
		
										
		
		System.out.println(salesCityMap1);
		
		
		
		Map<String, Double> salesCityAmountMap = allSales
													.stream()
													.collect(Collectors.groupingBy(Sale :: getCityName, Collectors.summingDouble(Sale :: getSalesAmount)));


		System.out.println(salesCityAmountMap);
		
		
		
		
		Map<String, Double> gendercityAmountMap = allSales
														.stream()
														.collect(Collectors.groupingBy(Sale :: getGender, Collectors.summingDouble(Sale :: getSalesAmount)));
		
		System.out.println(gendercityAmountMap);
		
		
		// If you want to find min , max, then you must comapre , comparable
		
		
		
		System.out.println("Ascending Order");
		allSales
				.stream()
				.sorted((s1,s2) -> Double.compare(s1.getSaleId(), s2.getSaleId()))
				.forEach(s -> System.out.println(s));
		
		
		System.out.println("Ascending Order Sales Amount");
		allSales
				.stream()
				.sorted((s1,s2) -> Double.compare(s1.getSalesAmount(), s2.getSalesAmount()))
				.forEach(s -> System.out.println(s));
		
		
		
		
	}

}
