package com.training.ui;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.training.model.Employee;

public class Main5 {

	public static void main(String[] args) {

		
		Employee e1 = new Employee(101, "Ram", "Male", 3000.00, 'B');
		Employee e2 = new Employee(102, "Shalini", "Female", 5000.00, 'A');
		Employee e3 = new Employee(103, "Sham", "Male", 8000.00, 'A');
		Employee e4 = new Employee(104, "Reshmi", "Female", 12000.00, 'C');
		Employee e5 = new Employee(105, "Vikas", "Male", 7000.00, 'A');
		Employee e6 = new Employee(105, "Raj", "Male", 7000.00, 'B');
		
		
		
		Set<Employee> empSet = new HashSet<Employee>();
		
		empSet.add(e1);
		empSet.add(e3);
		empSet.add(e2);
		empSet.add(e4);
		empSet.add(e5);
		empSet.add(e6);
		
		
		List<Employee> aGradeEmployees;
		
		aGradeEmployees = empSet
							.stream()
							.filter(e -> e.getGrade() == 'A')
							.collect(Collectors.toList());
		
		System.out.println(aGradeEmployees);
		
		
		List<String> nameList;
//		
		nameList = empSet
					.stream()
					.map(e -> e.getName())
					.collect(Collectors.toList());
//		System.out.println(nameList);
		
		
		
		List<Double> salrayList;
		
		salrayList = empSet
					.stream()
//					.map(e -> e.getSalary())
					.map(Employee :: getSalary)             // Method Refrence
					.collect(Collectors.toList());
		
		System.out.println(salrayList);
		
		
		// Method reference
//		double totalSalary = empSet
//				.stream()
//				.mapToDouble(e -> e.getSalary())
//				.sum();
//
//		System.out.println(totalSalary);
		
		double totalSalary = empSet
								.stream()
								.mapToDouble(e -> e.getSalary())
								.sum();
		
		System.out.println(totalSalary);
		
		
//		int idList = empSet
//				.stream()
//				.mapToInt(e -> e.getId())
//				.forEach(e -> System.out.println(e));
	}

}
