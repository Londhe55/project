package com.training.ui;

import java.nio.channels.Pipe.SourceChannel;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.training.model.Circle;
import com.training.model.Square;

public class Main4 {
	
	
	public static void main(String[] args) {
		
		Set<Circle> circles = new HashSet<Circle>();
		
		circles.add(new Circle(10));
		circles.add(new Circle(5));
		circles.add(new Circle(12));
		circles.add(new Circle(7));
		
		
		List<Circle> bigCircles;
		
		bigCircles = circles
				.stream()
				.filter(c -> c.getRadius() > 10)
				.collect(Collectors.toList());
		
		
		System.out.println(bigCircles);
		
		
		
		
		List<Square> squaList = new LinkedList<Square>();
		
		squaList.add(new Square(10));
		
		squaList.add(new Square(2));
		squaList.add(new Square(15));
		squaList.add(new Square(20));
		squaList.add(new Square(5));
		squaList.add(new Square(30));
		
		
		List<Square> bigSquares;
		
		bigSquares = squaList
				.stream()
				.filter(s -> s.getSize() < 5)
				.collect(Collectors.toList());
		
		System.out.println(bigSquares);
		
	}

}
