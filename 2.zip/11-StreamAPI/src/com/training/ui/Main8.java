package com.training.ui;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.training.model.Course;
import com.training.model.Sale;

public class Main8 {

	public static void main(String[] args) {

		
		
		Course c1 = new Course(1, "HTML", "Web", 2500.00, 3);
		Course c2 = new Course(2, "CSS", "Web", 1500.00, 2);
		Course c3 = new Course(3, "MySQL", "DataBase", 1000.00, 1);
		Course c4 = new Course(4, "React", "java Script", 3500.00, 4);
		Course c5 = new Course(5, "Java", "Programming Language", 5500.00, 6);
		Course c6 = new Course(6, "HTML", "Web", 2500.00, 3);
		Course c7 = new Course(7, "Python", "Programming Language", 3000.00, 4);
		Course c8 = new Course(8, "HTML", "Web", 4000.00, 5);
		Course c9 = new Course(9, "JS", "java Script", 1700.00, 2);
		Course c10 = new Course(10, "Angular", "java Script", 4500.00, 4);
		
		
		
		
		Set<Course> allCoureses = new TreeSet<Course>();
		
		
		allCoureses.add(c1);
		allCoureses.add(c2);
		allCoureses.add(c3);
		allCoureses.add(c4);
		allCoureses.add(c5);
		allCoureses.add(c6);
		allCoureses.add(c7);
		allCoureses.add(c8);
		allCoureses.add(c9);
		allCoureses.add(c10);
		
		
		
		
		
		
	// for each with    
//				==> sorted(), map()
		
		
		
		allCoureses.stream().forEach(s -> System.out.println(s));
		
		allCoureses.stream().sorted().forEach(s -> System.out.println(s));
		
		allCoureses.stream().distinct().forEach(s -> System.out.println(s));
		
		allCoureses.stream().map(s -> s.equals("Web")).forEach(s -> System.out.println(s));
		
		
		
		allCoureses.stream().filter((s) -> s.getDurationInWeeks() > 3).forEach(s -> System.out.println(s));
		
		
		allCoureses.stream().filter(s -> s.getFees() > 2000).forEach(s -> System.out.println(s));
		
		
		allCoureses.stream().filter(s -> s.getDurationInWeeks() > 4).collect(Collectors.toList());
		
		
		
		List<Double> fees;
		
		fees = allCoureses
					.stream()
					.map(s -> s.getFees())
					.collect(Collectors.toList());
		
		System.out.println(fees);
		
		
		List<String> nameList;
		
		nameList = allCoureses
					.stream()
					.map(s -> s.getSubjectName())
					.collect(Collectors.toList());
		
		System.out.println(nameList);
		
		
		List<Integer> idList;
		
		idList = allCoureses
					.stream()
					.map(s -> s.getId())
					.collect(Collectors.toList());
		
		System.out.println(idList);
		
		
		List<Integer> durationInWeekList;
		
		durationInWeekList = allCoureses
					.stream()
					.map(s -> s.getDurationInWeeks())
					.collect(Collectors.toList());
		
		System.out.println(durationInWeekList);
		
		
		
		
		
		double slaryAmount = allCoureses
								.stream()
								.mapToDouble(Course :: getFees)
								.sum();
		System.out.println(slaryAmount);
		
		
		
		double subjectNameCount = allCoureses
				.stream()
				.filter(s -> s.getSubjectName() == "HTML")
				.mapToDouble(Course :: getId)
				.count();

		System.out.println(subjectNameCount);
		
		
		
		// Return the Subject Name with all entries
		Map<String, List<Course>> feesSubjectName = allCoureses
				.stream()
				.collect(Collectors.groupingBy(Course ::getSubjectName ));

		System.out.println(feesSubjectName);
		
		
		
		// Group the entries based upon category 
		Map<String, List<Course>> feesCategorytName = allCoureses
				.stream()
				.collect(Collectors.groupingBy(Course ::getCategory ));

		System.out.println(feesCategorytName);
		
		
		
		
		
		
		
	}

}
