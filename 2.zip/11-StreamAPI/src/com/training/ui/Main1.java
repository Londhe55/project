package com.training.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Main1 {

	public static void main(String[] args) {

//		List<String> cityNames = new ArrayList<String>();
//		
//		
//		cityNames.add("Mumbai");
//		cityNames.add("Delhi");
//		cityNames.add("Kolkatta");
//		cityNames.add("Mumbai");
//		cityNames.add("Pune");
//		
//		cityNames.stream().forEach((cn) -> System.out.println(cn));
//		
//		System.out.println();
//		cityNames.stream().forEach((cn) -> System.out.println(cn.toUpperCase()));
//		
//		System.out.println();
//		cityNames.stream().sorted().forEach( (cn) -> System.out.println(cn));
//		
//		System.out.println();
//		cityNames.stream().forEach((cn) -> System.out.println(cn));
//		
//		System.out.println();
//		cityNames.stream().distinct().forEach((cn) -> System.out.println(cn));
//		
//		
//		System.out.println();
//		cityNames.stream().map((s) -> s.length()).forEach((l) -> System.out.println(l));
//		
//		
//		System.out.println();
//		System.out.println(cityNames.stream().distinct().count());
		
		
		
//		List<Double> prices = new ArrayList<Double>();
//		
//		prices.add(67.00);
//		prices.add(45.00);
//		prices.add(90.3);
//		prices.add(80.0);
//		prices.add(72.8);
//		
		
		// Minimum
//		Optional<Double> result1 = prices.stream().min((d1, d2) -> Double.compare(d1, d2));
//		if(result1.isPresent()) {
//			System.out.println(result1.get());
//		}
//		
//		
//		
//		// Maximum
//		Optional<Double> result2 = prices.stream().max((d1, d2) -> Double.compare(d1, d2));
//		if(result2.isPresent()) {
//			System.out.println(result2.get());
//		}
		
		
		
		List<Integer> ages = new ArrayList<Integer>();
		
		
		ages.add(22);
		ages.add(23);
		ages.add(28);
		ages.add(25);
		ages.add(20);
		
		
		ages.stream().forEach((a) -> System.out.println(a));
		
		System.out.println("Distinct");
		ages.stream().distinct().forEach((a) -> System.out.println(a));
		
		
		// Minimum
		System.out.println("Minimum");
		Optional<Integer> result1 = ages.stream().min((i1, i2) -> Integer.compare(i1, i2));
		
		if(result1.isPresent()) {
			System.out.println(result1.get());
		}
		
		
		System.out.println("Maximum");
		Optional<Integer> result2 = ages.stream().max((i1, i2) -> Integer.compare(i1, i2));
		Optional<Integer> max = ages.stream().max(Integer::compare);
		System.out.println(max.get());
		
		if(result2.isPresent()) {
			System.out.println(result2.get());
		}
		
		
		System.out.println("Sorted");
		ages.stream().sorted().forEach((a) -> System.out.println(a));
		
		
	
		
		
		
	}

}


// Stram API Privides different operation 
// Stram API contain only one terminal operation a
// Any number of intermediate opertaion may be prsent 
