package com.training.model;

import java.util.Objects;

public class Sale {
	
	
	private int saleId;
	private String salesPersonName;
	private String cityName;
	private double salesAmount;
	private String gender;
	
	
	
	
	public Sale(int saleId, String salesPersonName, String cityName, double salesAmount, String gender) {
		super();
		this.saleId = saleId;
		this.salesPersonName = salesPersonName;
		this.cityName = cityName;
		this.salesAmount = salesAmount;
		this.gender = gender;
	}







	public int getSaleId() {
		return saleId;
	}




	public void setSaleId(int saleId) {
		this.saleId = saleId;
	}




	public String getSalesPersonName() {
		return salesPersonName;
	}




	public void setSalesPersonName(String salesPersonName) {
		this.salesPersonName = salesPersonName;
	}




	public String getCityName() {
		return cityName;
	}




	public void setCityName(String cityName) {
		this.cityName = cityName;
	}




	public double getSalesAmount() {
		return salesAmount;
	}




	public void setSalesAmount(double salesAmount) {
		this.salesAmount = salesAmount;
	}




	public String getGender() {
		return gender;
	}




	public void setGender(String gender) {
		this.gender = gender;
	}




	@Override
	public String toString() {
		return "\n Sale [saleId=" + saleId + ", salesPersonName=" + salesPersonName + ", cityName=" + cityName
				+ ", salesAmount=" + salesAmount + ", gender=" + gender + "]";
	}




	@Override
	public int hashCode() {
		return Objects.hash(saleId);
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sale other = (Sale) obj;
		return saleId == other.saleId;
	}
	
	
	
	
	
	
	
	
	
	

}
