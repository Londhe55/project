package com.training.model;

import java.util.Objects;

public class Course implements Comparable<Course>{
	
	
	
	private int id;
	private String subjectName;
	private String category;
	private double fees;
	private int durationInWeeks;
	
	
	
	public Course(int id, String subjectName, String category, double fees, int durationInWeeks) {
		super();
		this.id = id;
		this.subjectName = subjectName;
		this.category = category;
		this.fees = fees;
		this.durationInWeeks = durationInWeeks;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getSubjectName() {
		return subjectName;
	}



	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public double getFees() {
		return fees;
	}



	public void setFees(double fees) {
		this.fees = fees;
	}



	public int getDurationInWeeks() {
		return durationInWeeks;
	}



	public void setDurationInWeeks(int durationInWeeks) {
		this.durationInWeeks = durationInWeeks;
	}



	@Override
	public String toString() {
		return "\n Course [id=" + id + ", subjectName=" + subjectName + ", category=" + category + ", fees=" + fees
				+ ", durationInWeeks=" + durationInWeeks + "]";
	}



	@Override
	public int hashCode() {
		return Objects.hash(id);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		return id == other.id;
	}



	@Override
	public int compareTo(Course o) {
		return Double.compare(this.fees, o.fees);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
