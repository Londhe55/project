package com.training.model;

public class Loan {

	private String loanId;
	private String customername;
	private double amount;
	private int tenure;
	public Loan(String loanId, String customername, double amount, int tenure) {
		super();
		this.loanId = loanId;
		this.customername = customername;
		this.amount = amount;
		this.tenure = tenure;
	}
	public Loan() {
		super();
	}
	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", customername=" + customername + ", amount=" + amount + ", tenure=" + tenure
				+ "]";
	}
	
	
	
	
	
}
