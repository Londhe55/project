package com.training.model;

public class Address {
	
	private String doorNumber;
	private String areaname;
	private String city;
	private String pincode;
	public Address(String doorNumber, String areaname, String city, String pincode) {
		super();
		this.doorNumber = doorNumber;
		this.areaname = areaname;
		this.city = city;
		this.pincode = pincode;
	}
	public Address() {
		super();
	}
	public String getDoorNumber() {
		return doorNumber;
	}
	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}
	public String getAreaname() {
		return areaname;
	}
	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [doorNumber=" + doorNumber + ", areaname=" + areaname + ", city=" + city + ", pincode="
				+ pincode + "]";
	}
	
	
	
	

}
