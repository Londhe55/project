package com.training.model;

public class Bank {
	
	
	String bankname;
	String headoffice;
	@Override
	public String toString() {
		return "Bank [bankname=" + bankname + ", headoffice=" + headoffice + "]";
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getHeadoffice() {
		return headoffice;
	}
	public void setHeadoffice(String headoffice) {
		this.headoffice = headoffice;
	}
	
	
	

}
