package com.training.model;

public class Customer {
	
	
	String customerName;
	String customerGender;
	double balanceAmount;
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerGender=" + customerGender + ", balanceAmount="
				+ balanceAmount + "]";
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerGender() {
		return customerGender;
	}
	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}
	public double getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	
	
	

}
