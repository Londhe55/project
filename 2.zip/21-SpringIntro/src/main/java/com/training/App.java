package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.Address;
import com.training.model.Bank;
import com.training.model.Customer;
import com.training.model.Employee;
import com.training.model.HelloWorld;
import com.training.model.Loan;
import com.training.model.Square;

public class App 
{
    public static void main( String[] args )
    {
        
    	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
    	
    	HelloWorld obj = (HelloWorld) context.getBean("hw");
    	
    	System.out.println(obj);
    	
    	
    	Bank bank = context.getBean(Bank.class);    		// When you have only one bean then it is valid 
//    	Bank bank1 = (Bank) context.getBean("bank");       // This is also valid
//    	Object bank2 = context.getBean("bank");			   // This is also valid
    	System.out.println(bank);
    	
    	Customer customer = context.getBean(Customer.class);
    	
    	System.out.println(customer);
    	
    	
    	Loan loan = context.getBean(Loan.class);
    	System.out.println(loan);
    	
    	Square s1,s2;
    	
    	s1 = context.getBean(Square.class);
    	System.out.println(s1);
    	s1.setSize(200);
    	System.out.println(s1);
    	
    	
    	s2 = context.getBean(Square.class);
    	System.out.println(s2);
    	
    	
    	Address address = context.getBean(Address.class);
    	System.out.println(address);
    	
    	
    	Employee employee = context.getBean(Employee.class);
    	System.out.println(employee);
    }
}
