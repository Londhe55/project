package com.training;

import java.util.List;


import com.training.model.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class App 
{
	
	
	static void insert() {
		Student e = new Student(104,"MS",65.78);
		
		// EntityManagerFactory is responsible for reading persistence.xml file 
		// and also create the connection to the database
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		// EntityManager is interface responsible to talk to the database.
		// and using instance of EntityManager we can perform Insert (persist), Update, Delete, Fetch
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(e);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	}
	
	
	// Read 
	static void read() {
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Student e = em.find(Student.class, 101);
		
		System.out.println(e);
		
		em.close();
	}
	
	// Upadte 
	static void update() {
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Student e = em.find(Student.class, 101);
		
		e.setMarks(90.00);
		
		em.getTransaction().begin();
		em.merge(e);
		em.getTransaction().commit();
		
		
		em.close();
		emf.close();
	}
	
	
	
	// Delete
	
	static void delete() {
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		Student e = em.find(Student.class, 102);
		
		em.getTransaction().begin();
		em.remove(e);
		em.getTransaction().commit();
		
		
		em.close();
		emf.close();
	}
	
	
	
	
	// Read  All
	static void readAll() {
		
		EntityManagerFactory emf;
		emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();
		
		String jpql ="select e from Student e";
		
		Query q = em.createQuery(jpql);    // createQuery() → converts the JPQL string into an executable query
		
		List<Student> studentList = q.getResultList();    // Give me ALL matching records
		
		System.out.println(studentList);
		
		Student e = em.find(Student.class, 101);
		
		System.out.println(e);
		
		em.close();
		
		
//		✅ getResultList()
//				✔ Returns multiple results
//				✔ Returns empty list if no data
//		
//			
//		✅ getSingleResult()
//				✔ Returns only ONE result
//				❌ Throws exception if:
//		
//				No data
//				More than one row


	}
	
	
	
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
//      insert();
    	
    	
//  	read();
//
//  	update();
//  	
//  	delete();
//  	
  	readAll();
        
    }
}
