package com.training.model;

public class ShapeFactory {
	
	
	
	// Purpose of Factorydesign is to Decouple the class from client 
	public static Shape createShape(int type) {
		
		if(type == 1) {
			return new Circle();
		}
		if(type ==2) {
			return new Square();
		}
		return null;
	}



}
