package com.training.ui;



import com.training.model.Shape;
import com.training.model.ShapeFactory;


public class Main1 {
	
	public static void main(String[] args) {
		
//		Shape shape;
//		shape = new Circle();
//		shape.setSize(10);
//		System.out.println(shape.getArea());
//		System.out.println(shape);
//		
//		
//		Shape shape1;
//		shape1 = new Square();
//		shape1.setSize(10);
//		System.out.println(shape1.getArea());
//		System.out.println(shape1);
		
		
		
		
		
//		Shape shape;
//		shape = null;
//		shape.setSize(10);
//		System.out.println(shape.getArea());
//		System.out.println(shape);
		
		
		Shape shape1;
		shape1 = ShapeFactory.createShape(1);
		shape1.setSize(10);
		System.out.println(shape1.getArea());
		System.out.println(shape1);
		
	}

}
