package com.training;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.MyConfiguration;
import com.training.controller.CustomerController;



public class App {
    public static void main(String[] args) {
        
    	
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfiguration.class);
    	
    	CustomerController controller = context.getBean(CustomerController.class);
    	System.out.println(controller);
    }
}
