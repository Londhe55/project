package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.repository.CustomerRepository;


@Service
public class CustomerService {
	
	
	@Autowired
	CustomerRepository repository;

	@Override
	public String toString() {
		return "CustomerService [repository=" + repository + "]";
	}
	
	
	
	

}
