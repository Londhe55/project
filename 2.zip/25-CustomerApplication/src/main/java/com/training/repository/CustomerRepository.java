package com.training.repository;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepository {

	@Override
	public String toString() {
		return "CustomerRepository []";
	}
	
	

}
