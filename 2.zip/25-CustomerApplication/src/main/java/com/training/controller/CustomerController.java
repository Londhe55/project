package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.training.service.CustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	CustomerService service;

	@Override
	public String toString() {
		return "CustomerController [service=" + service + "]";
	}
	
	

}
