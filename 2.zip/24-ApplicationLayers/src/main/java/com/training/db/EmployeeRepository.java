package com.training.db;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeRepository {

	@Override
	public String toString() {
		return "EmployeeRepository []";
	}


	
}
