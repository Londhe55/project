package com.training.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.training.service.EmployeeService;

@Controller
public class Employeecontroller {
	
	@Autowired
	EmployeeService service;

	@Override
	public String toString() {
		return "Employeecontroller [service=" + service + "]";
	}


	

}
