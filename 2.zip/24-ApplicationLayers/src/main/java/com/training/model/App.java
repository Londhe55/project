package com.training.model;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.MyConfiguration;
import com.training.ui.Employeecontroller;


public class App {
    public static void main(String[] args) {
        
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfiguration.class);
    	
    	
    	Employeecontroller ec = context.getBean(Employeecontroller.class);
    	System.out.println(ec);
    	
    	
    }
}
