package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.db.EmployeeRepository;

@Service
public class EmployeeService {

	
	@Autowired
	EmployeeRepository repository;

	@Override
	public String toString() {
		return "EmployeeService [repository=" + repository + "]";
	}

	

	
	



	

}
