package com.example.service;

import java.util.List;

import com.example.feign.AuditClient;
import com.example.feign.AuditRequest;
import java.time.LocalDateTime;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.CustomerRequest;
import com.example.dto.CustomerResponse;
import com.example.entity.Customer;
import com.example.exception.CustomerNotFoundException;
import com.example.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private AuditClient auditClient;
    @Autowired
    private CustomerRepository repository;

    // SAVE CUSTOMER USING DTO
    public CustomerResponse saveCustomer(CustomerRequest request) {

        Customer customer = new Customer();

        customer.setFirstName(request.getFirstName());
        customer.setLastName(request.getLastName());
        customer.setNickName(request.getNickName());
        customer.setSex(request.getSex());
        customer.setAge(request.getAge());
        customer.setQualification(request.getQualification());
        customer.setNotes(request.getNotes());
        customer.setPermanentAddress(request.getPermanentAddress());
        customer.setCommunicationAddress(request.getCommunicationAddress());

        Customer savedCustomer = repository.save(customer);
        
        AuditRequest audit = new AuditRequest();

        audit.setCustomerId(savedCustomer.getId());
        audit.setAction("CREATE");
        audit.setTimestamp(LocalDateTime.now());
        audit.setPerformedBy("admin");
        audit.setDetails("Customer Created");

        auditClient.saveAudit(audit);


        CustomerResponse response = new CustomerResponse();

        response.setId(savedCustomer.getId());
        response.setFirstName(savedCustomer.getFirstName());
        response.setLastName(savedCustomer.getLastName());
        response.setNickName(savedCustomer.getNickName());
        response.setSex(savedCustomer.getSex());
        response.setAge(savedCustomer.getAge());
        response.setQualification(savedCustomer.getQualification());
        response.setNotes(savedCustomer.getNotes());
        response.setPermanentAddress(savedCustomer.getPermanentAddress());
        response.setCommunicationAddress(savedCustomer.getCommunicationAddress());	

        return response;
    }

    public Customer getCustomerById(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new CustomerNotFoundException(
                                "Customer not found with id: " + id));
    }

    public List<Customer> getAllCustomers() {
        return repository.findAll();
    }

    public Customer updateCustomer(Long id, Customer customer) {

        Customer existingCustomer =
                repository.findById(id)
                        .orElseThrow(() ->
                                new CustomerNotFoundException(
                                        "Customer not found with id: " + id));

        existingCustomer.setFirstName(customer.getFirstName());
        existingCustomer.setLastName(customer.getLastName());
        existingCustomer.setNickName(customer.getNickName());
        existingCustomer.setSex(customer.getSex());
        existingCustomer.setAge(customer.getAge());
        existingCustomer.setQualification(customer.getQualification());
        existingCustomer.setNotes(customer.getNotes());

        Customer updatedCustomer = repository.save(existingCustomer);

        AuditRequest audit = new AuditRequest();

        audit.setCustomerId(updatedCustomer.getId());
        audit.setAction("UPDATE");
        audit.setTimestamp(LocalDateTime.now());
        audit.setPerformedBy("admin");
        audit.setDetails("Customer Updated");

        auditClient.saveAudit(audit);

        return updatedCustomer;
    }

    public String deleteCustomer(Long id) {

        repository.deleteById(id);

        AuditRequest audit = new AuditRequest();

        audit.setCustomerId(id);
        audit.setAction("DELETE");
        audit.setTimestamp(LocalDateTime.now());
        audit.setPerformedBy("admin");
        audit.setDetails("Customer Deleted");

        auditClient.saveAudit(audit);

        return "Customer Deleted Successfully";
    }
}