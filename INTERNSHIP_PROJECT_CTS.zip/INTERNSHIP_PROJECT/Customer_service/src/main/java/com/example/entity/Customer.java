package com.example.entity;

import jakarta.persistence.*;
import lombok.Data;
import jakarta.validation.constraints.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Size;

import jakarta.persistence.Embedded;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;

@Entity
@Table(name = "customers")



public class Customer {

	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @NotBlank(message = "First Name is required")
	    private String firstName;
	    
	    
	    @NotBlank(message = "Last Name is required")
	    private String lastName;
	    
	    private String nickName;
	    
	    
	    @NotBlank(message = "Sex is required")
	    private String sex;

	    @Min(value = 1, message = "Age must be greater than 0")
	    @Max(value = 120, message = "Age must be less than 120")
	    private Integer age;

	    public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getNickName() {
			return nickName;
		}

		public void setNickName(String nickName) {
			this.nickName = nickName;
		}

		public String getSex() {
			return sex;
		}

		public void setSex(String sex) {
			this.sex = sex;
		}

		public Integer getAge() {
			return age;
		}

		public void setAge(Integer age) {
			this.age = age;
		}

		public String getQualification() {
			return qualification;
		}

		public void setQualification(String qualification) {
			this.qualification = qualification;
		}

		public String getNotes() {
			return notes;
		}

		public void setNotes(String notes) {
			this.notes = notes;
		}
		@NotBlank(message = "Qualification is required")
		private String qualification;
		@Size(max = 250, message = "Notes cannot exceed 250 characters")
	    private String notes;
	    
		@Embedded
		@AttributeOverrides({
		    @AttributeOverride(name = "houseNo", column = @Column(name = "permanent_house_no")),
		    @AttributeOverride(name = "street", column = @Column(name = "permanent_street")),
		    @AttributeOverride(name = "landmark", column = @Column(name = "permanent_landmark")),
		    @AttributeOverride(name = "city", column = @Column(name = "permanent_city")),
		    @AttributeOverride(name = "state", column = @Column(name = "permanent_state")),
		    @AttributeOverride(name = "pin", column = @Column(name = "permanent_pin"))
		})
		private Address permanentAddress;

		@Embedded
		@AttributeOverrides({
		    @AttributeOverride(name = "houseNo", column = @Column(name = "communication_house_no")),
		    @AttributeOverride(name = "street", column = @Column(name = "communication_street")),
		    @AttributeOverride(name = "landmark", column = @Column(name = "communication_landmark")),
		    @AttributeOverride(name = "city", column = @Column(name = "communication_city")),
		    @AttributeOverride(name = "state", column = @Column(name = "communication_state")),
		    @AttributeOverride(name = "pin", column = @Column(name = "communication_pin"))
		})
		private Address communicationAddress;

		public Address getPermanentAddress() {
			return permanentAddress;
		}

		public void setPermanentAddress(Address permanentAddress) {
			this.permanentAddress = permanentAddress;
		}

		public Address getCommunicationAddress() {
			return communicationAddress;
		}

		public void setCommunicationAddress(Address communicationAddress) {
			this.communicationAddress = communicationAddress;
		}
		
		
		
		

}



