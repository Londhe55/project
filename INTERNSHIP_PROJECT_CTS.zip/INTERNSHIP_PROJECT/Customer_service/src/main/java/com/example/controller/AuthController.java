package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.security.AuthRequest;
import com.example.security.AuthResponse;
import com.example.security.JwtService;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private JwtService jwtService;

    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest request) {

    	if ("admin".equals(request.getUsername())
    	        && "admin123".equals(request.getPassword())) {

    	    String token =
    	        jwtService.generateToken(
    	            request.getUsername(),
    	            "ADMIN");

    	    return new AuthResponse(token);
    	}
    	if ("user".equals(request.getUsername())
    	        && "user123".equals(request.getPassword())) {

    	    String token =
    	        jwtService.generateToken(
    	            request.getUsername(),
    	            "USER");

    	    return new AuthResponse(token);
    	}

        throw new RuntimeException("Invalid Username or Password");
    }
}