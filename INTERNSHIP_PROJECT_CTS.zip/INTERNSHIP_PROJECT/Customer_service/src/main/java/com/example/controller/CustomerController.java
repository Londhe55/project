package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.dto.CustomerRequest;
import com.example.dto.CustomerResponse;
import com.example.entity.Customer;
import com.example.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/cms")
public class CustomerController {

    @Autowired
    private CustomerService service;

    @PostMapping("/save")
    public CustomerResponse saveCustomer(
            @Valid @RequestBody CustomerRequest request) {

        return service.saveCustomer(request);
    }

    @GetMapping("/fetchall")
    public List<Customer> getAll() {
        return service.getAllCustomers();
    }

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        return service.getCustomerById(id);
    }

    @PutMapping("/save/{id}")
    public Customer updateCustomer(@PathVariable Long id,
                                   @RequestBody Customer customer) {

        return service.updateCustomer(id, customer);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteCustomer(@PathVariable Long id) {

        return service.deleteCustomer(id);
    }
}