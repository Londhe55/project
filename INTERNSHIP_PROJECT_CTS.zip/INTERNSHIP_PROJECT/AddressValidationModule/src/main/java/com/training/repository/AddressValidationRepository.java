package com.training.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.training.model.AddressValidationModel;

@Repository
public interface AddressValidationRepository
        extends JpaRepository<AddressValidationModel, Long> {

}
