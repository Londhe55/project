
package com.training.dto;

import com.training.model.AddressValidationModel;

public class AddressValidationResponseDTO {

    private AddressValidationModel addressValidation;

    private int httpStatusCode;

    private String message;

    public AddressValidationModel getAddressValidation() {
        return addressValidation;
    }

    public void setAddressValidation(
            AddressValidationModel addressValidation) {
        this.addressValidation = addressValidation;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
