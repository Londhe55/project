package com.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {

        return new OpenAPI()
                .info(
                        new Info()
                                .title("Address Validation Service API")
                                .version("1.0")
                                .description(
                                        "API Documentation for Address Validation Microservice")
                                .contact(
                                        new Contact()
                                                .name("Babu Anand")
                                                .email("babu@example.com")));
    }
}