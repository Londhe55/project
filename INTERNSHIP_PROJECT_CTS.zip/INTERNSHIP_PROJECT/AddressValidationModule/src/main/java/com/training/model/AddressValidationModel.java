package com.training.model;

import java.time.LocalDateTime;
import java.util.Objects;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;


@Entity
@Table(name = "address_validation")
public class AddressValidationModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @NotBlank(message = "Address Type is required")
    @Pattern(
            regexp = "(?i)^(PERMANENT|COMMUNICATION)$",
            message = "Address Type must be PERMANENT or COMMUNICATION")
    @Column(nullable = false)
    private String addressType;

    @NotBlank(message = "City is required")
    @Column(nullable = false)
    private String city;

    @NotBlank(message = "State is required")
    @Column(nullable = false)
    private String state;

    @NotBlank(message = "PIN is required")
    @Pattern(
            regexp = "^[1-9][0-9]{5}$",
            message = "PIN must be a valid 6 digit number")
    @Column(nullable = false)
    private String pin;

    @Column(nullable = false)
    private Boolean isValid;

    @Column(nullable = false)
    private LocalDateTime validationTimestamp;

	public AddressValidationModel(Long id,
			@NotBlank(message = "Address Type is required") @Pattern(regexp = "(?i)^(PERMANENT|COMMUNICATION)$", message = "Address Type must be PERMANENT or COMMUNICATION") String addressType,
			@NotBlank(message = "City is required") String city, @NotBlank(message = "State is required") String state,
			@NotBlank(message = "PIN is required") @Pattern(regexp = "^[1-9][0-9]{5}$", message = "PIN must be a valid 6 digit number") String pin,
			Boolean isValid, LocalDateTime validationTimestamp) {
		super();
		this.id = id;
		this.addressType = addressType;
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.isValid = isValid;
		this.validationTimestamp = validationTimestamp;
	}

	public AddressValidationModel(
			@NotBlank(message = "Address Type is required") @Pattern(regexp = "(?i)^(PERMANENT|COMMUNICATION)$", message = "Address Type must be PERMANENT or COMMUNICATION") String addressType,
			@NotBlank(message = "City is required") String city, @NotBlank(message = "State is required") String state,
			@NotBlank(message = "PIN is required") @Pattern(regexp = "^[1-9][0-9]{5}$", message = "PIN must be a valid 6 digit number") String pin,
			Boolean isValid, LocalDateTime validationTimestamp) {
		super();
		this.addressType = addressType;
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.isValid = isValid;
		this.validationTimestamp = validationTimestamp;
	}

	public AddressValidationModel() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public Boolean getIsValid() {
		return isValid;
	}

	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}

	public LocalDateTime getValidationTimestamp() {
		return validationTimestamp;
	}

	public void setValidationTimestamp(LocalDateTime validationTimestamp) {
		this.validationTimestamp = validationTimestamp;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AddressValidationModel other = (AddressValidationModel) obj;
		return Objects.equals(id, other.id);
	}

	@Override
	public String toString() {
		return "AddressValidationModel [id=" + id + ", addressType=" + addressType + ", city=" + city + ", state="
				+ state + ", pin=" + pin + ", isValid=" + isValid + ", validationTimestamp=" + validationTimestamp
				+ "]";
	}
	
}
