package com.training.service;

import com.training.dto.AddressValidationListResponseDTO;
import com.training.dto.AddressValidationRequestDTO;
import com.training.dto.AddressValidationResponseDTO;

public interface AddressValidationService {

    AddressValidationResponseDTO saveAddressValidation(
            AddressValidationRequestDTO requestDTO);

    AddressValidationResponseDTO getAddressValidationById(Long id);

    AddressValidationListResponseDTO getAllAddressValidations();

    AddressValidationResponseDTO updateAddressValidation(
            Long id,
            AddressValidationRequestDTO requestDTO);

    void deleteAddressValidation(Long id);
}