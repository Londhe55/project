package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.training.dto.AddressValidationListResponseDTO;
import com.training.dto.AddressValidationRequestDTO;
import com.training.dto.AddressValidationResponseDTO;
import com.training.service.AddressValidationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/address")
@Tag(name = "Address Validation",description = "Address Validation APIs")
public class AddressValidationController {

    @Autowired
    private AddressValidationService service;

    @Operation(summary = "Save Address Validation Record",
    		   description = "Creates a new Address Validation record")
    @PostMapping("/save")
    public AddressValidationResponseDTO saveAddressValidation(
            @Valid @RequestBody
            AddressValidationRequestDTO requestDTO) {

        return service.saveAddressValidation(requestDTO);
    }

    @Operation(summary = "Get Record By ID",
               description = "Fetch Address Validation record by ID")
    @GetMapping("/{id}")
    public AddressValidationResponseDTO
    getAddressValidationById(
            @PathVariable Long id) {

        return service.getAddressValidationById(id);
    }

    @Operation(summary = "Get All Records",
               description = "Fetch all Address Validation records")
    @GetMapping
    public AddressValidationListResponseDTO
    getAllAddressValidations() {

        return service.getAllAddressValidations();
    }

    @Operation(summary = "Update Record",
               description = "Update Address Validation record")
    @PutMapping("/update/{id}")
    public AddressValidationResponseDTO
    updateAddressValidation(
            @PathVariable Long id,
            @Valid @RequestBody
            AddressValidationRequestDTO requestDTO) {

        return service.updateAddressValidation(
                id,
                requestDTO);
    }

    @Operation(summary = "Delete Record",
               description = "Delete Address Validation record by ID")
    @DeleteMapping("/delete/{id}")
    public String deleteAddressValidation(
            @PathVariable Long id) {

        service.deleteAddressValidation(id);

        return "Record Deleted Successfully";
    }

}