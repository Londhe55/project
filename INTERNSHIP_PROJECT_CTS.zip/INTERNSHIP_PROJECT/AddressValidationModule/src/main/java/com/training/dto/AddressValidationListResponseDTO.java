package com.training.dto;

import java.util.List;

import com.training.model.AddressValidationModel;

public class AddressValidationListResponseDTO {

    private List<AddressValidationModel> addresses;

    private int httpStatusCode;

    private String message;

    public List<AddressValidationModel> getAddresses() {
        return addresses;
    }

    public void setAddresses(
            List<AddressValidationModel> addresses) {
        this.addresses = addresses;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
