
package com.training.dto;

import com.training.model.AddressValidationModel;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public class AddressValidationRequestDTO {

    @Valid
    @NotNull(message = "Address details are required")
    private AddressValidationModel addressValidation;

    public AddressValidationModel getAddressValidation() {
        return addressValidation;
    }

    public void setAddressValidation(
            AddressValidationModel addressValidation) {
        this.addressValidation = addressValidation;
    }
}
