package com.training.exception;

public class InvalidAddressTypeException extends RuntimeException {

	public InvalidAddressTypeException(String message) {
			
		super(message);
	
	}
}
