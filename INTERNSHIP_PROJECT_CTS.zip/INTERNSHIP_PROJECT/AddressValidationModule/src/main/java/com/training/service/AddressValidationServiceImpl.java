package com.training.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dto.AddressValidationListResponseDTO;
import com.training.dto.AddressValidationRequestDTO;
import com.training.dto.AddressValidationResponseDTO;
import com.training.exception.InvalidAddressTypeException;
import com.training.exception.InvalidPinException;
import com.training.exception.ResourceNotFoundException;
import com.training.model.AddressValidationModel;
import com.training.repository.AddressValidationRepository;

@Service
public class AddressValidationServiceImpl
        implements AddressValidationService {

    @Autowired
    private AddressValidationRepository repository;

    @Override
    public AddressValidationResponseDTO saveAddressValidation(
            AddressValidationRequestDTO requestDTO) {

        AddressValidationModel model =
                requestDTO.getAddressValidation();
        
        validateAddress(model);

        model.setIsValid(true);
        model.setValidationTimestamp(
                LocalDateTime.now());

        AddressValidationModel savedModel =
                repository.save(model);

        AddressValidationResponseDTO response =
                new AddressValidationResponseDTO();

        response.setAddressValidation(savedModel);
        response.setHttpStatusCode(201);
        response.setMessage(
                "Address Validation Saved Successfully");

        return response;
    }

    @Override
    public AddressValidationResponseDTO
    getAddressValidationById(Long id) {

        AddressValidationModel model =
                repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Record not found with id : " + id));

        AddressValidationResponseDTO response =
                new AddressValidationResponseDTO();

        response.setAddressValidation(model);
        response.setHttpStatusCode(200);
        response.setMessage(
                "Record Fetched Successfully");

        return response;
    }

    @Override
    public AddressValidationListResponseDTO
    getAllAddressValidations() {

        List<AddressValidationModel> addressList =
                repository.findAll();

        AddressValidationListResponseDTO response =
                new AddressValidationListResponseDTO();

        response.setAddresses(addressList);
        response.setHttpStatusCode(200);
        response.setMessage(
                "Records Fetched Successfully");

        return response;
    }

    @Override
    public AddressValidationResponseDTO
    updateAddressValidation(
            Long id,
            AddressValidationRequestDTO requestDTO) {

        AddressValidationModel existingModel =
                repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Record not found with id : " + id));

        AddressValidationModel requestModel =
                requestDTO.getAddressValidation();
        
        validateAddress(requestModel);

        existingModel.setAddressType(
                requestModel.getAddressType());

        existingModel.setCity(
                requestModel.getCity());

        existingModel.setState(
                requestModel.getState());

        existingModel.setPin(
                requestModel.getPin());

        existingModel.setIsValid(
                requestModel.getIsValid());

        existingModel.setValidationTimestamp(
                LocalDateTime.now());

        AddressValidationModel updatedModel =
                repository.save(existingModel);

        AddressValidationResponseDTO response =
                new AddressValidationResponseDTO();

        response.setAddressValidation(updatedModel);
        response.setHttpStatusCode(200);
        response.setMessage(
                "Record Updated Successfully");

        return response;
    }

    @Override
    public void deleteAddressValidation(Long id) {

        AddressValidationModel model =
                repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Record not found with id : " + id));

        repository.delete(model);
    }
    
    private void validateAddress(AddressValidationModel model) {

        if (!model.getAddressType()
                .equalsIgnoreCase("PERMANENT")
                &&
                !model.getAddressType()
                .equalsIgnoreCase("COMMUNICATION")) {

            throw new InvalidAddressTypeException(
                    "Address Type must be PERMANENT or COMMUNICATION");
        }

        if (!model.getPin()
                .matches("^[1-9][0-9]{5}$")) {

            throw new InvalidPinException(
                    "PIN must be a valid 6 digit number");
        }
    }
}