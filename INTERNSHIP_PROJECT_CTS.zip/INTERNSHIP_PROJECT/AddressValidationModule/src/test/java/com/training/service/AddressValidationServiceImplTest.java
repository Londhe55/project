package com.training.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.dto.AddressValidationRequestDTO;
import com.training.dto.AddressValidationResponseDTO;
import com.training.model.AddressValidationModel;
import com.training.repository.AddressValidationRepository;
import com.training.service.AddressValidationServiceImpl;

@ExtendWith(MockitoExtension.class)
class AddressValidationServiceImplTest {

    @Mock
    private AddressValidationRepository repository;

    @InjectMocks
    private AddressValidationServiceImpl service;

    @Test
    void testSaveAddressValidation() {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setAddressType("PERMANENT");
        model.setCity("Chennai");
        model.setState("Tamil Nadu");
        model.setPin("600001");

        AddressValidationRequestDTO request =
                new AddressValidationRequestDTO();

        request.setAddressValidation(model);

        AddressValidationModel savedModel =
                new AddressValidationModel();

        savedModel.setId(1L);
        savedModel.setAddressType("PERMANENT");
        savedModel.setCity("Chennai");
        savedModel.setState("Tamil Nadu");
        savedModel.setPin("600001");
        savedModel.setIsValid(true);
        savedModel.setValidationTimestamp(LocalDateTime.now());

        when(repository.save(any(AddressValidationModel.class)))
                .thenReturn(savedModel);

        AddressValidationResponseDTO response =
                service.saveAddressValidation(request);

        assertNotNull(response);
        assertEquals(201,
                response.getHttpStatusCode());

        assertEquals("Chennai",
                response.getAddressValidation()
                        .getCity());
    }
}