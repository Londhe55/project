package com.training.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.dto.AddressValidationRequestDTO;
import com.training.dto.AddressValidationResponseDTO;
import com.training.model.AddressValidationModel;
import com.training.service.AddressValidationService;

@WebMvcTest(AddressValidationController.class)
class AddressValidationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AddressValidationService service;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testSaveAddressValidation()
            throws Exception {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setAddressType("PERMANENT");
        model.setCity("Chennai");
        model.setState("Tamil Nadu");
        model.setPin("600001");

        AddressValidationRequestDTO request =
                new AddressValidationRequestDTO();

        request.setAddressValidation(model);

        AddressValidationResponseDTO response =
                new AddressValidationResponseDTO();

        response.setAddressValidation(model);
        response.setHttpStatusCode(201);
        response.setMessage("Saved Successfully");

        when(service.saveAddressValidation(any()))
                .thenReturn(response);

        mockMvc.perform(
                        post("/address/save")
                                .contentType(
                                        MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper
                                                .writeValueAsString(
                                                        request)))
                .andExpect(status().isOk());
    }
}