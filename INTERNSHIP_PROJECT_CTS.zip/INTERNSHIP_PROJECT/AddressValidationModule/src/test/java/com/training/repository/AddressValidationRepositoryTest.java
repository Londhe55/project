package com.training.repository;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.training.model.AddressValidationModel;

@DataJpaTest
@AutoConfigureTestDatabase(
        replace = AutoConfigureTestDatabase.Replace.ANY)
class AddressValidationRepositoryTest {

    @Autowired
    private AddressValidationRepository repository;

    @Test
    void testSaveAddressValidation() {

        AddressValidationModel model =
                new AddressValidationModel();

        model.setAddressType("PERMANENT");
        model.setCity("Chennai");
        model.setState("Tamil Nadu");
        model.setPin("600001");
        model.setIsValid(true);
        model.setValidationTimestamp(
                LocalDateTime.now());

        AddressValidationModel saved =
                repository.save(model);

        assertNotNull(saved.getId());
    }
}