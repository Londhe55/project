
package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.entity.AuditLog;
import com.example.service.AuditService;

@RestController
@RequestMapping("/audit")
public class AuditController {

    @Autowired
    private AuditService service;

    @PostMapping("/save")
    public AuditLog save(@RequestBody AuditLog auditLog) {
        return service.save(auditLog);
    }

    @GetMapping("/fetchall")
    public List<AuditLog> getAllLogs() {
        return service.getAllLogs();
    }
}