package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.AuditLog;

public interface AuditRepository extends JpaRepository<AuditLog, Long> {

}
