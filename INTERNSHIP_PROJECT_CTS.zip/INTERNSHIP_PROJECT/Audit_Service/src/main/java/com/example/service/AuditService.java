//
//package com.example.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.entity.AuditLog;
//import com.example.repository.AuditRepository;
//
//@Service
//public class AuditService {
//
//    @Autowired
//    private AuditRepository repository;
//
//    public AuditLog save(AuditLog auditLog) {
//        return repository.save(auditLog);
//    }
//
//    public List<AuditLog> getAllLogs() {
//        return repository.findAll();
//    }
//}


package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.AuditLog;
import com.example.repository.AuditRepository;

@Service
public class AuditService {

    @Autowired
    private AuditRepository repository;

    public AuditLog save(AuditLog auditLog) {
        return repository.save(auditLog);
    }

    public List<AuditLog> getAllLogs() {
        return repository.findAll();
    }
}