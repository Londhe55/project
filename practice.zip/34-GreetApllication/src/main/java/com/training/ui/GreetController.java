package com.training.ui;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/greetapi")
public class GreetController {
	
	
	@GetMapping("/greet/{name}")
	public String f1(@PathVariable String name) {
		
		return name.toUpperCase() + " How are You";
		
	}

}
