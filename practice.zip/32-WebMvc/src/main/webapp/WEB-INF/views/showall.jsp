<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false"%>

	<%@ taglib = uri = "http://java.sun.com/jsp/jstl/core" prefix = "c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	
	<table>
			
		<c:forEach items= "${requestScope.empList}" var = "e">
			<tr>
				<td> ${e.id}<td>
				<td> ${e.name}<td>
				<td> ${e.basic}<td>
				<td> ${e.grade}<td>
			</tr>
	</table>
</body>
</html>