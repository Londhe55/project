<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Employee Input</title>
</head>
<body>
    <h1>This is Employee Input page</h1>

    
    <form:form modelAttribute="empForm" action="saveEmployee" method="post">
        
        <div> 
            <label>ID</label> 
            <form:input path="id" /> 
        </div>
        
        <div> 
            <label>Name</label>
            <form:input path="name" />
        </div>
            
        <div> 
            <label>Basic</label>
            <form:input path="basic" />
        </div>
                
        <div> 
            <label>Grade</label>
           
            <form:radiobutton path="grade" value="A" label="A" />
            <form:radiobutton path="grade" value="B" label="B" />
            <form:radiobutton path="grade" value="C" label="C" />
        </div>
        
        <div>
            <input type="submit" value="Submit">
        </div>
                
    </form:form>
    
</body>
</html>