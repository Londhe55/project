<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
		<table border = "1">
			<tr>
				<td>ID</td>
				<td>${requestScope.emp.id}</td>
					
			</tr>
			
			
			<tr>
				<td>Name</td>
				<td>${requestScope.emp.name}</td>
								
			</tr>
						
			<tr>
				<td>Basic</td>
				<td>${requestScope.emp.basic}</td>
											
			</tr>
									
			<tr>
				<td>Grade</td>
				<td>${requestScope.emp.grade}</td>
														
			</tr>
												
			<tr>
				<td>Tax</td>
				<td>${requestScope.emp.tax}</td>
																	
			</tr>
			
			
			<tr>
				<td>Salary</td>
				<td>${requestScope.emp.netSalary}</td>
																	
			</tr>
		</table>
</body>
</html>