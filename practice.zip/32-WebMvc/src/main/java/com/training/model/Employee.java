package com.training.model;



public class Employee {
	
	int id;
	
	String name;
	
	double basic;
	
	char grade;

	public Employee(int id, String name, double basic, char grade) {
		super();
		this.id = id;
		this.name = name;
		this.basic = basic;
		this.grade = grade;
	}

	public Employee() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBasic() {
		return basic;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

	public char getGrade() {
		return grade;
	}

	public void setGrade(char grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", basic=" + basic + ", grade=" + grade + "]";
	}
	
	
	
	
	public double getAllowence() {
		
		double allowence = 0.0;
		
		switch (grade) {
		case 'A':
			allowence = this.basic*0.4;
			break;
		case 'B':
			allowence = this.basic*0.35;
			break;
		case 'C':
			allowence = this.basic*0.2;
			break;
		
		}
		return allowence;
		
	}
	
	public double getTax() {
		return this.basic*0.10;
	}
	
	public double getNetSalary() {
		return this.basic + this.getAllowence() - this.getTax();
	}
	
	

}
