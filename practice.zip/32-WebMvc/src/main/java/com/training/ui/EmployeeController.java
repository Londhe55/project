package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.training.model.Employee;

@Controller
public class EmployeeController {
	
	
	@GetMapping("/showemp")
	public String f1(Model model1) {
		
		System.out.println("Controler Called");
		
		Employee employee = new Employee(8001, "Krish", 35000, 'A');
		model1.addAttribute("emp", employee);
		
		return "EmployeeOutput";
		
	}
	
	
	@GetMapping("/input")
	public String f2(Model model) {
		
		model .addAttribute("empForm",new Employee());
		return "EmployeeInput";
	}
	
	
	@PostMapping("/saveEmployee")
	public String f3(@ModelAttribute(name = "empForm") Employee employee, Model model) {
		
		System.out.println("Contrller called");
		model.addAttribute("emp", employee);
		
		return "empoutput";
		
	}
	
	
	@GetMapping("/showall")
	public ModelAndView	f4() {
		
		Employee e1  = new Employee(101, "harini", 6000, 'A');
		Employee e2  = new Employee(102, "Sudhakar", 4000, 'B');
		Employee e3  = new Employee(103, "Hema", 8000, 'A');
		Employee e4  = new Employee(104, "Swathy", 9000, 'B');
		Employee e5  = new Employee(105, "Bala", 5000, 'A');
	
		
		List<Employee> empList = new LinkedList<>();
		

		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		
		ModelAndView andView = new ModelAndView("showAll");
		andView.addObject("empList", empList);
		
		return andView;
	}

}
