package com.training.ui;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServlet;


@Controller
public class HelloController{
	
	
	@RequestMapping("/hello")
	public String f1(Model model) {
		
		model.addAttribute("msg", "welcome to the spring MVC");
		
		return "hello";
	}

}
