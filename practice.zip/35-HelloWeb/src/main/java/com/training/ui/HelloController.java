package com.training.ui;

import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/helloapi")
public class HelloController {
	
	
	@Autowired
	RestTemplate restTemplate;
	
	
	@GetMapping("/hello/{name}")
	public String f1(@PathVariable String name) {
		String url = "http://localhost:9090/greetapi/greet/"+name;
		
		@Nullable
		String result = restTemplate.getForObject(url, String.class);
		return "Hello "+result;
	}
	
	@GetMapping("/hello")
	public String f2(@RequestParam String name) {
		String url = "http://localhost:9090/greetapi/greet/"+name;
		
		@Nullable
		String result = restTemplate.getForObject(url, String.class);
		return "Hello "+result;
	}

}
