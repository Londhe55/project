package com.training.service;

public interface HelloService {

}
