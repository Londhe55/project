package com.training.ui;

public class HelloController {

}
