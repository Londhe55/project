package com.springdtajpademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
