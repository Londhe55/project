package com.springdtajpademo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdtajpademo.entity.Student;
import com.springdtajpademo.repository.StudentRepository;

import jakarta.transaction.Transactional;

@Service
public class StudentService {

	@Autowired
	private StudentRepository repository;

	
	// Insert
	
	
	// 👉 Because Spring Data JPA automatically applies transaction management to repository methods
	// SimpleJpaRepository (internal class) add transaction automatically
	public void saveStudent(Student student) {
		repository.save(student);
	}

	
	
	
	// Read
	
	
	
	
	// Data may or may NOT exist in database still work 
	// it is ==> Null safety, Explicit handling,
	// To handle null safely and force developers to explicitly handle absence of data.
//	public Optional<Student> findStudent(int id) {
//
//		Optional<Student> s = repository.findById(id);
//		Optional<Student> s1 = repository.findById(id);
//
//		System.out.println(s1 == s);     // false because optinal(id) will call for two times differently
//
//		if (s.isPresent()) {
//			return s;
//		}
//
//		return s;
//	}

	
	
	
	
	// Dirty Chyecking
	// when you want dirty checking should be executed then we must use @Transactional
	//without transaction the setName  will not be  stored in the database
//	@Transactional
	public Optional<Student> findStudent(int id) {

		Optional<Student> s = repository.findById(id);
		Optional<Student> s1 = repository.findById(id);
		System.out.println(s == s1);
		System.out.println(s.get());

		if (s.isPresent()) {
			Student student = s.get();
			student.setFirstName("Dharmavir");
			student.setFirstName("Updated By Dirty Checking 😳");
			
			return s;
		}
		else {

		    System.out.println("Student not found");

		}

		Student s3 = repository.findById(id).orElse(null);
		Student s2 = repository.findById(id).orElse(null);

		System.out.println(s3 == s2);            // here it is true because only one time findById(id) called and second time it will be referenced from the persistance context  so same object

		return s;
	}

	
	// Find method using Entity Storing object
//		Safe only if:
//		ID is guaranteed present 
	
	public Student findStudentUsingEntity(int id) {
		
		Student s = repository.findById(id).orElseThrow();
		return s;
		
//		return repository.findById(id).orElse(null);   // you can write above two lines in single line also
	}
	
	
	
	
	
	
	// Upadate
	
	
	
	//	Recommended
	
	@Transactional
	public void updateStudentName(int rollNumber) {

		Student student = repository.findById(rollNumber).orElse(null);

		if (student != null) {
			student.setFirstName("New Updated Name"); // ✅ Dirty Checking
		} else {
			System.out.println("Student not found");
		}
    
   
    
		//    traditional way:

//public void updateStudentUsingSave(int id, String newName) {
//
//    Student student = repository.findById(id).orElse(null);
//
//    if (student != null) {
//        student.setName(newName);
//        repository.save(student);  // ✅ explicit save
//    }

		
		
		

    
}




	// Delete



//public void deleteStudent(int rollNumber) {
//	repository.deleteById(rollNumber);
//}


	
//Safe Way (Check First ✅ Recommended)
public void deleteStudent(int rollNumber) {

    if (repository.existsById(rollNumber)) {
        repository.deleteById(rollNumber);
        System.out.println("Student deleted successfully");
    } else {
        System.out.println("Student not found");
    }
}






//
//Using Entity (Advanced way 🔥)
//	public void deleteStudent(int rollNumber) {
//	
//	    Student student = repository.findById(rollNumber).orElse(null);
//	
//	    if (student != null) {
//	        repository.delete(student);  // delete using entity
//	    }
//	}



	

}
