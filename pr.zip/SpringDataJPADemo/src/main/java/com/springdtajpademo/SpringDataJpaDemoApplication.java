package com.springdtajpademo;



import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.springdtajpademo.controller.StudentController;
import com.springdtajpademo.entity.Student;

@SpringBootApplication
public class SpringDataJpaDemoApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringDataJpaDemoApplication.class, args);
		
		
		
		Scanner scanner = new Scanner(System.in);
		
//		System.out.println("Spring data JPA");
//		
//		System.out.println("Enter the Student id : ");
//		int id = Integer.valueOf(scanner.nextLine());
//		
//		System.out.println("Enter the Student Roll Number :");
//		int rollNumber = Integer.valueOf(scanner.nextLine());
//		
//		System.out.println("Enter the Student First Name : ");
//		String firstName = scanner.nextLine();
//		
//		System.out.println("Enter the student Last Name : ");
//		String lastName = scanner.nextLine();
//		
//		System.out.println("Eneter you age : ");
//		int age = Integer.valueOf(scanner.nextLine());
		
		
		
		
		
		StudentController controller = context.getBean(StudentController.class);
		
		
		
		
//		Student student = new Student(id, rollNumber, firstName, lastName, age);
//		System.out.println(student);
		
		
		//Insert
		
//		controller.saveStudent(student);       // to  used for inserting
//		
		
		
		
		// Read
		
		
		
//		System.out.println("Enter the Student id : ");
//		int id = Integer.valueOf(scanner.nextLine());
		
//		System.out.println(controller.findStudentUsingOptional(id));
		
//		System.out.println(controller.findStudentUsingEntity(id));
	

		
		
		
		//Update
		
		System.out.println("Enter the Student id : ");
		int id = Integer.valueOf(scanner.nextLine());
		
//		// ✅ Update student
		controller.updateStudent(id);
		
		
		// ✅ Fetch again to verify
		System.out.println(controller.findStudentUsingOptional(id));
//
//
		
		
		
		// Delete

//		// ✅ Delete student
//		controller.deleteStudent(1);

//		// ✅ Try fetching after delete
//		System.out.println(controller.findStudent(1));

		
		
	}

	
	
	

}
