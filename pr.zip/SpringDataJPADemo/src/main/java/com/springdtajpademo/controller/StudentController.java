package com.springdtajpademo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.springdtajpademo.entity.Student;
import com.springdtajpademo.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	private StudentService service;

	// Insert
	
	public void saveStudent(Student student) {
		service.saveStudent(student);

	}
	
	
	
	
	
	
	// Read
	
	public Optional<Student> findStudentUsingOptional(int id) {
		return service.findStudent(id);
	}

	
	public Student findStudentUsingEntity(int id) {
		return service.findStudentUsingEntity(id);
	}
	
	
	
	
	// Update
	
	public void updateStudent(int rollNumber) {
		 updateStudentName(rollNumber);
	}
	
	
	
	// delete
	

	private void updateStudentName(int rollNumber) {
		// TODO Auto-generated method stub
		
	}






	public void deleteStudent(int rollNumber) {
		service.deleteStudent(rollNumber);
	}






	






	

}
