package com.springdtajpademo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springdtajpademo.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{


}
