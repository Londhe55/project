package com.jwtimpl.service;


import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import com.jwtimpl.entity.User;
import com.jwtimpl.repository.UserRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository repo;

    // ✅ Constructor Injection
    public CustomUserDetailsService(UserRepository repo) {
        this.repo = repo;
    }

    // ✅ This method is called by Spring Security during login
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = repo.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        return org.springframework.security.core.userdetails.User
                .builder()
                .username(user.getUsername())
                .password(user.getPassword())  // ✅ already encoded password
                .roles(user.getRole())         // ✅ USER / ADMIN
                .build();
    }
}