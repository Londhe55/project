package com.jwtimpl.controller;


import com.jwtimpl.dto.LoginRequestDTO;
import com.jwtimpl.dto.SignUpRequestDTO;
import com.jwtimpl.entity.User;
import com.jwtimpl.repository.UserRepository;
import com.jwtimpl.security.JwtUtil;

import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    public AuthController(UserRepository userRepository,
                          PasswordEncoder passwordEncoder,
                          AuthenticationManager authenticationManager,
                          JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
    }

    // ✅ SIGNUP API
    @PostMapping("/signup")
    public String signup(@RequestBody SignUpRequestDTO request) {

        // ✅ Check if user already exists
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        // ✅ Create new user
        User user = new User();
        user.setUsername(request.getUsername());

        // ✅ Encode password
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        user.setRole("USER");

        // ✅ Save to DB
        userRepository.save(user);

        return "User registered successfully!";
    }

    // ✅ LOGIN API
    @PostMapping("/login")
    public String login(@RequestBody LoginRequestDTO request) {

        // ✅ Authenticate user using Spring Security
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );

        // ✅ If authentication fails → exception automatically thrown

        // ✅ Generate JWT token
        String token = jwtUtil.generateToken(request.getUsername());

        return token;
    }
}