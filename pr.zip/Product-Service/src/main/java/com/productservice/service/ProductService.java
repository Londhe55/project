package com.productservice.service;

import java.util.List;

import com.productservice.dto.ProductRequestDTO;
import com.productservice.dto.ProductResponseDTO;

public interface ProductService {

    ProductResponseDTO addProduct(ProductRequestDTO requestDTO);

    List<ProductResponseDTO> getAllProducts();

    ProductResponseDTO getProductById(Long id);
}
