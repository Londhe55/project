package com.productservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.security.access.prepost.PreAuthorize;

import com.productservice.dto.ProductRequestDTO;
import com.productservice.dto.ProductResponseDTO;
import com.productservice.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    // ✅ Add Product → ADMIN only
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ProductResponseDTO addProduct(@RequestBody ProductRequestDTO requestDTO) {
        return productService.addProduct(requestDTO);
    }

    // ✅ Get All Products → Public / USER / ADMIN
    @GetMapping
    public List<ProductResponseDTO> getAllProducts() {
        return productService.getAllProducts();
    }

    // ✅ Get Product By ID → Public / USER / ADMIN
    @GetMapping("/{id}")
    public ProductResponseDTO getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }
}
