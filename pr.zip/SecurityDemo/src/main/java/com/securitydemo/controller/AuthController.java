package com.securitydemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.securitydemo.config.AuthService;
import com.securitydemo.dto.SignResponseDto;
import com.securitydemo.dto.UserRequestDto;
import com.securitydemo.dto.UserResponseDto;

@RestController
@RequestMapping("/auth")
public class AuthController {
	
	@Autowired
	AuthService service;
	
	
	@PostMapping("/login")
	public ResponseEntity<UserResponseDto> login(@RequestBody UserRequestDto requestDto){
		return ResponseEntity.ok(service.login(requestDto));
		
	}
	
	@PostMapping("/login")
	public ResponseEntity<SignResponseDto> signup(@RequestBody UserRequestDto signRequestDto){
		return ResponseEntity.ok(service.signup(signRequestDto));
		
	}
	
	

}
