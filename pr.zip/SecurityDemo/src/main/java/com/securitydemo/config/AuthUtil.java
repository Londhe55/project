package com.securitydemo.config;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.securitydemo.entitty.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;


// this class is responsible for creating the token

@Component
public class AuthUtil {
	
	@Value("${jwt.secretKey}")
	private String jwtSecretKey;
	
	
	private SecretKey getSecretKey() {
		
		return Keys.hmacShaKeyFor(jwtSecretKey.getBytes(StandardCharsets.UTF_8));
		
	}
	
	
	public String generateToken(User user) {
		
		return Jwts.builder()
				.subject(user.getUsername())
				.claim("user ID is ",user.getId())
				.issuedAt(new Date())
				.expiration(new Date(System.currentTimeMillis() + 1000*60*60))
				.signWith(getSecretKey())
				.compact();
				
		
	}
	
	
	

}
