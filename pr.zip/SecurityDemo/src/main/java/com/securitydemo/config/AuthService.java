package com.securitydemo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import com.securitydemo.controller.AuthController;
import com.securitydemo.dto.SignResponseDto;
import com.securitydemo.dto.UserRequestDto;
import com.securitydemo.dto.UserResponseDto;
import com.securitydemo.entitty.User;
import com.securitydemo.repo.UserRepository;

@Service
public class AuthService {

    private final AuthController authController;

	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	AuthUtil authUtil;
	
	@Autowired
	UserRepository repository;

    AuthService(AuthController authController) {
        this.authController = authController;
    }
	
	public UserResponseDto login(UserRequestDto requestDto) {
		
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(requestDto.getUsername(), requestDto.getPassword())
				);
		
		User user = (User) authentication.getPrincipal();
		
		
		String token = authUtil.generateToken(user);
		
		return UserResponseDto(token, user.getId());
	}

	public SignResponseDto signup(UserRequestDto signRequestDto) {
		
		User user = repository.findByUsername(signRequestDto.getUsername()).orElse(null);
		
		if (user != null) throw new IllegalArgumentException("User not Found exception"){
			
			user = repository.save(User().builder().username(signupRequest.getUsername).password(signRequest.getpassword().build());
		}
		
		return new SignResponseDto(user.getId(), user.getUsername());
	}

}
