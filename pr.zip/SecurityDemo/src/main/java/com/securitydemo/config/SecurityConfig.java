package com.securitydemo.config;

import java.net.http.HttpRequest;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	
	
//	Below method is used for disableing the default Spring Security Behaviour and allow for all request
//  Also there is no need to write   .csrf(csrf -> csrf.disable()) to make all request open 
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		

		http
            .csrf(csrf -> csrf.disable()) 
            .authorizeHttpRequests(auth -> auth
                .anyRequest().permitAll() 
            )
            .formLogin(Customizer.withDefaults());
		
		return http.build();
		
	}
	
	
	
//	@Bean
//	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//		
//
//		http
//            .authorizeHttpRequests(auth -> auth
//            	.requestMatchers("/public").permitAll()
//            	.requestMatchers("/admin").hasRole("ADMIN")
//                .anyRequest().authenticated()
//            );
//		
//		return http.build();
//		
//	}
	
	
	
	
	
	

}
