package com.securitydemo.dto;


public class SignResponseDto {
	
	
	private long id;
	
	private String username;

	public SignResponseDto(long id, String username) {
		super();
		this.id = id;
		this.username = username;
	}

	public SignResponseDto() {
		super();
	}
	
	
	
	
	
	

}
