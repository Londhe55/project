package com.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapi.dto.LoginRequestDTO;

@RestController
@RequestMapping("/student")
public class JWTController {
	
	@Autowired
	private AuthenticationManager authenticationManager;

	
	@PostMapping("/login")
	public LoginRequestDTO login(@RequestBody LoginRequestDTO requestDTO ) {
		return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(LoginRequestDTO.get)).;
		
	}

}
