package com.restapi.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.restapi.entity.User;
import com.restapi.service.UserService;

@RestController
@RequestMapping("/user")
public class HelloController {
	
	@Autowired
	UserService service;
	
	
	@GetMapping("/hello")
	public String hello() {
		return "Hello Dharmavir";
	}
	
	
	@PostMapping("insert")
	public String addData(@RequestBody User user) {
		return service.save(user);
	}
	
	
	@GetMapping("/read")
	public List<User> findAll() {
		return service.findAllUser();
	}
	
	
	
	@GetMapping("/read/{id}")
	public Optional<User> retrive(@PathVariable int id){
		return service.getUserById(id);
	}
	
	@PutMapping("/update/{id}")
	public String updateUserById(@PathVariable int id, @RequestBody User user) {
		return service.updateUserById(id,user);
	}
	
	
	@DeleteMapping("/delete/{id}")
	public String deleteUserById(@PathVariable int id) {
		System.out.println("Controller Called");
		return service.deleteUserById(id);
	}
	
	
	@GetMapping("/read/name/{name}")
	public List<User> getUserByName(@PathVariable String name) {
		
		return service.findUserByName(name);
	}
	
	
}
