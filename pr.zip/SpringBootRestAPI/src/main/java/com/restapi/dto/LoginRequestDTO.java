package com.restapi.dto;


public class LoginRequestDTO {
	
	
	String userName;
	String password;
	
	
	

}
