package com.restapi.dto;


public class RequestDTO {

}
