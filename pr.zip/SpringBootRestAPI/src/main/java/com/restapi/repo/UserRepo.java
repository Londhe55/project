package com.restapi.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.restapi.entity.User;

public interface UserRepo extends JpaRepository<User, Integer>{
	
	List<User> findByFirstName(String firstName);

    List<User> findByLastName(String lastName);

    List<User> findByAge(int age);

    List<User> findByCityName(String cityName);
    List<User> findByFirstNameOrLastName(String firstName, String lastName);

}
