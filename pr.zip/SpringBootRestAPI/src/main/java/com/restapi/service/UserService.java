package com.restapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapi.entity.User;
import com.restapi.repo.UserRepo;

@Service
public class UserService {

	
	@Autowired
	UserRepo repo;
	
	
	public String  save(User user) {
		repo.save(user);

		return "User Registerd Successfully";
	}


	public Optional<User> getUserById(int id) {
		Optional<User> userList = repo.findById(id);
		if (userList.isEmpty()) {
			return null;
		}
		return userList;
	}


	public List<User> findAllUser() {
		List<User> userList = repo.findAll();
		if (userList.isEmpty()) {
			return null;
		}
		
		return userList;
	}


	public String updateUserById(int id, User user) {
		User userInfo = repo.findById(id).orElse(null);
		
		if (userInfo == null) {
			return null;
		}
		userInfo.setAge(user.getAge());
		userInfo.setCityName(user.getCityName());
		
		repo.save(userInfo);
		
		return "User Updated Succefully";
	}


	public List<User> findUserByName(String name) {
	    return repo.findByFirstName(name); 
	}


	public String deleteUserById(int id) {
		System.out.println("Service Called");
		repo.deleteById(id);
		return "User Deleted Successfully";
	}

}
