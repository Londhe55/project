package com.userservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.userservice.dto.AuthResponseDTO;
import com.userservice.dto.LoginRequestDTO;
import com.userservice.dto.UserRequestDTO;
import com.userservice.service.UserService;

@RestController
@RequestMapping("/users")
public class AuthController {

    @Autowired
    private UserService userService;

    // ✅ Register API
    @PostMapping("/register")
    public String registerUser(@RequestBody UserRequestDTO userRequest) {
        return userService.registerUser(userRequest);
    }

    // ✅ Login API
    @PostMapping("/login")
    public AuthResponseDTO loginUser(@RequestBody LoginRequestDTO loginRequest) {
        return userService.loginUser(loginRequest);
    }
}