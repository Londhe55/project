package com.userservice.service;

import com.userservice.dto.AuthResponseDTO;
import com.userservice.dto.LoginRequestDTO;
import com.userservice.dto.UserRequestDTO;

public interface UserService {

    String registerUser(UserRequestDTO userRequest);

    AuthResponseDTO loginUser(LoginRequestDTO loginRequest);
}
