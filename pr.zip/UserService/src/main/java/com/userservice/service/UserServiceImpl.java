package com.userservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.userservice.dto.AuthResponseDTO;
import com.userservice.dto.LoginRequestDTO;
import com.userservice.dto.UserRequestDTO;
import com.userservice.entity.User;
import com.userservice.repository.UserRepository;
import com.userservice.security.JwtUtil;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    // ✅ Register User
    @Override
    public String registerUser(UserRequestDTO userRequest) {

        Optional<User> existingUser = userRepository.findByEmail(userRequest.getEmail());

        if (existingUser.isPresent()) {
            return "User already exists with this email";
        }

        User user = new User();
        user.setName(userRequest.getName());
        user.setEmail(userRequest.getEmail());

        // 🔐 Encrypt password
        user.setPassword(passwordEncoder.encode(userRequest.getPassword()));

        user.setRole(userRequest.getRole());

        userRepository.save(user);

        return "User registered successfully";
    }

    // ✅ Login User
    @Override
    public AuthResponseDTO loginUser(LoginRequestDTO loginRequest) {

        User user = userRepository.findByEmail(loginRequest.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid Email or Password"));

        // ✅ Check password
        if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid Email or Password");
        }

        // ✅ Generate JWT Token
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole());

        return new AuthResponseDTO(token, user.getRole());
    }
}
