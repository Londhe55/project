package com.orderservice.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orderservice.client.ProductClient;
import com.orderservice.dto.OrderRequestDTO;
import com.orderservice.dto.OrderResponseDTO;
import com.orderservice.dto.ProductDTO;
import com.orderservice.entity.Order;
import com.orderservice.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductClient productClient;

    // ✅ Place Order
    @Override
    public OrderResponseDTO placeOrder(OrderRequestDTO request, String userEmail) {

        // 🔥 Step 1: Call Product Service
        ProductDTO product = productClient.getProductById(request.getProductId());

        if (product == null) {
            throw new RuntimeException("Product not found");
        }

        // 🔥 Step 2: Check stock
        if (product.getQuantity() < request.getQuantity()) {
            throw new RuntimeException("Insufficient stock");
        }

        // 🔥 Step 3: Calculate total price
        double totalPrice = product.getPrice() * request.getQuantity();

        // 🔥 Step 4: Create Order
        Order order = new Order();
        order.setUserEmail(userEmail);   // ✅ from JWT
        order.setProductId(product.getId());
        order.setQuantity(request.getQuantity());
        order.setTotalPrice(totalPrice);
        order.setStatus("PLACED");

        // 🔥 Step 5: Save Order
        Order savedOrder = orderRepository.save(order);

        // 🔥 Step 6: Return DTO
        return mapToResponseDTO(savedOrder);
    }

    // ✅ Get Orders by User
    @Override
    public List<OrderResponseDTO> getOrdersByUser(String userEmail) {

        List<Order> orders = orderRepository.findByUserEmail(userEmail);

        return orders.stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    // ✅ Helper Method
    private OrderResponseDTO mapToResponseDTO(Order order) {

        return new OrderResponseDTO(
                order.getId(),
                order.getProductId(),
                order.getQuantity(),
                order.getTotalPrice(),
                order.getStatus()
        );
    }
}