package com.orderservice.service;

import java.util.List;

import com.orderservice.dto.OrderRequestDTO;
import com.orderservice.dto.OrderResponseDTO;

public interface OrderService {

    OrderResponseDTO placeOrder(OrderRequestDTO request, String userEmail);

    List<OrderResponseDTO> getOrdersByUser(String userEmail);
}