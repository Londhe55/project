package com.orderservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.orderservice.dto.OrderRequestDTO;
import com.orderservice.dto.OrderResponseDTO;
import com.orderservice.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // ✅ Place Order
    @PostMapping
    public OrderResponseDTO placeOrder(@RequestBody OrderRequestDTO request) {

        // ✅ Extract Authentication object
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // ✅ Extract email (principal)
        String userEmail = (String) authentication.getPrincipal();

        return orderService.placeOrder(request, userEmail);
    }

    // ✅ Get Orders for logged-in user
    @GetMapping
    public List<OrderResponseDTO> getOrders() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userEmail = (String) authentication.getPrincipal();

        return orderService.getOrdersByUser(userEmail);
    }
}