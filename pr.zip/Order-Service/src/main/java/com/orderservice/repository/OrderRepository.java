package com.orderservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.orderservice.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

    // ✅ Get orders for a particular user
    List<Order> findByUserEmail(String userEmail);
}