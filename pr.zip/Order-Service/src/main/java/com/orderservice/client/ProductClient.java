package com.orderservice.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.orderservice.dto.ProductDTO;

@Component
public class ProductClient {

    @Autowired
    private RestTemplate restTemplate;

    private static final String PRODUCT_URL = "http://localhost:8081/products/";

    public ProductDTO getProductById(Long productId) {

        String url = PRODUCT_URL + productId;

        return restTemplate.getForObject(url, ProductDTO.class);
    }
}
