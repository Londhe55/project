package com.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityUsingJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityUsingJwtApplication.class, args);
	}

}
