package com.auth.security;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth.service.CustomUserDetailsService;

import java.io.IOException;

@Component
public class JwtFilter extends OncePerRequestFilter {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private CustomUserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String authHeader = request.getHeader("Authorization");
		String token = null;
		String username = null;

		if (authHeader != null && authHeader.startsWith("Bearer ")) {
			token = authHeader.substring(7).trim();
		}

		if (token != null) {
			try {
				username = jwtUtil.extractUsername(token);
			} catch (Exception e) {

				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.setContentType("application/json");

				response.getWriter().write("{\"error\":\"Invalid or expired JWT token\"}");

				return;
			}
		}

		if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

			UserDetails userDetails = userDetailsService.loadUserByUsername(username);

			System.out.println(" Username: " + username);
			System.out.println(" Authorities: " + userDetails.getAuthorities());

			if (jwtUtil.validateToken(token, userDetails.getUsername())) {

				UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,
						null, userDetails.getAuthorities());

				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

				SecurityContextHolder.getContext().setAuthentication(authToken);

			} else {

				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.setContentType("application/json");

				response.getWriter().write("{\"error\":\"Invalid JWT token\"}");

				return;
			}
		}

		filterChain.doFilter(request, response);
	}
}