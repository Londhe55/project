package com.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.security.authentication.BadCredentialsException;

import com.auth.dto.*;
import com.auth.entity.User;
import com.auth.exception.UserAlreadyExistsException;
import com.auth.repository.UserRepository;
import com.auth.security.JwtUtil;

@Service
public class AuthService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtUtil;

	public String register(RegisterRequest request) {

	    if (userRepository.findByUsername(request.getUsername()).isPresent()) {
	    	throw new UserAlreadyExistsException("Username already exists");
	    }

	    User user = new User();

	    user.setUsername(request.getUsername());
	    user.setPassword(passwordEncoder.encode(request.getPassword()));
	    user.setRole("ROLE_" + request.getRole().toUpperCase());

	    userRepository.save(user);

	    return "User registered successfully";
	}

	public AuthResponse login(AuthRequest request) {

		authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

		User user = userRepository.findByUsername(request.getUsername())
				.orElseThrow(() -> new UsernameNotFoundException("User not found"));

		String token = jwtUtil.generateToken(user.getUsername(), user.getRole());

		return new AuthResponse(token);
	}
}