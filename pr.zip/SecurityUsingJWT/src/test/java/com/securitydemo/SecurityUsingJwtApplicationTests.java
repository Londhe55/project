package com.securitydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityUsingJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
