/**
 * 
 */
/**
 * 
 */
module Practice {
}