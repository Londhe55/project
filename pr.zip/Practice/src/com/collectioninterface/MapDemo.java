package com.collectioninterface;

public class MapDemo {
	
	

}
