package com.stringndemo;

public class StringDemo {
	
	
	public static void main(String[] args) {
		
		String s = "Hello";
		
		s.concat("World");
		
		System.out.println(s);
		
		StringBuilder builder = new StringBuilder("Hello");
		
		
		builder.append("veer");
		
		
		
		System.out.println(builder);
	}
	

}
