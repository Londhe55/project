package com.patternMatching;

public class PatternMatchingDemo {
	
	public static void main(String[] args) {
		
		
		
		Object obj = "Hello";
		
		if(obj instanceof String) {
			String s = (String) obj;   // Here we need Explicit Type Casting 
			System.out.println(s.length());
			
		}
		
		
		Object obj2 = "Welcome";
		
		if(obj2 instanceof String s) {               // This is called pattern Matching
			System.out.println(s.length());
		}
		
		
		// Pattern Matching for the Switch
		
		
		Object obj3 = "Welcome";
		Object obj4 = "10";
		
		
		switch (obj3) {
		case String s:
			System.out.println(s.toUpperCase());
			break;

		case Integer i:
			System.out.println(i*2);
		default:
			System.out.println("Default");
			break;
		}
				
				
				
	}

}
