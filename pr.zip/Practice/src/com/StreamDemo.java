package com;

import java.net.Socket;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StreamDemo {
	
	public static void main(String[] args) {
		
		
//		List<Integer> list = Arrays.asList(1,3,4,5,2,5);
//		List<Integer> list1 = Arrays.asList(1,2,3,4,5);
//		
//		list.stream().filter(s -> s > 1).forEach(s -> System.out.println(s));
//		
//		list.stream().forEach(s -> System.out.println(s));
//		
//		
//		
//		list.stream().map(s -> s*s).forEach(s -> System.out.println(s));
//		
//		System.out.println(list.stream().filter(s -> s >2).collect(Collectors.toList()));
//		list.stream().filter(s -> s >2).collect(Collectors.toList()).forEach(s -> System.out.println(s));
//		
//		list.stream().sorted().forEach(s -> System.out.println(s));
//		
//		System.out.println("Count");
//		System.out.println(list.stream().distinct().count());
//		list.stream().limit(3).forEach(s -> System.out.println(s));
//		
//		System.out.println();
//		
//		int max = list.stream().max((s1,s2) -> s1-s2).get();
//		System.out.println(max);
//		System.out.println("Min");
//		System.out.println(list.stream().min(Integer::compare).get());
//		
//	
//		int sum = list.stream().reduce(0, (a,b) ->a+b);
//		System.out.println(sum);
//		
//		System.out.println(list.stream().allMatch(s -> s>3));
//		System.out.println(list.stream().anyMatch(s -> s==5));
//		
//		System.out.println(list.stream().equals(list));
//		
//		
//		System.out.println(list.stream().findAny().orElse(null));
//		
//		System.out.println(list.stream().collect(Collectors.groupingBy(n -> n, Collectors.counting())));
//		
//		
//		System.out.println("Below return HashSet Bydefault :");
//		System.out.println(list.stream().collect(Collectors.toSet()));
//		
//		System.out.println("when you want to return treeset then use below one");
//		System.out.println(list.stream().collect(Collectors.toCollection(TreeSet::new)));
		
		
		List<Integer> list3 = Arrays.asList(1,2,4,2,4,6,8);
		
		List<String> list4 = Arrays.asList("Hello", "Wor777ld", "India1111576761");
		
		
		
		//Even
		list3.stream().filter(n -> n%2 == 0).forEach(s -> System.out.println(s));
		
		//Find Longest String
		System.out.println(list4.stream().max(Comparator.comparing(String::length)).get());
		
		
		// Char frequency
		String str = "Hello World";
		Map<Character,Long> result = str.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(result);
		System.out.println("Char Freq");
		System.out.println(Arrays.asList(str.split("")).stream().collect(Collectors.groupingBy(s -> s, Collectors.counting())));
		
		
		// List into UpperCase
		list4.stream().map(String::toUpperCase).forEach(s -> System.out.println(s));
		
		
		// List into Ascending order
		list3.stream().sorted(Collections.reverseOrder()).forEach(s -> System.out.println(s));
		
		
		// Remove Duplicates
		System.out.println("Duplicates");
		list3.stream().distinct().forEach(s -> System.out.println(s));
		
		
		//Count Duplicates 
		System.out.println("Distinct Element");
		System.out.println(list3.stream().distinct().count());
		
		
		// findFirst
		int first = list3.stream().findFirst().get();
		System.out.println(first);
		
		
		//find max
		System.out.println("Max");
		System.out.println(list3.stream().max(Integer::compareTo));
		
		//Find Minimum
		System.out.println("Minimum");
		System.out.println(list3.stream().min(Integer::compareTo));
		
		
		// Sum of Number
		System.out.println("Sum");
		System.out.println(list3.stream().mapToInt(Integer:: intValue).sum());
		
		// Sum
		System.out.println("Sum");
		System.out.println(list3.stream().reduce(0, (a,b) -> a+b));
		
		
		System.out.println("Average");
		System.out.println(list3.stream().mapToDouble(Integer::intValue).average().getAsDouble());
		
		
		
		// find Shortest String
		System.out.println("Shortest String");
		System.out.println(list4.stream().min(Comparator.comparing(String::length)).get());
		
		
		
		// Find alphabetical
		System.out.println("AlphaBetical");
		System.out.println(list4.stream().sorted().collect(Collectors.toList()));
		
		
		
		//Count String Occurrences
		System.out.println(list4.stream().collect(Collectors.groupingBy(s->s, Collectors.counting())));
		
		
		String str2 = "Hello";
		
		List<String> res = Arrays.asList(str2.split(""));
		
		System.out.println(res.stream().collect(Collectors.groupingBy(s -> s, Collectors.counting())));
		
		
		System.out.println(res.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting())));
		
		
		
		// Second Highest
		
		System.out.println("Second Highest");
		System.out.println(list3.stream().distinct().sorted(Collections.reverseOrder()).skip(1).findFirst().get());
		
		
		
		
	}

}
