package com.functinalinterface;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class ConsumerDemo {
	
	public static void main(String[] args) {
		
		
		Consumer<String> consumer = s -> System.out.println(s.toUpperCase());
		consumer.accept("hello");
		
		
		List<Integer> list = Arrays.asList(1,21,43,34,49,70,85,85);
		
		List<String> list1 = Arrays.asList("Apple", "Orange", "Mango","Banana");
		
		
		System.out.println("List Using forEach Consumer");
		list.stream().forEach(s -> System.out.println(s));
		
		int max1 = list.stream().max((s1,s2) -> s1-s2).get();
		int max2 = list.stream().max(Integer::compare).get();
		System.out.println("Max");
		System.out.println(max1);
		System.out.println(max2);
		
		
		int min1 = list.stream().min(Integer::compare).get();
		int min2 = list.stream().min((s1,s2) -> s1-s2).get();
		System.out.println("Min");
		System.out.println(min1);
		System.out.println(min2);
		
		
		System.out.println("Distinct");
		
		list.stream().distinct().sorted().forEach(s -> System.out.println(s));
		
		System.out.println("Use of Reduce ");
		
		int result = list.stream().reduce(0, (s1,s2) -> s1 +s2);
		System.out.println(result);
		
		
		System.out.println("AnyMatch");
		boolean anyMatch = list.stream().anyMatch(s -> s ==8);
		System.out.println(anyMatch);
		
		
		System.out.println("AllMatch");
		boolean allMatch = list.stream().allMatch(s -> s%2==0);
		System.out.println(allMatch);
		
		
		System.out.println("Use of count");
		long count = list.stream().filter(s -> s >4).count();
		System.out.println(count);
		
		System.out.println("use of FindAny: It return next elemnt where you condition applied");
		int any= list.stream().filter(s -> s %2 == 0).findAny().get();
		System.out.println(any);
		
		System.out.println("FindFirst  : ");
		int findFirst = list.stream().filter(s -> s %2 == 0).findFirst().get();
		System.out.println(findFirst);
		
		
		System.out.println("Finding Even Number :");
		list.stream().filter(n -> n%2==0).forEach(s -> System.out.println(s));
		
		System.out.println("Finding Odd Number :");
		list.stream().filter(n -> n%2!=0).forEach(s -> System.out.println(s));
		
		System.out.println("convert List to set and also Used Filter");
		list.stream().filter(n -> n>2).collect(Collectors.toSet()).forEach(s -> System.out.println(s));
		System.out.println("convert List to Set directly using collect function");
		list.stream().collect(Collectors.toSet()).forEach(s -> System.out.println(s));
		
		
		System.out.println("map");
		list.stream().map(s -> s*s).forEach(s -> System.out.println(s));
		
		
		System.out.println("Find Second Highest Number :");

		int secondMax = list.stream()
			        .distinct()
			        .sorted((a,b) -> b-a)
			        .skip(1)
			        .findFirst()
			        .get();
		System.out.println(secondMax);
			
		
		System.out.println("Collectors :");	
		Map<Boolean, List<Integer>> map =
		list.stream()
		            .collect(Collectors.groupingBy(s -> s % 2 == 0));
		
		map.forEach((k, v) -> System.out.println(k + " -> " + v));

			
		
	
	   System.out.println("Joining Strings ");
	   String res = list1.stream().collect(Collectors.joining("-"));
	   System.out.println(res);
	   
	   
	   System.out.println("String Operation ");
	   list1.stream().map(s -> s.toUpperCase()).forEach(s -> System.out.println(s));
	   list1.stream().map(s -> s.length()).forEach(s -> System.out.println("Length of Each Word is :" + s));

		
		
	   
		
	}
	

}
