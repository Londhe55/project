package com.functinalinterface;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class PredicateDemo {
	
	public static void main(String[] args) {
		
		
		Predicate<Integer> predicate = x -> x>10;
		
		
		System.out.println(predicate.test(78));
		
		
		List<Integer> list = Arrays.asList(10,12,3,5,1,2);
		
	    list.stream().filter(x -> x > 5).forEach(x -> System.out.println(x));
		
		System.out.println();
		
		
		list.stream().filter(x -> x%2 == 0).filter(x -> x >10).forEach(x -> System.out.println(x));
		
		
	}

}
