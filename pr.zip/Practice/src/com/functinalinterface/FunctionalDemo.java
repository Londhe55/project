package com.functinalinterface;

import java.util.function.Function;

public class FunctionalDemo {
	
	
	public static void main(String[] args) {
		
		Function<Integer, Integer> function = s -> s*s;
		System.out.println(function.apply(5));
	}

}
