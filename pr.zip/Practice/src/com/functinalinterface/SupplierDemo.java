package com.functinalinterface;

import java.util.function.Supplier;

public class SupplierDemo {
	
	public static void main(String[] args) {
		
		Supplier<Integer> supplier = () -> 4;
		System.out.println(supplier.get());
		
		
		
	}

}
