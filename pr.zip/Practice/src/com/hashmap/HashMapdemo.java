package com.hashmap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMapdemo {
	
	public static void main(String[] args) {
		
		
		Map<Integer, String> map = new HashMap<>();
		
		map.put(1, "veer");
		map.put(2, "Sham");
		map.put(3, "ram");
		
		
		// using Stram
		map.entrySet().stream().forEach(s -> System.out.println(s.getKey() + " " +s.getValue()));
		
		
		// using Entry Set Using for Loop
		for(Map.Entry<Integer, String> map1 : map.entrySet()) {
			
			System.out.println(map1.getKey() + " "+map1.getValue());
		}
		
		
		// Iterate keys, then get value
		
		for(Integer key: map.keySet()) {
			System.out.println(key + " " + map.get(key));
	
		}
		
		
		
		// Using Iterator
		

		Iterator<Map.Entry<Integer, String>> it = map.entrySet().iterator();

		while (it.hasNext()) {
			Map.Entry<Integer, String> entry = it.next();
			System.out.println(entry.getKey() + " " + entry.getValue());
		}

	}

}
