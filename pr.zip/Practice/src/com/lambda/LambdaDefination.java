package com.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class LambdaDefination {
	
	

	
		public static void main(String[] args) {
			
			Runnable r = new Runnable() {
				
				@Override
				public void run() {
					System.out.println("Runnable is running without Lambda Expression");
				}
			};
			
			r.run();
			
			Runnable r1 = () -> System.out.println("Runnable is Running Using lambda Expression");
			
			
			r1.run();
			
			
			
			Consumer<String> s = s1 -> System.out.println(s1.toUpperCase());
			s.accept("Hello");
			
			
			
			
			
			List<String> list1 = Arrays.asList("Apple", "Banana", "Apple");
			
			Map<String, Long> result = list1.stream()
				    .collect(Collectors.groupingBy(s1 -> s1, Collectors.counting()));

				System.out.println(result);
				
		}
		
		
		
		
	 
	 
		
		
		
		

}
