package com.sealedclass;


// Here Error Because Class A is final class 
// so we can not extend 

//public class F extends A{
//	public void show() {
//		System.out.println("Message from B");
//	}
//
//}
