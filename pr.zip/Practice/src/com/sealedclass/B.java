package com.sealedclass;

public non-sealed class B extends SealedClassDemo {

	public void show() {
		System.out.println("Sealed Class from B");
	}
}
