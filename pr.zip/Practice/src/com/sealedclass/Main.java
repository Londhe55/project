package com.sealedclass;

public class Main {
	
	public static void main(String[] args) {
		
		
		SealedClassDemo demo = new SealedClassDemo();
		
		SealedClassDemo demo1 = new B();
	
		SealedClassDemo demo2 = new A();
		
		C demo3 = new C();
		
		D demo4 = new D();
		
		E demo5 = new E();
		
//		F demo6 = new F();
		
		demo.show();
		demo1.show();
		demo2.show();
		demo3.show();
		demo4.show();
		demo5.show();
//		demo6.show();
		
	}

}
