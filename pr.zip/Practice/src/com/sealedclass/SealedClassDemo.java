package com.sealedclass;
 
sealed class SealedClassDemo permits A,B,C {
	
	public void show() {
		System.out.println("Sealed Class");
	}

}
