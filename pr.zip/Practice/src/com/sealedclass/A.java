package com.sealedclass;

public final class A extends SealedClassDemo {
	
	public void show() {
		System.out.println("Sealed class from A");
	}

}
