package com.sealedclass;


// B is sealed class so we can Extend the class B 

public final class E extends B{

	public void show() {
		System.out.println("Message From Class C");
	}
}
