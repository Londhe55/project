package com.sealedclass;


// Here C is the sealed class so we can extend the C class 

public final class D extends C {
	
	
	public void Show() {
		System.out.println("Message From Class D");
	
	}
	
	

}

