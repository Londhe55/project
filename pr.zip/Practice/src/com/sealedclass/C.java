package com.sealedclass;

public sealed class C extends SealedClassDemo permits D {

    @Override
    public void show() {
        System.out.println("Class C");
    }
}