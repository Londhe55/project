package com.Map_FlatMap;

import java.util.List;

public class FlatMapDemo {
	
	public static void main(String[] args) {
		
		
		List<List<Integer>> list = List.of(List.of(1,2), List.of(3,4));
		
		System.out.println(list);
		
		list.stream().map(l -> l.stream()).forEach(s -> System.out.println(s));
		list.stream().flatMap(l -> l.stream()).forEach(s -> System.out.println(s));
		
		
		
		
	}

}
