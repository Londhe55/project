
package com.record;

public class Main {
	
	public static void main(String[] args) {
		
		RecordDemo demo = new RecordDemo(1, "Veer");
		
		System.out.println(demo);
		
//		demo.setName("Dharmavir");          // Record class are Imutable so we can't change the value of Name 
		
		System.out.println(demo.name());
	}
}
