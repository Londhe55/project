package com.record;

public record  RecordDemo (int rollNumber, String name) {}
