package com.trading.company.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import com.trading.company.entity.TradingCompany;
import com.trading.company.service.TradingCompanyService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(TradingCompanyController.class)
class TradingCompanyControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private TradingCompanyService tradingCompanyService;

    // Create Trading Company

    @Test
    void testCreateTradingCompany() throws Exception {

        TradingCompany company = new TradingCompany();

        when(tradingCompanyService.createTradingCompany(any()))
                .thenReturn(company);

        String json = """
                {
                    "tradingCompany": {
                        "name":"TCS Trading",
                        "licenseNumber":"LIC-1001",
                        "contactEmail":"support@tcs.com",
                        "address":"Chennai"
                    }
                }
                """;

        mockMvc.perform(post("/companies")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk());

        verify(tradingCompanyService)
                .createTradingCompany(any());
    }

    // Get Trading Company By Id

    @Test
    void testGetTradingCompanyById() throws Exception {

        TradingCompany company = new TradingCompany();

        when(tradingCompanyService.getTradingCompanyById(1L))
                .thenReturn(company);

        mockMvc.perform(get("/companies/1"))
                .andExpect(status().isOk());

        verify(tradingCompanyService)
                .getTradingCompanyById(1L);
    }

    // Get All Trading Companies

    @Test
    void testGetAllTradingCompanies() throws Exception {

        TradingCompany company = new TradingCompany();

        when(tradingCompanyService.getAllTradingCompanies())
                .thenReturn(List.of(company));

        mockMvc.perform(get("/companies"))
                .andExpect(status().isOk());

        verify(tradingCompanyService)
                .getAllTradingCompanies();
    }

    // Update Trading Company

    @Test
    void testUpdateTradingCompany() throws Exception {

        TradingCompany company = new TradingCompany();

        when(tradingCompanyService.updateTradingCompany(
                eq(1L), any()))
                .thenReturn(company);

        String json = """
                {
                    "tradingCompany": {
                        "name":"Updated Company",
                        "licenseNumber":"LIC-1001",
                        "contactEmail":"updated@test.com",
                        "address":"Mumbai"
                    }
                }
                """;

        mockMvc.perform(put("/companies/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk());

        verify(tradingCompanyService)
                .updateTradingCompany(eq(1L), any());
    }

    // Delete Trading Company

    @Test
    void testDeleteTradingCompany() throws Exception {

        TradingCompany company = new TradingCompany();

        when(tradingCompanyService.deleteTradingCompany(1L))
                .thenReturn(company);

        mockMvc.perform(delete("/companies/1"))
                .andExpect(status().isOk());

        verify(tradingCompanyService)
                .deleteTradingCompany(1L);
    }
}