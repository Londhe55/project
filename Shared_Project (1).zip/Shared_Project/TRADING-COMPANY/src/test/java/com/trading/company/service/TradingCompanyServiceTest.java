package com.trading.company.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import com.trading.company.dto.CreateTradingCompanyRequest;

import com.trading.company.entity.TradingCompany;
import com.trading.company.exception.DuplicateResourceException;
import com.trading.company.exception.ResourceNotFoundException;
import com.trading.company.repository.TradingCompanyRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TradingCompanyServiceTest {

    @Mock
    private TradingCompanyRepository repository;

    @InjectMocks
    private TradingCompanyService companyService;

    // Create Trading Company

    @Test
    void testCreateTradingCompany() {

        TradingCompany company = new TradingCompany();

        company.setName("TCS Trading");
        company.setLicenseNumber("LIC-1001");
        company.setContactEmail("support@tcs.com");
        company.setAddress("Chennai");

        CreateTradingCompanyRequest request = new CreateTradingCompanyRequest();

        request.setTradingCompany(company);

        when(repository.existsByLicenseNumber("LIC-1001")) .thenReturn(false);

        when(repository.existsByContactEmail("support@tcs.com")).thenReturn(false);

        when(repository.save(any(TradingCompany.class)))
                .thenReturn(company);

        TradingCompany result =
                companyService.createTradingCompany(request);

        assertNotNull(result);
        assertEquals(
                "TCS Trading",
                result.getName());

        verify(repository)
                .save(any(TradingCompany.class));
    }

    // Duplicate License Number

    @Test
    void testCreateTradingCompanyDuplicateLicense() {

        TradingCompany company = new TradingCompany();

        company.setLicenseNumber("LIC-1001");

        CreateTradingCompanyRequest request =
                new CreateTradingCompanyRequest();

        request.setTradingCompany(company);

        when(repository.existsByLicenseNumber("LIC-1001"))
                .thenReturn(true);

        assertThrows(
                DuplicateResourceException.class,
                () -> companyService.createTradingCompany(request));

        verify(repository, never())
                .save(any());
    }

    // Duplicate Email

    @Test
    void testCreateTradingCompanyDuplicateEmail() {

        TradingCompany company = new TradingCompany();

        company.setLicenseNumber("LIC-1001");
        company.setContactEmail("support@tcs.com");

        CreateTradingCompanyRequest request =
                new CreateTradingCompanyRequest();

        request.setTradingCompany(company);

        when(repository.existsByLicenseNumber("LIC-1001"))
                .thenReturn(false);

        when(repository.existsByContactEmail("support@tcs.com"))
                .thenReturn(true);

        assertThrows(
                DuplicateResourceException.class,
                () -> companyService.createTradingCompany(request));

        verify(repository, never())
                .save(any());
    }

    // Get Trading Company By Id

    @Test
    void testGetTradingCompanyById() {

        TradingCompany company =
                new TradingCompany();

        company.setId(1L);
        company.setName("TCS Trading");

        when(repository.findById(1L))
                .thenReturn(Optional.of(company));

        TradingCompany result =
                companyService.getTradingCompanyById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
    }

    // Get Trading Company By Id Not Found

    @Test
    void testGetTradingCompanyByIdNotFound() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> companyService.getTradingCompanyById(1L));
    }

    // Get All Trading Companies

    @Test
    void testGetAllTradingCompanies() {

        TradingCompany company1 =
                new TradingCompany();

        TradingCompany company2 =
                new TradingCompany();

        when(repository.findAll())
                .thenReturn(List.of(company1, company2));

        List<TradingCompany> companies =
                companyService.getAllTradingCompanies();

        assertNotNull(companies);
        assertEquals(2, companies.size());
    }

    // Update Trading Company

    @Test
    void testUpdateTradingCompany() {

        TradingCompany existingCompany =
                new TradingCompany();

        existingCompany.setId(1L);

        TradingCompany updatedCompany =
                new TradingCompany();

        updatedCompany.setName("Infosys Trading");
        updatedCompany.setLicenseNumber("LIC-2002");
        updatedCompany.setContactEmail("info@infosys.com");
        updatedCompany.setAddress("Bangalore");

        CreateTradingCompanyRequest request =
                new CreateTradingCompanyRequest();

        request.setTradingCompany(updatedCompany);

        when(repository.findById(1L))
                .thenReturn(Optional.of(existingCompany));

        when(repository.save(any(TradingCompany.class)))
                .thenReturn(existingCompany);

        TradingCompany result =
                companyService.updateTradingCompany(
                        1L,
                        request);

        assertNotNull(result);

        verify(repository)
                .save(any(TradingCompany.class));
    }

    // Update Trading Company Not Found

    @Test
    void testUpdateTradingCompanyNotFound() {

        CreateTradingCompanyRequest request =
                new CreateTradingCompanyRequest();

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> companyService.updateTradingCompany(
                        1L,
                        request));
    }

    // Delete Trading Company

    @Test
    void testDeleteTradingCompany() {

        TradingCompany company =
                new TradingCompany();

        company.setId(1L);

        when(repository.findById(1L))
                .thenReturn(Optional.of(company));

        TradingCompany deletedCompany =
                companyService.deleteTradingCompany(1L);

        assertNotNull(deletedCompany);

        verify(repository)
                .delete(company);
    }

    // Delete Trading Company Not Found

    @Test
    void testDeleteTradingCompanyNotFound() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> companyService.deleteTradingCompany(1L));
    }
}