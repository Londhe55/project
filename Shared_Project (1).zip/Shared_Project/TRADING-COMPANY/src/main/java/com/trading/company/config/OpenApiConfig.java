package com.trading.company.config;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI tradingCompanyOpenAPI() {

        return new OpenAPI()
                .info(new Info()
                        .title("Trading Company Service API")
                        .description("Microservice for managing trading companies")
                        .version("1.0")
                        .contact(new Contact()
                                .name("Trading Team")
                                .email("support@trading.com")));
    }
}
