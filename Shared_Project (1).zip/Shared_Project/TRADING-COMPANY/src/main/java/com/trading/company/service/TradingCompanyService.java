package com.trading.company.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.trading.company.dto.CreateTradingCompanyRequest;
import com.trading.company.entity.TradingCompany;
import com.trading.company.exception.DuplicateResourceException;
import com.trading.company.exception.ResourceNotFoundException;
import com.trading.company.repository.TradingCompanyRepository;

@Service
public class TradingCompanyService {

    private final TradingCompanyRepository tradingCompanyRepository;

    public TradingCompanyService(TradingCompanyRepository tradingCompanyRepository) {

        this.tradingCompanyRepository = tradingCompanyRepository;
    }

    // Create Trading Company

    public TradingCompany createTradingCompany(CreateTradingCompanyRequest request) {

        TradingCompany company =request.getTradingCompany();

        if (tradingCompanyRepository.existsByLicenseNumber(company.getLicenseNumber())) {

            throw new DuplicateResourceException("License Number already exists : "
                            	+ company.getLicenseNumber());
        }

        if (tradingCompanyRepository.existsByContactEmail(company.getContactEmail())) {

            throw new DuplicateResourceException("Email already exists : "
                            	+ company.getContactEmail());
        }

        company.setCreatedAt(LocalDateTime.now());

        return tradingCompanyRepository.save(company);
    }

    // Get Trading Company By Id

    public TradingCompany getTradingCompanyById(Long id) {

        return tradingCompanyRepository.findById(id).orElseThrow(() ->
                        	new ResourceNotFoundException(
                                "Trading Company not found with id : "+ id));
    }

    // Get All Trading Companies

    public List<TradingCompany>
    getAllTradingCompanies() {

        return tradingCompanyRepository.findAll();
    }

    // Update Trading Company

    public TradingCompany updateTradingCompany(Long id,CreateTradingCompanyRequest request) {

        TradingCompany existingCompany = tradingCompanyRepository.findById(id).orElseThrow(() ->
                                		new ResourceNotFoundException("Trading Company not found with id : "+ id));

        TradingCompany updatedCompany = request.getTradingCompany();

        existingCompany.setName(updatedCompany.getName());
        existingCompany.setLicenseNumber(updatedCompany.getLicenseNumber());
        existingCompany.setContactEmail( updatedCompany.getContactEmail());
        existingCompany.setAddress(updatedCompany.getAddress());
        existingCompany.setUpdatedAt(LocalDateTime.now());

        return tradingCompanyRepository.save(existingCompany);
    }

    // Delete Trading Company

    public TradingCompany deleteTradingCompany(Long id) {

        TradingCompany company =tradingCompanyRepository.findById(id).orElseThrow(() ->
                                	new ResourceNotFoundException(
                                        "Trading Company not found with id : "+ id));

        tradingCompanyRepository.delete(company);

        return company;
    }
}