package com.trading.company.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "trading_companies")
public class TradingCompany {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Company name is required")
    @Size(max = 150,
          message = "Company name cannot exceed 150 characters")
    @Column(name = "name",
            nullable = false,
            length = 150)
    private String name;

    @NotBlank(message = "License number is required")
    @Column(name = "license_number",
            nullable = false,
            unique = true)
    private String licenseNumber;

    @NotBlank(message = "Contact email is required")
    @Email(message = "Invalid email format")
    @Column(name = "contact_email",
            nullable = false,
            unique = true)
    private String contactEmail;

    @NotBlank(message = "Address is required")
    @Size(max = 250,
          message = "Address cannot exceed 250 characters")
    @Column(name = "address",
            nullable = false,
            length = 250)
    private String address;

    @Column(name = "created_at",
            nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    
    public TradingCompany() {
    }

    public TradingCompany(Long id,
                          String name,
                          String licenseNumber,
                          String contactEmail,
                          String address,
                          LocalDateTime createdAt,
                          LocalDateTime updatedAt) {

        this.id = id;
        this.name = name;
        this.licenseNumber = licenseNumber;
        this.contactEmail = contactEmail;
        this.address = address;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

    
    
   
}