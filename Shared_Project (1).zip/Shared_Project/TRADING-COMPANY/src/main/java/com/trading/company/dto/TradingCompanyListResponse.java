package com.trading.company.dto;

import java.util.List;

import com.trading.company.entity.TradingCompany;

public class TradingCompanyListResponse {

    private List<TradingCompany> companies;

    private int httpStatusCode;

    private String message;

    public List<TradingCompany> getCompanies() {
        return companies;
    }

    public void setCompanies(
            List<TradingCompany> companies) {
        this.companies = companies;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(
            int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(
            String message) {
        this.message = message;
    }
}