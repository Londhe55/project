package com.trading.company.dto;

import com.trading.company.entity.TradingCompany;

public class CreateTradingCompanyRequest {

    private TradingCompany tradingCompany;

    public TradingCompany getTradingCompany() {
        return tradingCompany;
    }

    public void setTradingCompany(
            TradingCompany tradingCompany) {
        this.tradingCompany = tradingCompany;
    }
}