package com.trading.company.dto;

import com.trading.company.entity.TradingCompany;

public class TradingCompanyResponse {

    private TradingCompany tradingCompany;

    private int httpStatusCode;

    private String message;

    public TradingCompany getTradingCompany() {
        return tradingCompany;
    }

    public void setTradingCompany(
            TradingCompany tradingCompany) {
        this.tradingCompany = tradingCompany;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(
            int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(
            String message) {
        this.message = message;
    }
}