package com.trading.company.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.trading.company.dto.CreateTradingCompanyRequest;
import com.trading.company.dto.TradingCompanyListResponse;
import com.trading.company.dto.TradingCompanyResponse;

import com.trading.company.entity.TradingCompany;
import com.trading.company.service.TradingCompanyService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/companies")
public class TradingCompanyController {

    private  TradingCompanyService tradingCompanyService;

    public TradingCompanyController(TradingCompanyService tradingCompanyService) {

        this.tradingCompanyService = tradingCompanyService;
    }

    
    // Create Trading Company

    @PostMapping
    @Operation(summary = "Create a new Trading Company")
    public ResponseEntity<TradingCompanyResponse>createTradingCompany(
            @Valid @RequestBody
            CreateTradingCompanyRequest request) {

        TradingCompany company =tradingCompanyService.createTradingCompany(request);

        TradingCompanyResponse response = new TradingCompanyResponse();

        response.setTradingCompany(company);
        response.setHttpStatusCode(201);
        response.setMessage("Trading Company Created Successfully");

        return ResponseEntity.ok(response);
    }

    // Get Trading Company By Id

    @GetMapping("/{id}")
    @Operation(summary = "Get Trading Company By Id")
    public ResponseEntity<TradingCompanyResponse> getTradingCompanyById(@PathVariable Long id) {

        TradingCompany company = tradingCompanyService.getTradingCompanyById(id);

        TradingCompanyResponse response = new TradingCompanyResponse();

        response.setTradingCompany(company);
        response.setHttpStatusCode(200);
        response.setMessage("Trading Company Found Successfully");

        return ResponseEntity.ok(response);
    }

    // Get All Trading Companies

    @GetMapping
    @Operation(summary = "Get All Trading Companies")
    public ResponseEntity<TradingCompanyListResponse>
    getAllTradingCompanies() {

        List<TradingCompany> companies = tradingCompanyService.getAllTradingCompanies();

        TradingCompanyListResponse response = new TradingCompanyListResponse();

        if (!companies.isEmpty()) {

            response.setCompanies(companies);
            response.setHttpStatusCode(200);
            response.setMessage(companies.size()+ " Trading Companies Found");

            return ResponseEntity.ok(response);
        }

        response.setCompanies(null);
        response.setHttpStatusCode(404);
        response.setMessage("No Trading Companies Found");

        return ResponseEntity.notFound().build();
    }

    // Update Trading Company

    @PutMapping("/{id}")
    @Operation(summary = "Update Trading Company")
    public ResponseEntity<TradingCompanyResponse> updateTradingCompany(
            @PathVariable Long id, @Valid @RequestBody
            CreateTradingCompanyRequest request) {

        TradingCompany company =tradingCompanyService.updateTradingCompany(id,request);

        TradingCompanyResponse response = new TradingCompanyResponse();

        response.setTradingCompany(company);
        response.setHttpStatusCode(200);
        response.setMessage("Trading Company Updated Successfully");

        return ResponseEntity.ok(response);
    }

    // Delete Trading Company

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete Trading Company")
    public ResponseEntity<TradingCompanyResponse> deleteTradingCompany(
            @PathVariable Long id) {

        TradingCompany company = tradingCompanyService.deleteTradingCompany(id);

        TradingCompanyResponse response = new TradingCompanyResponse();

        response.setTradingCompany(company);
        response.setHttpStatusCode(200);
        response.setMessage("Trading Company Deleted Successfully");

        return ResponseEntity.ok(response);
    }
    
    
    
 
}