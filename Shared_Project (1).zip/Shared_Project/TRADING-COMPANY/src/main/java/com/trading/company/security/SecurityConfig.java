//package com.trading.company.security;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//public class SecurityConfig {
//
//    @Bean
//    public UserDetailsService userDetailsService() {
//
//        UserDetails admin = User.builder()
//                .username("admin")
//                .password(passwordEncoder().encode("admin123"))
//                .roles("ADMIN")
//                .build();
//
//        UserDetails user = User.builder()
//                .username("user")
//                .password(passwordEncoder().encode("user123"))
//                .roles("USER")
//                .build();
//
//        return new InMemoryUserDetailsManager(admin, user);
//    }
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//
//        return new BCryptPasswordEncoder();
//    }
//
//    @Bean
//    public SecurityFilterChain securityFilterChain(
//            HttpSecurity http) throws Exception {
//
//        http
//            .csrf(csrf -> csrf.disable())
//            .authorizeHttpRequests(auth -> auth
//                    // Swagger Access
//                    .requestMatchers(
//                            "/swagger-ui/**",
//                            "/swagger-ui.html",
//                            "/v3/api-docs/**")
//                    .permitAll()
//
//                    // GET APIs
//                    .requestMatchers(HttpMethod.GET,
//                            "/companies/**")
//                    .hasAnyRole("ADMIN", "USER")
//
//                    // POST APIs
//                    .requestMatchers(HttpMethod.POST,
//                            "/companies/**")
//                    .hasRole("ADMIN")
//
//                    // PUT APIs
//                    .requestMatchers(HttpMethod.PUT,
//                            "/companies/**")
//                    .hasRole("ADMIN")
//
//                    // DELETE APIs
//                    .requestMatchers(HttpMethod.DELETE,
//                            "/companies/**")
//                    .hasRole("ADMIN")
//
//                    .anyRequest()
//                    .authenticated())
//
//            .httpBasic(Customizer.withDefaults());
//
//        return http.build();
//    }
//}