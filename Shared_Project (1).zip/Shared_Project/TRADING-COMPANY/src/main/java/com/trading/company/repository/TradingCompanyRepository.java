package com.trading.company.repository;

import java.util.Optional;

import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trading.company.entity.TradingCompany;

@Repository
public interface TradingCompanyRepository extends JpaRepository<TradingCompany, Long>{

    Optional<TradingCompany> findByLicenseNumber(String licenseNumber);
    
    Optional<TradingCompany> findByContactEmail(String contactEmail);
    
    boolean existsByLicenseNumber(String licenseNumber);
    
    boolean existsByContactEmail(String contactEmail);
}
