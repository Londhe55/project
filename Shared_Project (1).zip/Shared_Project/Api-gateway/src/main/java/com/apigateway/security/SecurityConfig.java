package com.apigateway.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;

import jakarta.annotation.PostConstruct;

@Configuration
public class SecurityConfig {
	
	@PostConstruct
	public void init() {
	    System.out.println("========== SECURITY LOADED ==========");
	}

    @Bean
    public MapReactiveUserDetailsService userDetailsService() {

        UserDetails admin = User.builder()
                .username("admin")
                .password(passwordEncoder().encode("admin123"))
                .roles("ADMIN")
                .build();

        UserDetails user = User.builder()
                .username("user")
                .password(passwordEncoder().encode("user123"))
                .roles("USER")
                .build();

        return new MapReactiveUserDetailsService(admin, user);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityWebFilterChain securityFilterChain(
            ServerHttpSecurity http) {

        return http
                .csrf(csrf -> csrf.disable())

                .authorizeExchange(exchange -> exchange

                        .pathMatchers(
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/v3/api-docs/**",
                                "/v3/api-docs",
                                "/swagger-resources/**",
                                "/webjars/**",
                                "/tradeordersapi/v3/api-docs",
                                "/api/traders/v3/api-docs",
                                "/companies/v3/api-docs",
                                "/assets/v3/api-docs",
                                "/settlements/v3/api-docs"
                        ).permitAll()

                        .pathMatchers(HttpMethod.GET,
                                "/companies",
                                "/companies/**",
                                "/tradeordersapi/**",
                                "/api/traders/**",
                                "/assets/**",
                                "/settlements/**")
                        .hasAnyRole("ADMIN", "USER")

                        .pathMatchers(HttpMethod.POST,
                        		"/companies",
                                "/companies/**",
                                "/tradeordersapi/**",
                                "/api/traders/**",
                                "/assets/**",
                                "/settlements/**")
                        .hasRole("ADMIN")

                        .pathMatchers(HttpMethod.PUT,
                        		"/companies",
                                "/companies/**",
                                "/tradeordersapi/**",
                                "/api/traders/**",
                                "/assets/**",
                                "/settlements/**")
                        .hasRole("ADMIN")

                        .pathMatchers(HttpMethod.DELETE,
                        		"/companies",
                                "/companies/**",
                                "/tradeordersapi/**",
                                "/api/traders/**",
                                "/assets/**",
                                "/settlements/**")
                        .hasRole("ADMIN")

                        .anyExchange()
                        .authenticated()
                )

                .httpBasic(Customizer.withDefaults())
                .build();
    }
}