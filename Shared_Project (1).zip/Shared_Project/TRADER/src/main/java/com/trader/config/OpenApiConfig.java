package com.trader.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI tradingCompanyOpenAPI() {
    	
    	String securitySchemeName = "basicAuth";

        return new OpenAPI()
                .info(new Info()
                        .title("Trader  Service API")
                        .description("Microservice for managing traders")
                        .version("1.0")
                        .contact(new Contact()
                                .name("Trader Team")
                                .email("support@trading.com")))
                
                .servers(List.of(
                        new Server()
                                .url("/")
                                .description("Gateway URL")
                ))
                .addSecurityItem(
                        new SecurityRequirement()
                                .addList(securitySchemeName))
                .schemaRequirement(
                        securitySchemeName,
                        new SecurityScheme()
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("basic"));
    }
}
