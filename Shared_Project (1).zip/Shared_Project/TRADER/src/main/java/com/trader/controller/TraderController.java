package com.trader.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.trader.dto.TraderRequest;
import com.trader.dto.TraderResponse;
import com.trader.dto.TraderUpdateRequest;
import com.trader.service.TraderService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/traders")
@Validated
public class TraderController {

    @Autowired
    private TraderService traderService;

    
    
    
    @Operation(summary = "Create a Trader Account ")
    @PostMapping
    public ResponseEntity<TraderResponse> createTrader(
            @Valid @RequestBody TraderRequest traderRequest) {

        TraderResponse response = traderService.createTrader(traderRequest);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    
    

    @Operation(summary = "get the Trdaer By  Id")
    @GetMapping("/{id}")
    public ResponseEntity<TraderResponse> getTraderById(
            @PathVariable Long id) {

        TraderResponse response = traderService.getTraderById(id);

        return ResponseEntity.ok(response);
    }
    
    
    
    
    

    @Operation(summary = "Get All the Trdaers Data")
    @GetMapping
    public ResponseEntity<List<TraderResponse>> getAllTraders() {

        List<TraderResponse> response = traderService.getAllTraders();

        return ResponseEntity.ok(response);
    }

    
    
    
    
    @Operation(summary = "Upadte the Trdaer by Id ")
    @PutMapping("/{id}")
    public ResponseEntity<TraderResponse> updateTrader(
            @PathVariable Long id,
            @Valid @RequestBody TraderUpdateRequest request) {

        TraderResponse response = traderService.updateTrader(id, request);

        return ResponseEntity.ok(response);
    }

    
    
    
    @Operation(summary = "Delete the Trader by ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTrader(
            @PathVariable Long id) {

        String response = traderService.deleteTrader(id);

        return ResponseEntity.ok(response);
    }
    
    
}