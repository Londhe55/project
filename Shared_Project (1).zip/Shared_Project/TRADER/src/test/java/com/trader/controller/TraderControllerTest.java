package com.trader.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.trader.dto.TraderResponse;
import com.trader.service.TraderService;

@WebMvcTest(TraderController.class)
public class TraderControllerTest {
	
	
	@Autowired
	MockMvc mockMvc;
	
	@MockitoBean
	private TraderService serviceImpl;
	
	
	
// Test case for Create the Trader
	@Test
	void testCreateTrader() throws Exception {
		
		TraderResponse response = new TraderResponse();
		
		when(serviceImpl.createTrader(any())).thenReturn(response);

		String json = """ 
				{
				"tradingCompanyId": 101,
				"firstName": "Jordan",
				"lastName": "Lee",
				"email": "jordan.lee@globaltrade.com",
				"phone": "+65 91234567"
				}
				""";
		
		mockMvc.perform(post("/api/traders")
					.contentType(MediaType.APPLICATION_JSON)
					.content(json))
					.andExpect(status().isCreated());
		
		verify(serviceImpl).createTrader(any());     // Checks : actually called on the service?
				
	}
	
	
	// Test Case For Get Trader By Id
	@Test
	void testGetTraderById() throws Exception {
		
		TraderResponse response = new TraderResponse();
		when(serviceImpl.getTraderById(1L)).thenReturn(response);
		
		mockMvc.perform(get("/api/traders/1")).andDo(print()).andExpect(status().isOk());
		
		verify(serviceImpl).getTraderById(1L);
		
	}
	
	
	
	// Test Case for get All Traders Data
	@Test
	void testgetAllTraders() throws Exception {
		List<TraderResponse> response = new ArrayList<>();
		
		when(serviceImpl.getAllTraders()).thenReturn(response);
		
		mockMvc.perform(get("/api/traders")).andExpect(status().isOk());
		
		verify(serviceImpl).getAllTraders();
	}
		

	
	
	// test Case for put Trade Order
	
	@Test
	void testUpdateTradeOrder() throws Exception {
		
		TraderResponse response = new TraderResponse();
		
		when(serviceImpl.updateTrader(eq(1L), any())).thenReturn(response);
		
		String json = """
				{
					"tradingCompanyId": 101,
					"firstName": "Jordan",
					"lastName": "Lee",
					"email": "jordan.lee@globaltrade.com",
					"phone": "+65 91234567"
				}
				""";
		
		mockMvc.perform(put("/api/traders/1")
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk());
		
		
		verify(serviceImpl).updateTrader(eq(1l), any());
	}
	
	
	//Test Case for Delete the Trader Order
	
	@Test
	void testDeleteTraderOrderBYId() throws Exception {

	    when(serviceImpl.deleteTrader(1L))
	            .thenReturn("Trader deleted successfully");

	    mockMvc.perform(delete("/api/traders/1"))
	            .andExpect(status().isOk());

	    verify(serviceImpl).deleteTrader(1L);
	}
	
	

}
