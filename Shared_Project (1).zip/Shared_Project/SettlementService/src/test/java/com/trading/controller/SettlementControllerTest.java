package com.trading.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trading.model.Settlement;
import com.trading.service.SettlementService;

@WebMvcTest(SettlementController.class)
public class SettlementControllerTest {

    @MockitoBean
    private SettlementService service;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void createSettlementTest() throws Exception {

        Settlement settlement = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("15000.75"),
                "COMPLETED",
                "PAY1001");

        when(service.createSettlement(any(Settlement.class)))
                .thenReturn(settlement);

        mockMvc.perform(post("/settlements/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(settlement)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.settlement.id", is(1)))
                .andExpect(jsonPath("$.message",
                        is("Settlement created successfully")));
    }

    @Test
    public void getAllSettlementsTest() throws Exception {

        Settlement s1 = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("1000"),
                "COMPLETED",
                "PAY001");

        Settlement s2 = new Settlement(
                2L,
                1002L,
                LocalDateTime.now(),
                new BigDecimal("2000"),
                "PENDING",
                "PAY002");

        when(service.getAllSettlements())
                .thenReturn(List.of(s1, s2));

        mockMvc.perform(get("/settlements/findall"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode", is(200)))
                .andExpect(jsonPath("$.settlements.length()", is(2)));
    }

    @Test
    public void getSettlementByIdTest() throws Exception {

        Settlement settlement = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("15000.75"),
                "COMPLETED",
                "PAY1001");

        when(service.getSettlementById(1L))
                .thenReturn(settlement);

        mockMvc.perform(get("/settlements/fetch/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.settlement.id", is(1)))
                .andExpect(jsonPath("$.settlement.tradeOrderId", is(1001)))
                .andExpect(jsonPath("$.settlement.status",
                        is("COMPLETED")))
                .andExpect(jsonPath("$.settlement.paymentReference",
                        is("PAY1001")));
    }

    @Test
    public void updateSettlementTest() throws Exception {

        Settlement settlement = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("25000.00"),
                "SETTLED",
                "PAY999");

        when(service.updateSettlement(any(Long.class),
                any(Settlement.class)))
                .thenReturn(settlement);

        mockMvc.perform(put("/settlements/update/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(settlement)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.settlement.id", is(1)))
                .andExpect(jsonPath("$.message",
                        is("Settlement updated successfully")));
    }

    @Test
    public void deleteSettlementTest() throws Exception {

        when(service.deleteSettlement(1L))
                .thenReturn("Settlement deleted successfully");

        mockMvc.perform(delete("/settlements/delete/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.httpStatusCode", is(200)))
                .andExpect(jsonPath("$.message",
                        is("Settlement deleted successfully")));
    }
}