package com.trading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SettlementService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
