package com.trading.repo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.trading.model.Settlement;

@ExtendWith(MockitoExtension.class)
class SettlementRepositoryTest {

    @Mock
    private SettlementRepository repo;

    @Test
    void saveSettlementTest() {

        LocalDateTime settlementDate = LocalDateTime.now();

        Settlement settlement = new Settlement(
                1L,
                1001L,
                settlementDate,
                new BigDecimal("15000.50"),
                "COMPLETED",
                "PAY1001");

        given(repo.save(settlement)).willReturn(settlement);

        Settlement savedSettlement = repo.save(settlement);

        assertThat(savedSettlement).isNotNull();
        assertThat(savedSettlement.getId()).isEqualTo(1L);
        assertThat(savedSettlement.getTradeOrderId()).isEqualTo(1001L);
        assertThat(savedSettlement.getSettlementDate()).isEqualTo(settlementDate);
        assertThat(savedSettlement.getAmount())
                .isEqualByComparingTo(new BigDecimal("15000.50"));
        assertThat(savedSettlement.getStatus()).isEqualTo("COMPLETED");
        assertThat(savedSettlement.getPaymentReference()).isEqualTo("PAY1001");
    }

    @Test
    void findSettlementByIdTest() {

        LocalDateTime settlementDate = LocalDateTime.now();

        Settlement settlement = new Settlement(
                1L,
                1001L,
                settlementDate,
                new BigDecimal("15000.50"),
                "COMPLETED",
                "PAY1001");

        given(repo.findById(1L))
                .willReturn(Optional.of(settlement));

        Settlement result = repo.findById(1L).orElse(null);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getTradeOrderId()).isEqualTo(1001L);
        assertThat(result.getStatus()).isEqualTo("COMPLETED");
        assertThat(result.getPaymentReference()).isEqualTo("PAY1001");
    }

    @Test
    void findAllSettlementsTest() {

        Settlement s1 = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("1000"),
                "COMPLETED",
                "PAY001");

        Settlement s2 = new Settlement(
                2L,
                1002L,
                LocalDateTime.now(),
                new BigDecimal("2000"),
                "PENDING",
                "PAY002");

        List<Settlement> settlements = Arrays.asList(s1, s2);

        given(repo.findAll()).willReturn(settlements);

        List<Settlement> result = repo.findAll();

        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
    }

    @Test
    void updateSettlementTest() {

        Settlement settlement = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("15000.50"),
                "PENDING",
                "PAY1001");

        given(repo.save(settlement)).willReturn(settlement);

        Settlement savedSettlement = repo.save(settlement);

        savedSettlement.setStatus("COMPLETED");

        given(repo.save(savedSettlement))
                .willReturn(savedSettlement);

        Settlement updatedSettlement = repo.save(savedSettlement);

        assertThat(updatedSettlement.getStatus())
                .isEqualTo("COMPLETED");
    }

    @Test
    void deleteSettlementTest() {

        Settlement settlement = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("15000.50"),
                "COMPLETED",
                "PAY1001");

        given(repo.findById(1L))
                .willReturn(Optional.empty());

        Optional<Settlement> result = repo.findById(1L);

        assertThat(result).isEmpty();
    }

    @Test
    void existsByIdTest() {

        given(repo.existsById(1L))
                .willReturn(true);

        boolean exists = repo.existsById(1L);

        assertThat(exists).isTrue();
    }

    @Test
    void countSettlementsTest() {

        given(repo.count()).willReturn(1L);

        long count = repo.count();

        assertThat(count).isEqualTo(1L);
    }
}