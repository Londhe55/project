package com.trading.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.trading.model.Settlement;
import com.trading.repo.SettlementRepository;

@ExtendWith(MockitoExtension.class)
public class SettlementServiceImplTest {

    @Mock
    private SettlementRepository repo;

    @InjectMocks
    private SettlementServiceImpl service;

    @Test
    public void createSettlementTest() {
    	
    	LocalDateTime settlementDate = LocalDateTime.now();
        Settlement settlement = new Settlement(
                1L,
                1001L,
                settlementDate,
                new BigDecimal("15000.50"),
                "COMPLETED",
                "PAY1001");

        given(repo.save(settlement)).willReturn(settlement);

        Settlement savedSettlement =
                service.createSettlement(settlement);

        assertThat(savedSettlement).isNotNull();
        assertThat(savedSettlement.getId()).isEqualTo(1L);
        assertThat(savedSettlement.getTradeOrderId()).isEqualTo(1001L); 
        assertThat(savedSettlement.getSettlementDate()).isEqualTo(settlementDate);
        assertThat(savedSettlement.getAmount()).isEqualTo("15000.50");
        assertThat(savedSettlement.getStatus()).isEqualTo("COMPLETED");
        assertThat(savedSettlement.getPaymentReference()).isEqualTo("PAY1001");
        
    }

    @Test
    public void getAllSettlementsTest() {

        Settlement s1 = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("1000"),
                "COMPLETED",
                "PAY001");

        Settlement s2 = new Settlement(
                2L,
                1002L,
                LocalDateTime.now(),
                new BigDecimal("2000"),
                "PENDING",
                "PAY002");

        given(repo.findAll()).willReturn(List.of(s1, s2));

        List<Settlement> settlements =
                service.getAllSettlements();

        assertThat(settlements).isNotNull();
        assertThat(settlements.size()).isEqualTo(2);
    }

    @Test
    public void getSettlementByIdTest() {
    	
    	LocalDateTime settlementDate = LocalDateTime.now();
        Settlement settlement = new Settlement(
                1L,
                1001L,
                settlementDate,
                new BigDecimal("1000"),
                "COMPLETED",
                "PAY001");

        given(repo.findById(1L))
                .willReturn(Optional.of(settlement));

        Settlement result =
                service.getSettlementById(1L);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getTradeOrderId()).isEqualTo(1001L); 
        assertThat(result.getSettlementDate()).isEqualTo(settlementDate);
        assertThat(result.getAmount()).isEqualTo("1000");
        assertThat(result.getStatus()).isEqualTo("COMPLETED");
        assertThat(result.getPaymentReference()).isEqualTo("PAY001");
        
    }

    @Test
    public void updateSettlementTest() {

        Settlement existingSettlement = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("1000"),
                "PENDING",
                "PAY001");

        Settlement updatedSettlement = new Settlement(
                1L,
                1002L,
                LocalDateTime.now(),
                new BigDecimal("5000"),
                "COMPLETED",
                "PAY999");

        given(repo.findById(1L))
                .willReturn(Optional.of(existingSettlement));

        given(repo.save(existingSettlement))
                .willReturn(existingSettlement);

        Settlement result =
                service.updateSettlement(1L, updatedSettlement);

        assertThat(result).isNotNull();
    }

    @Test
    public void deleteSettlementTest() {

        Settlement settlement = new Settlement(
                1L,
                1001L,
                LocalDateTime.now(),
                new BigDecimal("1000"),
                "COMPLETED",
                "PAY001");

        given(repo.findById(1L))
                .willReturn(Optional.of(settlement));

        doNothing().when(repo).delete(settlement);

        String result =
                service.deleteSettlement(1L);

        verify(repo).delete(settlement);

        assertThat(result).isNotNull();
    }
}