package com.trading.advice;
 
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.trading.dto.ErrorResponse;
import com.trading.exception.SettlementListEmptyException;
import com.trading.exception.SettlementNotFoundException;

 
@RestControllerAdvice
public class GlobalExceptionHandler {
 
    @ExceptionHandler(SettlementNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleException(
    		SettlementNotFoundException ex) {
 
        ErrorResponse error = new ErrorResponse();
        error.setMessage(ex.getMessage());
        error.setStatus(404);
 
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(SettlementListEmptyException.class)
    public ResponseEntity<ErrorResponse> handleException1(
    		SettlementListEmptyException ex) {
 
        ErrorResponse error = new ErrorResponse();
        error.setMessage(ex.getMessage());
        error.setStatus(404);
 
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
 
}
