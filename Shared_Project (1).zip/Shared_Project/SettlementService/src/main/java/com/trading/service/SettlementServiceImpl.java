package com.trading.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trading.exception.SettlementNotFoundException;
import com.trading.model.Settlement;
import com.trading.repo.SettlementRepository;

@Service
public class SettlementServiceImpl implements SettlementService {

    @Autowired
    private SettlementRepository settlementRepository;

    @Override
    public Settlement createSettlement(Settlement settlement) {
    	
        return settlementRepository.save(settlement);
    }

    @Override
    public Settlement getSettlementById(Long id) {
        return settlementRepository.findById(id)
                .orElseThrow(() ->
                        new SettlementNotFoundException("Settlement not found with id: " + id));
    }

    @Override
    public List<Settlement> getAllSettlements() {
        return settlementRepository.findAll();
    }

    @Override
    public Settlement updateSettlement(Long id, Settlement settlementRequest) {

        Settlement settlement = settlementRepository.findById(id)
                .orElseThrow(() ->
                        new SettlementNotFoundException("Settlement not found with id: " + id));

		settlement.setTradeOrderId(settlementRequest.getTradeOrderId());
		settlement.setSettlementDate(settlementRequest.getSettlementDate());
		settlement.setAmount(settlementRequest.getAmount());
		settlement.setStatus(settlementRequest.getStatus());
		settlement.setPaymentReference(settlementRequest.getPaymentReference());

        return settlementRepository.save(settlement);
    }

    @Override
    public String deleteSettlement(Long id) {

        Settlement settlement = settlementRepository.findById(id)
                .orElseThrow(() ->
                        new SettlementNotFoundException("Settlement not found with id: " + id));

        settlementRepository.delete(settlement);
        return "Settlement deleted Successfully";
    }
}