package com.trading.service;

import java.util.List;

import com.trading.model.Settlement;

public interface SettlementService {

		Settlement createSettlement(Settlement settlement);
		
		List<Settlement> getAllSettlements();
		
		Settlement getSettlementById(Long id);
		
		Settlement updateSettlement(Long id, Settlement settlement);
		
		String deleteSettlement(Long id);

}