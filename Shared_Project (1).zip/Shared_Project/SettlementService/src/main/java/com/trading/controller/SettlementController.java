package com.trading.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trading.client.TradeOrderClient;
import com.trading.dto.SettlementListResponseDTO;
import com.trading.dto.SettlementRequestDTO;
import com.trading.dto.SettlementResponseDTO;
import com.trading.dto.TradeOrderDTO;
import com.trading.exception.SettlementListEmptyException;
import com.trading.exception.TradeOrderNotFoundException;
import com.trading.model.Settlement;
import com.trading.service.SettlementService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/settlements")
@Validated
@Tag(name = "Settlement API", description = "Operations related to Settlements")
public class SettlementController {

	@Autowired
	private SettlementService settlementService;
	
	@Autowired
	private TradeOrderClient tradeOrderClient;

	// CREATE	
	@PostMapping("/save")
	@Operation(summary = "Create a Settlement")
	public ResponseEntity<SettlementResponseDTO> createSettlement(@Valid @RequestBody SettlementRequestDTO dto) {
		try {
		    TradeOrderDTO tradeOrder =
		            tradeOrderClient.getTradeOrderById(
		                    dto.getSettlement().getTradeOrderId());

		    System.out.println("Trade Order Found: " + tradeOrder);
		}
		catch(Exception e) {
		    e.printStackTrace(); // IMPORTANT
		    throw new TradeOrderNotFoundException();
		}
		
		Settlement savedSettlement = settlementService.createSettlement(dto.getSettlement());

		SettlementResponseDTO responseDTO = new SettlementResponseDTO();

		responseDTO.setSettlement(savedSettlement);
		responseDTO.setHttpStatusCode(201);
		responseDTO.setMessage("Settlement created successfully");

		return ResponseEntity.ok(responseDTO);
	}

	// GET ALL
	@GetMapping("/findall")
	@Operation(summary = "Fetch all Settlements")
	public ResponseEntity<SettlementListResponseDTO> getAllSettlements() throws SettlementListEmptyException {

		List<Settlement> settlements = settlementService.getAllSettlements();

		SettlementListResponseDTO dto = new SettlementListResponseDTO();
		if (settlements.size() > 0) {

			dto.setSettlements(settlements);
			dto.setHttpStatusCode(200);
			dto.setMessage(settlements.size() + " Settlements fetched successfully");
		}else {
			throw new SettlementListEmptyException("No Settlements Found");
		}
			

		return ResponseEntity.ok(dto);
	}

	// GET BY ID
	@GetMapping("/fetch/{id}")
	@Operation(summary = "Fetch Settlement by ID")
	public ResponseEntity<SettlementResponseDTO> getSettlementById(@PathVariable Long id) {

		Settlement settlement = settlementService.getSettlementById(id);

		SettlementResponseDTO responseDTO = new SettlementResponseDTO();

		responseDTO.setSettlement(settlement);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage("Settlement found");

		return ResponseEntity.ok(responseDTO);
	}

	// UPDATE
	@PutMapping("/update/{id}")
	@Operation(summary = "Update Settlement")
	public ResponseEntity<SettlementResponseDTO> updateSettlement(@PathVariable Long id,
			@Valid @RequestBody SettlementRequestDTO dto) {

		Settlement updatedSettlement = settlementService.updateSettlement(id, dto.getSettlement());

		SettlementResponseDTO responseDTO = new SettlementResponseDTO();

		responseDTO.setSettlement(updatedSettlement);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage("Settlement updated successfully");

		return ResponseEntity.ok(responseDTO);
	}

	// DELETE
	@DeleteMapping("/delete/{id}")
	@Operation(summary = "Delete Settlement")
	public ResponseEntity<SettlementResponseDTO> deleteSettlement(@PathVariable Long id) {

		String message = settlementService.deleteSettlement(id);

		SettlementResponseDTO responseDTO = new SettlementResponseDTO();

		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage(message);

		return ResponseEntity.ok(responseDTO);
	}
}