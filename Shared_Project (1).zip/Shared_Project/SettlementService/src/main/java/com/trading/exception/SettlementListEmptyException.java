package com.trading.exception;

public class SettlementListEmptyException extends Exception{
 
	public SettlementListEmptyException() {
		super();
		// TODO Auto-generated constructor stub
	}
 
	public SettlementListEmptyException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
 
	public SettlementListEmptyException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
 
	public SettlementListEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
 
	public SettlementListEmptyException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
 
	
	
}