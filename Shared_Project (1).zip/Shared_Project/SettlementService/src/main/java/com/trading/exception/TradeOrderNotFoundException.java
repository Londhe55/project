package com.trading.exception;

public class TradeOrderNotFoundException extends RuntimeException {

	public TradeOrderNotFoundException()
	{
		super("Trade Order Not Found");
	}
}
