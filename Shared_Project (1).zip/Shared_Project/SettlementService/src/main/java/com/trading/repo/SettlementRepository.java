package com.trading.repo;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trading.model.Settlement;

@Repository
public interface SettlementRepository extends JpaRepository<Settlement, Long> {

}

