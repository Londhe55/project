package com.trading.exception;

public class SettlementNotFoundException extends RuntimeException {

    

	public SettlementNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SettlementNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SettlementNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SettlementNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SettlementNotFoundException(String message) {
        super(message);
    }
}
