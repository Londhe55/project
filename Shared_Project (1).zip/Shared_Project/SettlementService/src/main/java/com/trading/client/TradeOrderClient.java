package com.trading.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.trading.dto.TradeOrderDTO;

@FeignClient(name = "TradeOrdersService")
public interface TradeOrderClient {

    @GetMapping("/tradeordersapi/tradeorder/{id}")
    TradeOrderDTO getTradeOrderById(
            @PathVariable Long id);
}