package com.trading.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "settlements")
public class Settlement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Trade Order Id is required")
    @Column(name = "trade_order_id")
    private Long tradeOrderId;

    @NotNull(message = "Settlement Date is required")
    @Column(name = "settlement_date")
    private LocalDateTime settlementDate;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    private BigDecimal amount;

    @NotBlank(message = "Status is required")
    private String status;

    @NotBlank(message = "Payment Reference is required")
    @Column(name = "payment_reference")
    private String paymentReference;

	

	public Settlement(Long id, @NotNull(message = "Trade Order Id is required") Long tradeOrderId,
			@NotNull(message = "Settlement Date is required") LocalDateTime settlementDate,
			@NotNull(message = "Amount is required") @DecimalMin(value = "0.01", message = "Amount must be greater than zero") BigDecimal amount,
			@NotBlank(message = "Status is required") String status,
			@NotBlank(message = "Payment Reference is required") String paymentReference) {
		super();
		this.id = id;
		this.tradeOrderId = tradeOrderId;
		this.settlementDate = settlementDate;
		this.amount = amount;
		this.status = status;
		this.paymentReference = paymentReference;
	}

	public Settlement() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTradeOrderId() {
		return tradeOrderId;
	}

	public void setTradeOrderId(Long tradeOrderId) {
		this.tradeOrderId = tradeOrderId;
	}

	public LocalDateTime getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(LocalDateTime settlementDate) {
		this.settlementDate = settlementDate;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPaymentReference() {
		return paymentReference;
	}

	public void setPaymentReference(String paymentReference) {
		this.paymentReference = paymentReference;
	}

    
}