package com.asset.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.asset.dto.AssetResponse;
import com.asset.dto.CreateAssetRequest;
import com.asset.service.AssetService;
import com.asset.service.AssetService;

@WebMvcTest(AssetController.class)
public class AssetControllerTest {
	
	
	@Autowired
	MockMvc mockMvc;
	
	
	
	@MockitoBean
	private AssetService assetServiceImpl;
	
	
	@Autowired
	private ObjectMapper objectMapper;
	
	
	
	
	
	
	
	@Test
	void addAsset() throws Exception {

	    AssetResponse assetResponse = new AssetResponse();

	    when(assetServiceImpl.createAsset(any()))
	            .thenReturn(assetResponse);

	    CreateAssetRequest request = new CreateAssetRequest();

	    request.setName("ABC Corporation");
	    request.setSymbol("ABC");
	    request.setType("STOCK");
	    request.setCurrentPrice(BigDecimal.valueOf(250.75));
	    request.setListedSince(LocalDate.parse("2020-01-15"));

	    mockMvc.perform(post("/assets")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content(objectMapper.writeValueAsString(request)))
	            .andExpect(status().isCreated());

	    verify(assetServiceImpl).createAsset(any());
	}
	
	
	
	
	
	
	
//	// Test Case For the Create Asset
//		@Test
//		void addAsset() throws Exception {
//
//			AssetResponse assetResponse = new AssetResponse();
//			when(assetServiceImpl.createAsset(any())).thenReturn(assetResponse);
//			
//			String json = """ 
//					{
//					"name": "ABC Corporation",
//					"symbol": "ABC",
//					"type": "STOCK",
//					"currentPrice": 250.75,
//					"listedSince": "2020-01-15"
//
//					}
//					""";
//
//			mockMvc.perform(post("/assets")
//					.contentType(MediaType.APPLICATION_JSON)
//					.content(json))
//					.andExpect(status().isCreated());
//			
//			verify(assetServiceImpl).createAsset(any());
//		}
//		
		
		
		
	// Test Case For the Get Asset By id 
	@Test
	void getAssetByID() throws Exception {
		
		
		AssetResponse assetResponse = new AssetResponse();
		
		when(assetServiceImpl.getAssetById(1L)).thenReturn(assetResponse);
		
		mockMvc.perform(get("/assets/1"))
				.andExpect(status().isOk());
		
		verify(assetServiceImpl).getAssetById(1L);
	}
	
	
	
	// Test Case for Get All Asset 
	@Test
	void getAssetAll() throws Exception {
		
		List<AssetResponse> assetResponse = new ArrayList<AssetResponse>();
		when(assetServiceImpl.getAllAssets()).thenReturn(assetResponse);
		
		mockMvc.perform(get("/assets"))
				.andExpect(status().isOk());
		
		verify(assetServiceImpl).getAllAssets();
	}
	
	
	
	
	
	
	
	
	// Test Case for Update the Asset By Id
	@Test
	void updateAssetById() throws Exception {
		
		AssetResponse assetResponse = new AssetResponse();
		
		when(assetServiceImpl.updateAsset(eq(1L), any())).thenReturn(assetResponse);
		
		String json = """ 
				{
				"name": "ABC Corporation",
				"symbol": "ABC",
				"type": "STOCK",
				"currentPrice": 250.75,
				"listedSince": "2020-01-15"

				}
				""";
		mockMvc.perform(put("/assets/1")
					.contentType(MediaType.APPLICATION_JSON)
					.content(json))
					.andExpect(status().isOk());
		
		verify(assetServiceImpl).updateAsset(eq(1L), any());
	}
	
	
	
	//Test Case for Delete the Asset By Id 
	
	@Test
	void testDeleteByID() throws Exception {
		
		AssetResponse assetResponse = new AssetResponse();
		
		doNothing().when(assetServiceImpl)
        .deleteAsset(1L);
		
		mockMvc.perform(delete("/assets/1"))
				.andExpect(status().isOk())
				.andExpect(content().string("Asset deleted successfully"));
		
		verify(assetServiceImpl).deleteAsset(1L);
		
	}
	
	

}
