package com.asset.service;

import com.asset.dto.AssetResponse;
import com.asset.dto.CreateAssetRequest;
import com.asset.dto.UpdateAssetRequest;
import com.asset.entity.Asset;
import com.asset.exception.DuplicateResourceException;
import com.asset.exception.ResourceNotFoundException;
import com.asset.mapper.AssetMapper;
import com.asset.repository.AssetRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AssetService {

	private final AssetRepository assetRepository;
	private final AssetMapper assetMapper;

	public AssetService(AssetRepository assetRepository, AssetMapper assetMapper) {

		this.assetRepository = assetRepository;
		this.assetMapper = assetMapper;
	}

	public AssetResponse createAsset(CreateAssetRequest request) {

		if (assetRepository.existsBySymbol(request.getSymbol())) {

			throw new DuplicateResourceException("Asset symbol already exists");
		}

		Asset asset = assetMapper.toEntity(request);

		Asset savedAsset = assetRepository.save(asset);

		return assetMapper.toResponse(savedAsset);
	}

	public AssetResponse getAssetById(Long id) {

		Asset asset = assetRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Asset not found with id: " + id));

		return assetMapper.toResponse(asset);
	}

	public List<AssetResponse> getAllAssets() {

		return assetRepository.findAll().stream().map(assetMapper::toResponse).collect(Collectors.toList());
	}

	public AssetResponse updateAsset(Long id, UpdateAssetRequest request) {

		Asset asset = assetRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Asset not found with id: " + id));

		assetMapper.updateEntity(asset, request);

		Asset updatedAsset = assetRepository.save(asset);

		return assetMapper.toResponse(updatedAsset);
	}

	public void deleteAsset(Long id) {

		Asset asset = assetRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Asset not found with id: " + id));

		assetRepository.delete(asset);
	}
}