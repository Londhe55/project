package com.asset.controller;

import com.asset.dto.AssetResponse;
import com.asset.dto.CreateAssetRequest;
import com.asset.dto.UpdateAssetRequest;
import com.asset.service.AssetService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/assets")
public class AssetController {

    private final AssetService assetService;

    public AssetController(AssetService assetService) {
        this.assetService = assetService;
    }

   
    @Operation(summary = "Create the Asset")
    @PostMapping
    public ResponseEntity<AssetResponse> createAsset(
            @Valid @RequestBody CreateAssetRequest request) {

        AssetResponse response = assetService.createAsset(request);

        return new ResponseEntity<>(
                response,
                HttpStatus.CREATED);
    }

   
    @Operation(summary = "Get Asset By Id")
    @GetMapping("/{id}")
    public ResponseEntity<AssetResponse> getAssetById(
            @PathVariable Long id) {

        AssetResponse response = assetService.getAssetById(id);

        return ResponseEntity.ok(response);
    }

   
    @Operation(summary = "Get All Asset")
    @GetMapping
    public ResponseEntity<List<AssetResponse>> getAllAssets() {

        List<AssetResponse> assets = assetService.getAllAssets();

        return ResponseEntity.ok(assets);
    }

   
    @Operation(summary = "Update the Asset By id")
    @PutMapping("/{id}")
    public ResponseEntity<AssetResponse> updateAsset(
            @PathVariable Long id,
            @Valid @RequestBody UpdateAssetRequest request) {

        AssetResponse response = assetService.updateAsset(id, request);

        return ResponseEntity.ok(response);
    }

   
    @Operation(summary = "Delete Asset By Id ")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAsset(
            @PathVariable Long id) {

        assetService.deleteAsset(id);

        return ResponseEntity.ok("Asset deleted successfully");
    }
}