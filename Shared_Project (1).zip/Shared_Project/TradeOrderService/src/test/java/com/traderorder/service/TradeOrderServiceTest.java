package com.traderorder.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tradeorder.client.AssetClient;
import com.tradeorder.client.TraderClient;
import com.tradeorder.db.TradeOrderRepository;
import com.tradeorder.dto.AssetResponseDTO;
import com.tradeorder.dto.TraderResponseDTO;
import com.tradeorder.enums.OrderStatus;
import com.tradeorder.enums.OrderType;
import com.tradeorder.exception.AssetNotFoundException;
import com.tradeorder.exception.TradeOrderListNotFoundException;
import com.tradeorder.exception.TradeOrderNotFoundException;
import com.tradeorder.exception.TraderNotFoundException;
import com.tradeorder.model.TradeOrder;
import com.tradeorder.service.TradeOrderServiceImpl;

@ExtendWith(MockitoExtension.class)
public class TradeOrderServiceTest {

	@Mock
	private TradeOrderRepository repo;

	@Mock
	private TraderClient traderClient;

	@Mock
	private AssetClient assetClient;

	@InjectMocks
	private TradeOrderServiceImpl service;

	@Test
	void testGetTradeOrderById() {
		TradeOrder order = new TradeOrder();

		order.setId(1L);
		order.setTraderId(215L);
		order.setAssetId(3010L);
		order.setOrderType(OrderType.BUY);
		order.setQuantity(new BigDecimal("500"));
		order.setPrice(new BigDecimal("250.75"));
		order.setStatus(OrderStatus.OPEN);
		order.setCreatedAt(LocalDateTime.of(2025, 7, 28, 10, 0));

		when(repo.findById(1L)).thenReturn(Optional.of(order));

		TradeOrder result = service.getTradeOrderById(1L);

		assertNotNull(result);

		assertEquals(Long.valueOf(215), result.getTraderId());

		assertEquals(Long.valueOf(3010), result.getAssetId());

		assertEquals(OrderType.BUY, result.getOrderType());

		assertEquals(BigDecimal.valueOf(500), result.getQuantity());

		assertEquals(BigDecimal.valueOf(250.75), result.getPrice());

		assertEquals(OrderStatus.OPEN, result.getStatus());

	}

	@Test
	void testGetTradeOrderById_NotFound() {

		when(repo.findById(1L)).thenReturn(Optional.empty());

		assertThrows(TradeOrderNotFoundException.class, () -> service.getTradeOrderById(1L));
	}

	@Test
	void testGetTraderOrders() {
		List<TradeOrder> list = Arrays.asList(

				new TradeOrder(1L, 215L, 3010L, OrderType.BUY, new BigDecimal("500"), new BigDecimal("250.75"),
						OrderStatus.OPEN, LocalDateTime.of(2025, 7, 28, 10, 0)),

				new TradeOrder(2L, 216L, 3011L, OrderType.SELL, new BigDecimal("750"), new BigDecimal("315.50"),
						OrderStatus.OPEN, LocalDateTime.of(2025, 8, 15, 14, 30))

		);

		when(repo.findAll()).thenReturn(list);

		List<TradeOrder> result = service.getTradeOrders();

		assertEquals(2, result.size());

		assertEquals(Long.valueOf(215), result.get(0).getTraderId());

		assertEquals(Long.valueOf(216), result.get(1).getTraderId());
	}

	@Test
	void testGetTraderOrders_NotFound() {
		when(repo.findAll()).thenReturn(Collections.emptyList());

		assertThrows(TradeOrderListNotFoundException.class, () -> service.getTradeOrders());

	}

	@Test
	void testAddTradeOrder() {

		TradeOrder tradeOrder = new TradeOrder(1L, 1001L, 101L, OrderType.SELL, new BigDecimal("300"),
				new BigDecimal("5400"), OrderStatus.COMPLETED, LocalDateTime.of(2025, 8, 15, 14, 30));

		when(traderClient.getTraderById(1001L)).thenReturn(new TraderResponseDTO());

		when(assetClient.getById(101L)).thenReturn(new AssetResponseDTO());

		when(repo.save(tradeOrder)).thenReturn(tradeOrder);

		TradeOrder result = service.addTradeOrder(tradeOrder);

		assertNotNull(result);

		assertEquals(Long.valueOf(1001L), result.getTraderId());

		assertEquals(Long.valueOf(1001L), tradeOrder.getTraderId());

		assertEquals(Long.valueOf(101L), tradeOrder.getAssetId());

		assertEquals(OrderType.SELL, tradeOrder.getOrderType());

		assertEquals(BigDecimal.valueOf(300), tradeOrder.getQuantity());

		assertEquals(BigDecimal.valueOf(5400), tradeOrder.getPrice());

		assertEquals(OrderStatus.COMPLETED, tradeOrder.getStatus());

		verify(repo).save(tradeOrder);
	}

	@Test
	void testAddTradeOrder_TraderNotFound() {
		TradeOrder tradeOrder = new TradeOrder(1L, 1001L, 101L, OrderType.SELL, new BigDecimal("300"),
				new BigDecimal("5400"), OrderStatus.COMPLETED, LocalDateTime.of(2025, 8, 15, 14, 30));

		when(traderClient.getTraderById(1001L)).thenThrow(new RuntimeException());

		assertThrows(TraderNotFoundException.class, () -> service.addTradeOrder(tradeOrder));
	}

	@Test
	void testAddTradeOrder_AssetNotFOund() {
		TradeOrder tradeOrder = new TradeOrder(1L, 1001L, 101L, OrderType.SELL, new BigDecimal("300"),
				new BigDecimal("5400"), OrderStatus.COMPLETED, LocalDateTime.of(2025, 8, 15, 14, 30));

		when(assetClient.getById(101L)).thenThrow(new RuntimeException());

		assertThrows(AssetNotFoundException.class, () -> service.addTradeOrder(tradeOrder));
	}

	@Test
	void testUpdateTraderOrder() {
		TradeOrder existingOrder = new TradeOrder(1L, 1001L, 101L, OrderType.BUY, new BigDecimal("100"),
				new BigDecimal("250"), OrderStatus.OPEN, LocalDateTime.now());

		TradeOrder updatedTradeOrder = new TradeOrder(1L, 1001L, 101L, OrderType.SELL, new BigDecimal("300"),
				new BigDecimal("5400"), OrderStatus.COMPLETED, LocalDateTime.of(2025, 8, 15, 14, 30));

		when(repo.findById(1L)).thenReturn(Optional.of(existingOrder));

		when(repo.save(updatedTradeOrder)).thenReturn(updatedTradeOrder);

		TradeOrder result = service.updateTradeOrder(1L, updatedTradeOrder);

		assertNotNull(result);

		assertEquals(OrderType.SELL, updatedTradeOrder.getOrderType());

		assertEquals(BigDecimal.valueOf(300), updatedTradeOrder.getQuantity());

		assertEquals(BigDecimal.valueOf(5400), updatedTradeOrder.getPrice());

		assertEquals(OrderStatus.COMPLETED, updatedTradeOrder.getStatus());

		verify(repo).save(updatedTradeOrder);

	}

	@Test
	void testUpdateTradeOrder_NotFound() {
		TradeOrder order = new TradeOrder(2L, 1001L, 101L, OrderType.BUY, new BigDecimal("100"), new BigDecimal("250"),
				OrderStatus.OPEN, LocalDateTime.now());

		when(repo.findById(1L)).thenReturn(Optional.empty());

		assertThrows(TradeOrderNotFoundException.class, () -> service.updateTradeOrder(1L, order));
	}

	@Test
	void testDeleteTradeOrder() {
		when(repo.existsById(1L)).thenReturn(true);

		String result = service.deleteTradeOrder(1L);

		assertEquals("Trade Order Deleted Successfully", result);

		verify(repo).deleteById(1L);
	}

	@Test
	void testDeleteTradeOrder_NotFound() {
		
		when(repo.existsById(1L)).thenReturn(false);

		assertThrows(TradeOrderNotFoundException.class, ()->service.deleteTradeOrder(1L));

	}

}
