package com.traderorder.repo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tradeorder.db.TradeOrderRepository;
import com.tradeorder.enums.OrderStatus;
import com.tradeorder.enums.OrderType;
import com.tradeorder.model.TradeOrder;

@ExtendWith(MockitoExtension.class)
public class TradeOrdeRepositoryTest {

    @Mock
    private TradeOrderRepository repo;

    @Test
    void testSaveTradeOrder() {
    	
        TradeOrder tradeOrder = new TradeOrder();
        tradeOrder.setId(1L);
        tradeOrder.setTraderId(1L);
        tradeOrder.setAssetId(101L);
        tradeOrder.setOrderType(OrderType.BUY);
        tradeOrder.setQuantity(BigDecimal.valueOf(200));
        tradeOrder.setPrice(BigDecimal.valueOf(1200));
        tradeOrder.setStatus(OrderStatus.OPEN);
        tradeOrder.setCreatedAt(LocalDateTime.of(2025, 7, 28, 10, 0));

        given(repo.save(tradeOrder)).willReturn(tradeOrder);

        TradeOrder savedOrder = repo.save(tradeOrder);

        assertNotNull(savedOrder);
        assertNotNull(savedOrder.getId());

        assertEquals(Long.valueOf(1L), savedOrder.getTraderId());
        assertEquals(Long.valueOf(101L), savedOrder.getAssetId());
        assertEquals(OrderType.BUY, savedOrder.getOrderType());
        assertEquals(BigDecimal.valueOf(200), savedOrder.getQuantity());
        assertEquals(BigDecimal.valueOf(1200), savedOrder.getPrice());
        assertEquals(OrderStatus.OPEN, savedOrder.getStatus());
        assertEquals(LocalDateTime.of(2025, 7, 28, 10, 0), savedOrder.getCreatedAt());
    }

    @Test
    void testFindTraderOrderById() {

        TradeOrder tradeOrder = new TradeOrder();
        tradeOrder.setId(1L);
        tradeOrder.setTraderId(1L);
        tradeOrder.setAssetId(101L);
        tradeOrder.setOrderType(OrderType.BUY);
        tradeOrder.setQuantity(BigDecimal.valueOf(200));
        tradeOrder.setPrice(BigDecimal.valueOf(1200));
        tradeOrder.setStatus(OrderStatus.OPEN);
        tradeOrder.setCreatedAt(LocalDateTime.of(2025, 7, 28, 10, 0));

        given(repo.findById(1L)).willReturn(Optional.of(tradeOrder));

        Optional<TradeOrder> result = repo.findById(1L);

        assertTrue(result.isPresent());

        TradeOrder order = result.get();

        assertEquals(Long.valueOf(1L), order.getTraderId());
        assertEquals(Long.valueOf(101L), order.getAssetId());
        assertEquals(OrderType.BUY, order.getOrderType());
        assertEquals(BigDecimal.valueOf(200), order.getQuantity());
        assertEquals(BigDecimal.valueOf(1200), order.getPrice());
        assertEquals(OrderStatus.OPEN, order.getStatus());
        assertEquals(LocalDateTime.of(2025, 7, 28, 10, 0), order.getCreatedAt());
    }

    @Test
    void testFindAllTradeOrder() {

        TradeOrder tradeOrder = new TradeOrder();
        tradeOrder.setId(1L);
        tradeOrder.setTraderId(1L);
        tradeOrder.setAssetId(101L);
        tradeOrder.setOrderType(OrderType.BUY);
        tradeOrder.setQuantity(BigDecimal.valueOf(200));
        tradeOrder.setPrice(BigDecimal.valueOf(1200));
        tradeOrder.setStatus(OrderStatus.OPEN);
        tradeOrder.setCreatedAt(LocalDateTime.of(2025, 7, 28, 10, 0));

        TradeOrder tradeOrder2 = new TradeOrder();
        tradeOrder2.setId(2L);
        tradeOrder2.setTraderId(2L);
        tradeOrder2.setAssetId(102L);
        tradeOrder2.setOrderType(OrderType.SELL);
        tradeOrder2.setQuantity(BigDecimal.valueOf(250));
        tradeOrder2.setPrice(BigDecimal.valueOf(1000));
        tradeOrder2.setStatus(OrderStatus.COMPLETED);
        tradeOrder2.setCreatedAt(LocalDateTime.of(2025, 10, 28, 10, 0));

        List<TradeOrder> list = Arrays.asList(tradeOrder, tradeOrder2);

        given(repo.findAll()).willReturn(list);

        List<TradeOrder> result = repo.findAll();

        assertEquals(2, result.size());
        
    }

    @Test
    void testDeleteTradeOrderById() {

        Long id = 1L;

        doNothing().when(repo).deleteById(id);

        repo.deleteById(id);

        given(repo.findById(id)).willReturn(Optional.empty());

        Optional<TradeOrder> result = repo.findById(id);

        assertTrue(result.isEmpty());
    }

    @Test
    void testUpdateTradeOrderById() {

        TradeOrder tradeOrder = new TradeOrder();
        tradeOrder.setId(1L);
        tradeOrder.setTraderId(1L);
        tradeOrder.setAssetId(101L);
        tradeOrder.setOrderType(OrderType.SELL);
        tradeOrder.setQuantity(BigDecimal.valueOf(200));
        tradeOrder.setPrice(BigDecimal.valueOf(1200));
        tradeOrder.setStatus(OrderStatus.COMPLETED);
        tradeOrder.setCreatedAt(LocalDateTime.of(2025, 10, 28, 10, 0));

        given(repo.save(tradeOrder)).willReturn(tradeOrder);

        TradeOrder updatedOrder = repo.save(tradeOrder);

        assertEquals(OrderType.SELL, updatedOrder.getOrderType());
        assertEquals(OrderStatus.COMPLETED, updatedOrder.getStatus());
        assertEquals(LocalDateTime.of(2025, 10, 28, 10, 0), updatedOrder.getCreatedAt());
    }
}