package com.traderorder.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.tradeorder.controller.TradeOrderController;
import com.tradeorder.enums.OrderStatus;
import com.tradeorder.enums.OrderType;
import com.tradeorder.model.TradeOrder;
import com.tradeorder.service.TradeOrderService;

@WebMvcTest(TradeOrderController.class)
@AutoConfigureMockMvc(addFilters = false)
public class TradeOrderControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockitoBean
	
	private TradeOrderService service;

	@Test
	void testGetTradeOrderById() throws Exception {

	    TradeOrder tradeOrder = new TradeOrder();
	    tradeOrder.setId(1L);
	    tradeOrder.setTraderId(101L);
	    tradeOrder.setOrderType(OrderType.BUY);
		tradeOrder.setQuantity(BigDecimal.valueOf(200));
		tradeOrder.setPrice(BigDecimal.valueOf(1200));
		tradeOrder.setStatus(OrderStatus.OPEN);
		tradeOrder.setCreatedAt(LocalDateTime.of(2025, 7, 28, 10, 0));

	    when(service.getTradeOrderById(1L))
	            .thenReturn(tradeOrder);

	    mockMvc.perform(
	            get("/tradeordersapi/tradeorder/1"))
	            .andExpect(status().isOk());
	}
	
	@Test
	void testGetAllTradeOrders() throws Exception
	{	
		TradeOrder tradeOrder=new TradeOrder();
		tradeOrder.setTraderId(1L);
		tradeOrder.setAssetId(101L);
		tradeOrder.setOrderType(OrderType.BUY);
		tradeOrder.setQuantity(BigDecimal.valueOf(200));
		tradeOrder.setPrice(BigDecimal.valueOf(1200));
		tradeOrder.setStatus(OrderStatus.OPEN);
		tradeOrder.setCreatedAt(LocalDateTime.of(2025, 7, 28, 10, 0));
		
		TradeOrder tradeOrder2=new TradeOrder();
		tradeOrder2.setTraderId(2L);
		tradeOrder2.setAssetId(102L);
		tradeOrder2.setOrderType(OrderType.SELL);
		tradeOrder2.setQuantity(BigDecimal.valueOf(250));
		tradeOrder2.setPrice(BigDecimal.valueOf(1000));
		tradeOrder2.setStatus(OrderStatus.COMPLETED);
		tradeOrder2.setCreatedAt(LocalDateTime.of(2025, 10, 28, 10, 0));
		
		List<TradeOrder> list=Arrays.asList(tradeOrder,tradeOrder2);
		
		when(service.getTradeOrders()).thenReturn(list);
		
		mockMvc.perform(get("/tradeordersapi/tradeorders")).andExpect(status().isOk());
		
	}
	@Test
	void testAddTradeOrder() throws Exception {

	    TradeOrder tradeOrder = new TradeOrder();
	    tradeOrder.setTraderId(1L);
	    tradeOrder.setAssetId(101L);
	    tradeOrder.setOrderType(OrderType.BUY);
	    tradeOrder.setQuantity(BigDecimal.valueOf(200));
	    tradeOrder.setPrice(BigDecimal.valueOf(1200));
	    tradeOrder.setStatus(OrderStatus.OPEN);
	    tradeOrder.setCreatedAt(LocalDateTime.of(2025, 7, 28, 10, 0));

	    when(service.addTradeOrder(any(TradeOrder.class)))
	            .thenReturn(tradeOrder);

	    String requestBody = """
	            {
	                "tradeOrder":{
	                    "traderId":1,
	                    "assetId":101,
	                    "orderType":"BUY",
	                    "quantity":200,
	                    "price":1200,
	                    "status":"OPEN",
	                    "createdAt":"2025-07-28T10:00:00"
	                }
	            }
	            """;

	    mockMvc.perform(post("/tradeordersapi/tradeorder")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content(requestBody))
	            .andExpect(status().isOk());
	}
	
	@Test
	void testUpdateTradeOrder() throws Exception {

	    TradeOrder tradeOrder = new TradeOrder();
	    tradeOrder.setTraderId(1L);
	    tradeOrder.setAssetId(101L);
	    tradeOrder.setOrderType(OrderType.SELL);
	    tradeOrder.setQuantity(BigDecimal.valueOf(300));
	    tradeOrder.setPrice(BigDecimal.valueOf(1500));
	    tradeOrder.setStatus(OrderStatus.COMPLETED);
	    tradeOrder.setCreatedAt(LocalDateTime.of(2025, 10, 28, 10, 0));

	    when(service.updateTradeOrder(any(Long.class), any(TradeOrder.class)))
	            .thenReturn(tradeOrder);

	    String requestBody = """
	            {
	                "traderId":1,
	                "assetId":101,
	                "orderType":"SELL",
	                "quantity":300,
	                "price":1500,
	                "status":"COMPLETED",
	                "createdAt":"2025-10-28T10:00:00"
	            }
	            """;

	    mockMvc.perform(put("/tradeordersapi/tradeorder/1")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content(requestBody))
	            .andExpect(status().isOk());
	}
	
	@Test
	void testDeleteTradeOrder() throws Exception {

	    when(service.deleteTradeOrder(1L))
	            .thenReturn("Trade Order Deleted Successfully");

	    mockMvc.perform(delete("/tradeordersapi/tradeorder/1"))
	            .andExpect(status().isOk());
	}
}
