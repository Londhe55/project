package com.tradeorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
