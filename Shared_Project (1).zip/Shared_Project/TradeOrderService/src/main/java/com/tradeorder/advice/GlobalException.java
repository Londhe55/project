package com.tradeorder.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.tradeorder.dto.ErrorResponse;
import com.tradeorder.exception.SettlementCreationFailedException;
import com.tradeorder.exception.TradeOrderListNotFoundException;
import com.tradeorder.exception.TradeOrderNotFoundException;

@RestControllerAdvice
public class GlobalException {

	@ExceptionHandler(TradeOrderNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleException1(TradeOrderNotFoundException e) {

		ErrorResponse errorResponse = new ErrorResponse(404, e.getMessage());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(TradeOrderListNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleException2(TradeOrderListNotFoundException e) {

		ErrorResponse errorResponse = new ErrorResponse(404, e.getMessage());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorResponse> handleValidationException(MethodArgumentNotValidException e) {

		ErrorResponse errorResponse = new ErrorResponse(400, "Validation Failed");

		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<ErrorResponse> handleInvalidEnumValue(HttpMessageNotReadableException e) {

	    ErrorResponse errorResponse =new ErrorResponse( 400,"Invalid Enum Value");

	    return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
	} 
	
	@ExceptionHandler(SettlementCreationFailedException.class)
	public ResponseEntity<ErrorResponse> handleSettlementCreation(SettlementCreationFailedException e)
	{
		ErrorResponse errorResponse =new ErrorResponse( 400,"Settlement Creation Failed ");
		
		return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
	}
}
