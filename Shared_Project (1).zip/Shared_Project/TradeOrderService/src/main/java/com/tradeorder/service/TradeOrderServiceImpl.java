package com.tradeorder.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tradeorder.client.AssetClient;
import com.tradeorder.client.TraderClient;
import com.tradeorder.db.TradeOrderRepository;
import com.tradeorder.exception.AssetNotFoundException;
import com.tradeorder.exception.TradeOrderListNotFoundException;
import com.tradeorder.exception.TradeOrderNotFoundException;
import com.tradeorder.exception.TraderNotFoundException;
import com.tradeorder.model.TradeOrder;

@Service
public class TradeOrderServiceImpl implements TradeOrderService {

	@Autowired
	TradeOrderRepository repo;

	public List<TradeOrder> getTradeOrders() {

		List<TradeOrder> list = repo.findAll();

		if (list.isEmpty()) {
			throw new TradeOrderListNotFoundException();
		}

		return list;
	}

	public TradeOrder addTradeOrder(TradeOrder tradeOrder) {
		tradeOrder.setCreatedAt(LocalDateTime.now());
		return repo.save(tradeOrder);
	}

	public TradeOrder getTradeOrderById(Long id) {

		TradeOrder tradeOrder = repo.findById(id).orElseThrow(() -> new TradeOrderNotFoundException());

		return tradeOrder;
	}

	public TradeOrder updateTradeOrder(Long id, TradeOrder tradeOrder) {

		TradeOrder tradeOrder2 = repo.findById(id).orElseThrow(() -> new TradeOrderNotFoundException());

		return repo.save(tradeOrder);
	}

	public String deleteTradeOrder(Long id) {

		if (!repo.existsById(id)) {
			throw new TradeOrderNotFoundException();
		}

		repo.deleteById(id);

		return "Trade Order Deleted Successfully";
	}

}