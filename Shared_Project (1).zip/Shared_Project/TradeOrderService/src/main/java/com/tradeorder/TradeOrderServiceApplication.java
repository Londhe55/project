package com.tradeorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@OpenAPIDefinition(
	    servers = {
	        @Server(url = "/", description = "Gateway")
	    })
public class TradeOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradeOrderServiceApplication.class, args);
	}

}
