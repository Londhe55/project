package com.tradeorder.dto;

import com.tradeorder.model.TradeOrder;

public class TradeOrderRequestDTO {

	TradeOrder tradeOrder;

	public TradeOrder getTradeOrder() {
		return tradeOrder;
	}

	public void setTradeOrder(TradeOrder tradeOrder) {
		this.tradeOrder = tradeOrder;
	}
	
	
}