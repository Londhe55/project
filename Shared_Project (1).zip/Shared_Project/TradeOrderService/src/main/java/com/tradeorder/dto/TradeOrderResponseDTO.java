package com.tradeorder.dto;

import com.tradeorder.model.TradeOrder;

public class TradeOrderResponseDTO {
	
	TradeOrder tradeOrder;
	int httpStatusCode;
	String message;
	
	public TradeOrder getTradeOrder() {
		return tradeOrder;
	}
	public void setTradeOrder(TradeOrder tradeOrder) {
		this.tradeOrder = tradeOrder;
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	

}