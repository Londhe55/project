package com.tradeorder.dto;

import java.math.BigDecimal;

public class AssetResponseDTO {

	private Long id;
    private String assetName;
    private String assetType;
    private BigDecimal currentPrice;
    
	public AssetResponseDTO(Long id, String assetName, String assetType, BigDecimal currentPrice) {
		super();
		this.id = id;
		this.assetName = assetName;
		this.assetType = assetType;
		this.currentPrice = currentPrice;
	}

	public AssetResponseDTO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public BigDecimal getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(BigDecimal currentPrice) {
		this.currentPrice = currentPrice;
	}
    
    

}
