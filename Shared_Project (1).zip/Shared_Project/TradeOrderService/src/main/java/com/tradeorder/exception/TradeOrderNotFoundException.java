package com.tradeorder.exception;

public class TradeOrderNotFoundException extends RuntimeException {

	public TradeOrderNotFoundException() {
		super("No Trade Order Found");
	}
}
