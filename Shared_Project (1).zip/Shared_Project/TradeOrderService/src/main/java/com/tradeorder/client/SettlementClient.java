package com.tradeorder.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.tradeorder.dto.SettlementRequestDTO;
import com.tradeorder.dto.SettlementResponseDTO;

@FeignClient(name="SettlementService")
public interface SettlementClient {

	@PostMapping("/settlements/save")
    public SettlementResponseDTO createSettlement(@RequestBody SettlementRequestDTO request);

	
}
