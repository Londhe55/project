package com.tradeorder.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tradeorder.client.AssetClient;
import com.tradeorder.client.SettlementClient;
import com.tradeorder.client.TraderClient;
import com.tradeorder.dto.SettlementRequestDTO;
import com.tradeorder.dto.SettlementResponseDTO;
import com.tradeorder.dto.TradeOrderListResponseDTO;
import com.tradeorder.dto.TradeOrderRequestDTO;
import com.tradeorder.dto.TradeOrderResponseDTO;
import com.tradeorder.dto.TraderResponseDTO;
import com.tradeorder.enums.OrderStatus;
import com.tradeorder.exception.AssetNotFoundException;
import com.tradeorder.exception.SettlementCreationFailedException;
import com.tradeorder.exception.TraderNotFoundException;
import com.tradeorder.model.Settlement;
import com.tradeorder.model.TradeOrder;
import com.tradeorder.service.TradeOrderService;

import feign.FeignException;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/tradeordersapi")
public class TradeOrderController {

	@Autowired
	TradeOrderService service;
	
	@Autowired
	TraderClient traderClient;
	
	@Autowired
	AssetClient assetClient;
	
	@Autowired
	private SettlementClient settlementClient;

	@GetMapping("/tradeorders")
	
	public ResponseEntity<TradeOrderListResponseDTO> getAllTradeOrders(){
		List<TradeOrder> tradeOrderList=this.service.getTradeOrders();
		TradeOrderListResponseDTO listResponseDTO=new TradeOrderListResponseDTO();
		listResponseDTO.setList(tradeOrderList);
		listResponseDTO.setHttpStatusCode(200);
		listResponseDTO.setMessage("Fetched All TradeOrders");
		
		return ResponseEntity.ok(listResponseDTO);
		
	}
	
	@PostMapping("/tradeorder")
	public ResponseEntity<TradeOrderResponseDTO> addTradeOrder(@Valid @RequestBody TradeOrderRequestDTO orderRequestDTO) {
		try
		{
			traderClient.getTraderById(orderRequestDTO.getTradeOrder().getTraderId());
		}
		catch(FeignException e)
		{
			throw new TraderNotFoundException();
		}
		try
		{
			assetClient.getById(orderRequestDTO.getTradeOrder().getAssetId());
		}
		catch(FeignException e)
		{
			throw new AssetNotFoundException();
		}
		
		TradeOrder tradeOrder=this.service.addTradeOrder(orderRequestDTO.getTradeOrder());
		
		try
		{
			if(tradeOrder.getStatus()==OrderStatus.COMPLETED)
			{
				SettlementRequestDTO settlementRequestDTO=new SettlementRequestDTO();
				
				Settlement settlement = new Settlement();
				
				settlement.setTradeOrderId(tradeOrder.getId());
				settlement.setSettlementDate(LocalDateTime.now());
				settlement.setAmount(tradeOrder.getQuantity().multiply(tradeOrder.getPrice()));
				settlement.setStatus("COMPLETED");
				settlement.setPaymentReference("PAY-" + tradeOrder.getId());
				
				settlementRequestDTO.setSettlement(settlement);
				settlementClient.createSettlement(settlementRequestDTO);
			}
		}
		catch(FeignException e)
		{
			throw new SettlementCreationFailedException();
		}
		
		TradeOrderResponseDTO orderResponseDTO=new TradeOrderResponseDTO();
		orderResponseDTO.setTradeOrder(tradeOrder);
		orderResponseDTO.setHttpStatusCode(201);
		orderResponseDTO.setMessage("Trade Order saved succesfully");
		
		return ResponseEntity.ok(orderResponseDTO);
	}

	@GetMapping("/tradeorder/{id}")
	public ResponseEntity<TradeOrderResponseDTO> getTradeOrderById(@PathVariable Long id) {

		TradeOrder tradeOrder=this.service.getTradeOrderById(id);
		TradeOrderResponseDTO orderResponseDTO=new TradeOrderResponseDTO();
		orderResponseDTO.setTradeOrder(tradeOrder);
		orderResponseDTO.setHttpStatusCode(200);
		orderResponseDTO.setMessage("Fetched the record with id"+id);
		
		return ResponseEntity.ok(orderResponseDTO);
	}

	
	@PutMapping("/tradeorder/{id}")
	public ResponseEntity<TradeOrderResponseDTO> updateTradeOrder(@PathVariable Long id,
			@Valid @RequestBody TradeOrderRequestDTO tradeOrderRequestDTO) {

		TradeOrder updatedTradeOrder= this.service.updateTradeOrder(id, tradeOrderRequestDTO.getTradeOrder());
		TradeOrderResponseDTO orderResponseDTO=new TradeOrderResponseDTO();
		orderResponseDTO.setTradeOrder(updatedTradeOrder);
		orderResponseDTO.setHttpStatusCode(200);
		orderResponseDTO.setMessage("Updated the TradeOrder succesfully");
		
		return ResponseEntity.ok(orderResponseDTO);
	}

	@DeleteMapping("/tradeorder/{id}")
	public ResponseEntity<TradeOrderResponseDTO> deleteTradeOrder(@PathVariable Long id) {

		String message=service.deleteTradeOrder(id);
		TradeOrderResponseDTO orderResponseDTO=new TradeOrderResponseDTO();
		orderResponseDTO.setHttpStatusCode(200);
		orderResponseDTO.setMessage(message);
		return ResponseEntity.ok(orderResponseDTO);
	}
}