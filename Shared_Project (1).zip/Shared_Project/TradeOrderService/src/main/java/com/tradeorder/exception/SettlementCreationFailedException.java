package com.tradeorder.exception;

public class SettlementCreationFailedException extends RuntimeException{

	public SettlementCreationFailedException()
	{
		super("Unable to create Settlement");
	}
}
