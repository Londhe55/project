package com.tradeorder.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.tradeorder.dto.TraderResponseDTO;

@FeignClient(name = "trader-service")
public interface TraderClient {

	@GetMapping("/traders/{id}")
	public TraderResponseDTO getTraderById(@PathVariable Long id);

}
