package com.tradeorder.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.tradeorder.dto.AssetResponseDTO;

@FeignClient(name="asset-service")
public interface AssetClient {

	@GetMapping("/assets/{id}")
	public AssetResponseDTO getById(@PathVariable Long id);
}
