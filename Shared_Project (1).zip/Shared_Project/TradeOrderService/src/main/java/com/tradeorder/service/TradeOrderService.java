package com.tradeorder.service;

import java.util.List;

import com.tradeorder.model.TradeOrder;

public interface TradeOrderService {

	public List<TradeOrder> getTradeOrders();
	public TradeOrder addTradeOrder(TradeOrder tradeOrder);
	public TradeOrder getTradeOrderById(Long id);
	public TradeOrder updateTradeOrder(Long id, TradeOrder tradeOrder);
	public String deleteTradeOrder(Long id);


}
