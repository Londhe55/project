package com.tradeorder.db;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tradeorder.model.TradeOrder;

@Repository
public interface TradeOrderRepository extends JpaRepository<TradeOrder, Long> {

}
