package com.tradeorder.exception;

public class TraderNotFoundException extends RuntimeException {

	public TraderNotFoundException() {
		super("Trader is not found");
	}
}
