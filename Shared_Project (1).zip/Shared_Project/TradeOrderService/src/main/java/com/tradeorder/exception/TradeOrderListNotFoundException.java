package com.tradeorder.exception;

public class TradeOrderListNotFoundException extends RuntimeException {

	public TradeOrderListNotFoundException() {
		super("Trader Order List Not Found");
	}
}
