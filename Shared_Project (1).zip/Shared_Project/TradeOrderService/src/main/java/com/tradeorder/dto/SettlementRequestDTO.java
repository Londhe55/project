package com.tradeorder.dto;

import com.tradeorder.model.Settlement;

public class SettlementRequestDTO {
	
	Settlement settlement;

	public Settlement getSettlement() {
		return settlement;
	}

	public void setSettlement(Settlement settlement) {
		this.settlement = settlement;
	}

    

    
}
