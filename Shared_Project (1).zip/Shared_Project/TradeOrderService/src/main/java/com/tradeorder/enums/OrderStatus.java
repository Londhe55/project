package com.tradeorder.enums;

public enum OrderStatus {
	OPEN,
    PENDING,
    COMPLETED,
    CANCELLED

}
