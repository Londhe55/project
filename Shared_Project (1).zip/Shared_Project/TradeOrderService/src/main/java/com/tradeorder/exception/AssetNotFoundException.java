package com.tradeorder.exception;

public class AssetNotFoundException extends RuntimeException {

	public AssetNotFoundException()
	{
		super("Asset is not found");
	}
}
