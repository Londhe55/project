package com.tradeorder.enums;

public enum OrderType {
	BUY,
	SELL
}
