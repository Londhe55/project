package com.tradeorder.dto;

import java.util.List;

import com.tradeorder.model.TradeOrder;

public class TradeOrderListResponseDTO {

	List<TradeOrder> list;
	int httpStatusCode;
	String message;
	
	public List<TradeOrder> getList() {
		return list;
	}
	public void setList(List<TradeOrder> list) {
		this.list = list;
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}