package com.tradeorder.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.tradeorder.enums.OrderStatus;
import com.tradeorder.enums.OrderType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "TradeOrders")
public class TradeOrder {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column
	@NotNull
	private Long traderId;

	@Column
	@NotNull
	private Long assetId;

	@Column
	@NotNull
	@Enumerated(EnumType.STRING)
	private OrderType orderType;

	@Column
	@NotNull
	@Positive
	private BigDecimal quantity;

	@Column
	@NotNull
	@Positive
	private BigDecimal price;

	@Column
	@NotNull
	@Enumerated(EnumType.STRING)
	private OrderStatus status;

	@Column
	@NotNull
	private LocalDateTime createdAt;

	public TradeOrder() {
		super();
	}


	public TradeOrder(Long id, @NotNull Long traderId, @NotNull Long assetId, @NotNull OrderType orderType,
			@NotNull @Positive BigDecimal quantity, @NotNull @Positive BigDecimal price, @NotNull OrderStatus status,
			@NotNull LocalDateTime createdAt) {
		super();
		this.id = id;
		this.traderId = traderId;
		this.assetId = assetId;
		this.orderType = orderType;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.createdAt = createdAt;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public Long getTraderId() {
		return traderId;
	}



	public void setTraderId(Long traderId) {
		this.traderId = traderId;
	}



	public Long getAssetId() {
		return assetId;
	}



	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}



	public OrderType getOrderType() {
		return orderType;
	}



	public void setOrderType(OrderType orderType) {
		this.orderType = orderType;
	}



	public BigDecimal getQuantity() {
		return quantity;
	}



	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}



	public BigDecimal getPrice() {
		return price;
	}



	public void setPrice(BigDecimal price) {
		this.price = price;
	}



	public OrderStatus getStatus() {
		return status;
	}



	public void setStatus(OrderStatus status) {
		this.status = status;
	}



	public LocalDateTime getCreatedAt() {
		return createdAt;
	}



	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}



	@Override
	public String toString() {
		return "TradeOrders [id=" + id + ", traderId=" + traderId + ", assetId=" + assetId + ", orderType=" + orderType
				+ ", quantity=" + quantity + ", price=" + price + ", status=" + status + ", createdAt=" + createdAt
				+ "]";
	}

}
