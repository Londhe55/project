package com.training.bean;

public class F implements E {

	@Override
	public void m1() {

		System.out.println("M1");
	}

	@Override
	public void m2() {

		System.out.println("M2");
	}

	@Override
	public void m3() {

		System.out.println("M2");
	}

	@Override
	public void m4() {

		System.out.println("M3");
	}
	

}


// This class must be implemet all the method of E class or if not then this class must be abstarct class