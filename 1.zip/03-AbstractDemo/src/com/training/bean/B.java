package com.training.bean;

public class B  extends A{
	
	
//	@Override
//	public void m3() {
//		System.out.println("CTs");
//	}
	
	

	@Override
	void m4() {
		// TODO Auto-generated method stub
		
	}

}
