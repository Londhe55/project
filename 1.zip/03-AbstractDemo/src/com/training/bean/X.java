package com.training.bean;

public class X implements E{
	

	public void m1() {
		System.out.println("1");
	}
	
	
	public void m2() {
		System.out.println("2");
	}
	
	public void m3() {
		System.out.println("3");
	}
	
	public void m4() {
		System.out.println("4");
	}
}
