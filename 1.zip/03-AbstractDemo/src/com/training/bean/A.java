package com.training.bean;

abstract public class A {
	
	
	public void m1() {
		System.out.println("Welcome");
	}
	
	
	public void m2() {
		System.out.println("How are You ?");
	}
	
	
//	public void m3();
	
	abstract void m4();

}



// can not create obj for abstarct classes
// can create only variable for abstarct classes

// if you don't  want to overide abstarct method inside the subclass then you must define subclass as the abstact class

// Normal class also called concrete class
// abstract class does not contain any public method 

//To sum up the strict rules for an abstract class:
//
//If it has NO body (ends with a ;), it MUST have the abstract keyword.
//
//If it does NOT have the abstract keyword, it MUST have a body (ends with { }).

// You cannot define a default method without a body.