package com.training.bean;

public class C {
	
//	public abstarct m1();
//	public abstarct m2();
//	public abstarct m3();
	
	
	
	// you cannot define an abstract method at all inside a concrete (regular) class,
	// regardless of whether it has a body or not.

}
