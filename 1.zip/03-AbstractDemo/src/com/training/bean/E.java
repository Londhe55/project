package com.training.bean;

public interface E {

	void m1();
	void m2();
	void m3();
	void m4();
	
}


// any method defined in interface by deafult are public
// all the methods should be public and abstarct 


// Can define variable in interface 
// can not not create object

