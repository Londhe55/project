package com.training.bean;

import java.util.Objects;

public class Loan implements Comparable<Loan> {
	
	int loanId;
	String customerName;
	double loanAmount;
	int tenure;
	
	
	
	public Loan(int loanId, String customerName, double loanAmount, int tenure) {
		super();
		this.loanId = loanId;
		this.customerName = customerName;
		this.loanAmount = loanAmount;
		this.tenure = tenure;
	}


	

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", customerName=" + customerName + ", loanAmount=" + loanAmount + ", tenure="
				+ tenure + "]";
	}



	

	@Override
	public int hashCode() {
		return Objects.hash(loanAmount);
	}



	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loan other = (Loan) obj;
		return Double.doubleToLongBits(loanAmount) == Double.doubleToLongBits(other.loanAmount);
	}




	@Override
	public int compareTo(Loan o) {
		
		if (this.loanAmount < o.loanAmount) {
			return -1;
		}
		
		if (this.loanAmount > o.loanAmount) {
			return 1;
		}
		return 0;
	}
	
	
	
	
	
	

}



// when you implemets Comaparable then you must override ComapareTo method
// and in the compareTo method you need to provide implementation 
// comprabale comes from java.lang 


// Only one variable can be compared in the compareTo 


// To solve above issure Compartor comes in the picture



