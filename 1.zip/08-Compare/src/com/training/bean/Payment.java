package com.training.bean;

import java.util.Objects;

public class Payment implements Comparable<Payment>{
	
	int id;
	double amount;
	String paidBy;
	
	
	

	

	@Override
	public int hashCode() {
		return Objects.hash(amount);
	}



	


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payment other = (Payment) obj;
		return Double.doubleToLongBits(amount) == Double.doubleToLongBits(other.amount);
	}






	@Override
	public String toString() {
		return "Payment [id=" + id + ", amount=" + amount + ", paidBy=" + paidBy + "]";
	}



	





	public Payment(int id, double amount, String paidBy) {
		super();
		this.id = id;
		this.amount = amount;
		this.paidBy = paidBy;
	}






	@Override
	public int compareTo(Payment o) {
		if (this.amount < o.amount) {
			return -1;
		}
		
		if (this.amount > o.amount) {
			return 1;
		}
		return 0;
	}
	
	
	




	
	
	
	
	
	

}
