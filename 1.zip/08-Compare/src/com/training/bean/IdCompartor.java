package com.training.bean;

import java.util.Comparator;

public class IdCompartor implements Comparator<Loan> {

	
	
	@Override
	public int compare(Loan o1, Loan o2) {
		
		return o1.loanId-o2.loanId;
		
		
//		if (o1.loanAmount < o2.loanAmount) {
//			return -1;
//		}
//		
//		if (o1.loanAmount > o2.loanAmount) {
//			return 1;
//			
//		}
//		return 0;
	}

}
