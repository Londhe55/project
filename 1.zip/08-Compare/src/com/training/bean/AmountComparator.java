package com.training.bean;

import java.util.Comparator;

public class AmountComparator implements Comparator<Long> {

	

	@Override
	public int compare(Long o1, Long o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}

// comapre method need to implements when you implments class as a comparator

