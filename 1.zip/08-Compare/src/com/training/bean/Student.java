package com.training.bean;

import java.util.Objects;

public class Student  implements Comparable<Student>{
	
	int rollNumber;
	String name;
	int marks;
	
	
	
	
	
	
	
	
	
	
	
	
	
	public Student(int rollNumber, String name, int marks) {
		super();
		this.rollNumber = rollNumber;
		this.name = name;
		this.marks = marks;
	}







	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", name=" + name + ", marks=" + marks + "]";
	}




	@Override
	public int hashCode() {
		return Objects.hash(marks);
	}





	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return marks == other.marks;
	}







	@Override
	public int compareTo(Student o) {
		
		if (this.marks < o.marks) {
			return -1;
		}
		
		if (this.marks > o.marks) {
			return 1;
		}
		return 0;
		
	}
	
	
	
	

}
