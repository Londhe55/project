package com.training.ui;

import com.training.bean.Student;

public class Main4 {
	
	public static void main(String[] args) {
		
		
		Student student = new Student(1, "Veer", 80	);
		Student student2 = new Student(2, "Ram", 70);
		
		
		System.out.println(student.compareTo(student2));
	}

}
