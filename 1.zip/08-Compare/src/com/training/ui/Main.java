package com.training.ui;

import com.training.bean.Loan;

public class Main {
	
	public static void main(String[] args) {
		
		int a =100;
		int b =50;
		
		if (a<b) {
			System.out.println("B is Greater");
		}
		if (a>b) {
			System.out.println("A is Greater");
		}
		
		if (a ==b ) {
			System.out.println("A and B are Equal");
		}
		
		
		Loan loan = new Loan(101, "Veer", 12000, 9);
		Loan loan1 = new Loan(102, "John", 34000, 12);
		
		
		int result = loan.compareTo(loan1);
		
		System.out.println(result);
	}

}
