package com.training.ui;

import com.training.bean.Loan;

public class Main2 {
	
	public static void main(String[] args) {
		
		Loan loan1 = new Loan(101, "Veer", 12000, 9);
		Loan loan2 = new Loan(102, "John", 34000, 12);
		
		 
		
	}

}
