package com.training.ui;

import com.training.bean.Payment;

public class Main3 {
	
	public static void main(String[] args) {
		
		Payment payment1 = new Payment(101, 100000.00, "Veer");
		Payment payment2 = new Payment(102, 20000.00, "Vikas");
		
		

		int result = payment1.compareTo(payment2);
		

		System.out.println(result);
		
	}
	
	
	
	
	
	
	


}
