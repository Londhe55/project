package com.training.ui;

import java.util.function.Function;

import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Square;

public class Main3 {

	public static void main(String[] args) {
		
		Function<Circle, Square> f1;
		f1 = (c) -> new Square(c.getRadius());
		Square sqr = f1.apply(new Circle(100));
		System.out.println(sqr);
		
		
		
		Function<Employee, Double> f2;
		f2 = (e) -> e.getSalary();
		
		Double sal = f2.apply(new Employee(1, "ram", "M", 10000, 'A'));
		System.out.println(sal);
		
		
		Function<Employee, String> f3;
		f3 = (e) -> e.getGender();
		String gender = f3.apply(new Employee(1, "Ram", "Male", 100.00, 'A'));
		System.out.println(gender);
	}

}
