package com.training.ui;

import java.util.function.Predicate;

import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Square;

public class Main2 {
	
	static void check(Predicate<Square> predicate) {
		System.out.println(predicate.test(new Square(40)));
	}

	public static void main(String[] args) {

		
		Predicate<Integer> predicate1;
		
		predicate1 = (Integer i) -> {return i>100? true: false;};  // ternary operator with lambada Expression
		
		predicate1 = (i)-> i>100? true : false;         // Simplified Lambda Expression
		
		predicate1 = (Integer i)->{
			if(i>100) {
				return true;
			}
			else {
				return false;
			} 
		};
		
		System.out.println(predicate1.test(500));
		
		
		
		
		Predicate<Circle> predicate2 = (c) -> c.getRadius()>30;
		System.out.println(predicate2.test(new Circle(50)));
		
		
		Predicate<Employee> predicate3 = e -> e.getSalary()>5000;
		System.out.println(predicate3.test(new Employee(1, "Ram", "M", 10000, 'B')));
		
		
		check((s) -> s.getSize() >50 );
	}

}
