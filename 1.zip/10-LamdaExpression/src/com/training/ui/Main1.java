package com.training.ui;

import java.util.function.Consumer;

import com.training.model.Circle;
import com.training.model.Employee;

public class Main1 {
	
	
	static void execute(Consumer<Circle> consumer) {
		consumer.accept(new Circle(90));
	}

	
	
	static void execute1(Consumer<Employee> consumer) {
		consumer.accept(new Employee(1, "Ram", "M", 5000.00, 'A'));
	}
	public static void main(String[] args) {

		
		
		Consumer<String> consumer1 = new Consumer<String>() {
			
			@Override
			public void accept(String t) {

				System.out.println(t.length());
			}
		};     
		
		
		consumer1.accept("Welcome");
		
		
		Consumer<String> consumer2 = new Consumer<String>() {
			
			@Override
			public void accept(String t) {

				System.out.println(t.toUpperCase());
			}
		};
		
		consumer2.accept("Cognizant");
		
		
		
		
		// Using Lamda Expression
		
//		
////		Consumer<String> consumer3 = (String t) ->{
////			System.out.println(t.length());
////		};
////		
////		consumer3.accept("Chennai");
		
		
		// Here String and Curly Braces are optional 
		
//		Consumer<String> consumer3 = ( t) ->{
//			System.out.println(t.length());
//		};
//		consumer3.accept("Chennai");
//	}
//	
	
//	Consumer<String> consumer3 = ( t) -> System.out.println(t.length());
//	
//	consumer3.accept("Chennai");


//		Consumer<Integer> consumer4 = (Integer i) -> {System.out.println(i*i);};   // Lambda Expression
//		Consumer<Integer> consumer4 = (Integer i) -> System.out.println(i*i); 	   // Lambda Expression
//		Consumer<Integer> consumer4 = i -> System.out.println(i*i);                // Lambda Expression
		// Lambda Expression
		Consumer<Integer> consumer4 = (Integer i)->{
			System.out.println(i*i);
		};
		
		consumer4.accept(10);
		
		
		
//		Consumer<Circle> consumer5 = c -> System.out.println(c.getRadius());  // Lambda Expression
		
		Consumer<Circle> consumer5 = (Circle c)->{
			System.out.println(c.getRadius());
		};
		
		consumer5.accept(new Circle(5));
		
		
		
		
		Consumer<Employee> consumer67 = (e) -> System.out.println(e.getSalary());
		
		Consumer<Employee> consumer6 = (Employee e)->{
			System.out.println(e.getSalary());
		};
		
		consumer6.accept(new Employee(11, "Ram", "M", 2000.00, 'A'));
		
		
		
		
		
		Consumer<Circle> consumer7 = (c) -> System.out.println(c.getRadius());
		execute(consumer7);
		
		
		
		// Curly braces is not necessary and when you remove {} the must remove ;
		// Also () are optional
		
		execute((c)-> {System.out.println(c.getRadius());});
		
		execute1((e) -> System.out.println(e.getGrade()));
		
		execute1((e1) -> System.out.println(e1.getName().toUpperCase()));
	}


}


// Consumer
// producerC
// Supplier
// Function

// Before JDk 1.8 above method are used 


// After JDK1.8 lambda expression was introduced





// Function receiving another function as a prameter then it is called as functional programming





