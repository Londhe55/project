package com.training.ui;
import com.trainng.bean1.*;

public class Main {
	
	public static void main(String[] args) {
		
		Consumer c1 = new StringConsumer();
		c1.consume("CTS");
		
		// Annonyms Class
		
		Consumer c2 = new Consumer() {
			
			@Override
			public void consume(String s) {
				System.out.println(s.toUpperCase());
			}
		};
		
		c2.consume("Chennai");
		
		
		
		
		
		// Lamda Expression 
		
		Consumer c3 = (String s)->{
			System.out.println(s.toLowerCase());
		};		// Lamda Expression
		
		c3.consume("Pune");
		
		Consumer c4 = (String s)->{
			System.out.println(s.toString());
		};
		c4.consume("Maharashtra");
		
	}

}


// An interface with a single method is called as Functional Interface
// It can be implemted using lambda expression only



// Generics

// Class Name defined with the className with <T> it is called Generics
// In Generic you can crate Object array

// Generics are helpful when you don't want to implemnet same logic again and again the use Generics

// For Interface also you can use Genrics



