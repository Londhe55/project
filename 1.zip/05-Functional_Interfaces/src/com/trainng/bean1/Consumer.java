package com.trainng.bean1;

@FunctionalInterface
public interface Consumer {
	
	void consume(String s);

}
