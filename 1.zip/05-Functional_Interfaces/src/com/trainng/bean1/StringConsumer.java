package com.trainng.bean1;

public class StringConsumer implements Consumer {
	
	@Override
	public void consume(String s) {
		System.out.println(s.length());
	}

}
