package com.training.ui;

import java.util.ArrayList;
import java.util.List;

public class Main2 {

	public static void main(String[] args) {

		List<Double> list1 	= new ArrayList<Double>();
		
		
		list1.add(10.25555);
		list1.add(12.2345);
		list1.add(13.12344);
		list1.add(15.3728);
		list1.add(16.27872);
		list1.add(null);
		list1.add(null);
		
		
		
		for(int i = 0; i < list1.size(); i++) {
			System.out.println(list1.get(i));
		}
		
		
		for(Double j: list1) {
			System.out.println(j);
		}
		
		
		
//		System.out.println(list1.get(list1.size()-1));
//		
//		
//		System.out.println(list1.set(0, 500.06));
//		
//		System.out.println(list1.contains(400.0));
//		
//		System.out.println(list1.remove(3));
//		
//		System.out.println(list1.size());
//		
//		
////		System.out.print(list1.clear());
//		
//		System.out.println(list1.isEmpty());
		
		
	}

}
