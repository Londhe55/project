package com.training.ui;

import java.util.HashMap;
import java.util.Map;

import com.training.model.Circle;

public class Main12 {

	public static void main(String[] args) {
		
		
		Map<Integer, Circle	> map = new HashMap<Integer, Circle>();
		
		map.put(2, new Circle(10));
		map.put(3, new Circle(20));
		map.put(30, new Circle(30));
		
		
		
		for(Map.Entry<Integer, Circle> entry: map.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}

}



// For list you don't  need any comparable , comparator or equals method



// Fuctional Interface 
// Coinsumer, Supplier , Predivcator, 
// suplier doesn't take any paramerter and return one object as T
// Consumere takes pramerter but don't return anytrhing 