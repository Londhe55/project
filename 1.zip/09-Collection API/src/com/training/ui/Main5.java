package com.training.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Main5 {

	public static void main(String[] args) {
		
		
		// Map
		
		// hashMap
		
		// Not Orderd Collection
		// Keys can be uinque
		// Values can be duplicate
		
		
		
		
		
		String s1 = "coountryName";
		String s2 = "India";
		String s3 = "primeMinister";
		String s4 = "Modi";
		String s5 = "republicDay";
		String s6 = "26-jan-1950";
		
		
		Map<String, String> map = new HashMap<String, String>();
		
		
		map.put(s1, s2);
		map.put(s3, s4);
		map.put(s5, s6);
		
		System.out.println(map);
		
		System.out.println(map.get("primeMinister"));    // return the value related to  primeMinister key
		
		System.out.println(map.keySet());  // return all the keys in the Collection
		
		System.out.println(map.values());  // return all the values in the Collection
		
		
		System.out.println(map.containsKey("republicDay"));     // Return true if prsent otherwise false
		
		
		
		
		Set<String> allKeys = map.keySet();
		
		
		for(String key: allKeys) {
			System.out.println(key + " : "+ map.get(key));   // Return key with values
		}
		
		
		
		// TreeMap
		
		// Sorted Collection in Ascending Order
		
		
		

		
//		String s1 = "coountryName";
//		String s2 = "India";
//		String s3 = "primeMinister";
//		String s4 = "Modi";
//		String s5 = "republicDay";
//		String s6 = "26-jan-1950";
//		
//		
//		Map<String, String> map = new HashMap<String, String>();
//		
//		
//		map.put(s1, s2);
//		map.put(s3, s4);
//		map.put(s5, s6);
//		
//		System.out.println(map);
//		
//		System.out.println(map.get("primeMinister"));
	}

}
