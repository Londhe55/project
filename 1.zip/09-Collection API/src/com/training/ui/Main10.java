package com.training.ui;

import java.util.Set;
import java.util.TreeSet;

import com.training.model.Student;

public class Main10 {

	public static void main(String[] args) {

		
		
		Student s1 = new Student(1, "Rahul", 95.00, 5);
		Student s2 = new Student(2, "Sham", 85.00, 4);
		Student s3 = new Student(3, "Ram", 75.00, 3);
		Student s4 = new Student(4, "Vikas", 65.00, 2);
		Student s5 = new Student(5, "Rohit", 55.00, 1);
		Student s6 = new Student(6, "Virat", 45.00, 1);
		
		
		
		Set<Student> set = new TreeSet<Student>();
		
		set.add(s1);
		set.add(s2);
		set.add(s3);
		set.add(s4);
		set.add(s5);
		set.add(s6);
		
		
		
		System.out.println(set.size());
		
		
		for(Student s: set) {
			System.out.println(s);
		}
		
		
	}

}
