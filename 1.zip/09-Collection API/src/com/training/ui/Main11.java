package com.training.ui;

import java.security.KeyStore.Entry;
import java.util.HashMap;
import java.util.Map;

import com.training.model.Employee;

public class Main11 {

	public static void main(String[] args) {

		
		Employee e1 = new Employee(104, "Reshmi", "Female", 12000.00, 'C');
		Employee e2 = new Employee(105, "Vikas", "Male", 7000.00, 'A');
		Employee e3 = new Employee(105, "Raj", "Male", 7000.00, 'B');
		
		
		
		
		Map<String, Employee> map = new HashMap<String, Employee>();
		
		
		map.put("Best Employee", e2);
		map.put("Average Employee", e3);
		map.put("Poor performing Employee", e1);
		
		
		System.out.println(map);
		
		
		System.out.println(map.keySet());
		
		System.out.println(map.values());
		
		
		
		for(Map.Entry<String, Employee> entry: map.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue() );
		}
	}

}
