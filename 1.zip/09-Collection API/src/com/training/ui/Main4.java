package com.training.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Main4 {

	public static void main(String[] args) {

		Set<String> set = new HashSet();
		
		set.add("Chennai");
		
		set.add("Pune");
		set.add("Hydrabad");
		set.add("US");
		set.add("India");
		set.add("Uk");
		
		
		
		for(String i: set) {
			System.out.println(i);
		}
		
		
//		System.out.println(set);
//		
//		System.out.println(set.size());
//		
//		System.out.println(set.remove("US"));
//		
//		System.out.println(set);
//		
//		System.out.println(set.contains("Pune"));
//		
//		set.clear();
//		
//		System.out.println(set.isEmpty());
	}

}
