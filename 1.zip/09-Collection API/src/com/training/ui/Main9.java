package com.training.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.training.model.Employee;
import com.training.model.EmployeeGradeCompartor;
import com.training.model.EmployeeIdComparator;

public class Main9 {

	public static void main(String[] args) {
		
//		Employee e1 = new Employee(101, "Ram", "Male", 3000.00, 'B');
//		Employee e2 = new Employee(102, "Shalini", "Female", 5000.00, 'A');
//		Employee e3 = new Employee(103, "Sham", "Male", 8000.00, 'A');
//		Employee e4 = new Employee(104, "Reshmi", "Female", 12000.00, 'C');
//		Employee e5 = new Employee(105, "Vikas", "Male", 7000.00, 'A');
//		Employee e6 = new Employee(105, "Raj", "Male", 7000.00, 'B');
//		
//		
//		
//		Set<Employee> empSet = new HashSet<Employee>();
//		
//		empSet.add(e1);
//		empSet.add(e3);
//		empSet.add(e2);
//		empSet.add(e4);
//		empSet.add(e5);
//		empSet.add(e6);
//		
//		
//		
//		System.out.println(empSet);
//		
//		System.out.println(empSet.size());
//		
		
		
		
		// treeSet 
		
		//to use below code in treeset ithen you must implements comparable in the Employee also compareTo method
		
		
		
//		Employee e1 = new Employee(101, "Ram", "Male", 3000.00, 'B');
//		Employee e2 = new Employee(102, "Shalini", "Female", 5000.00, 'A');
//		Employee e3 = new Employee(103, "Sham", "Male", 8000.00, 'A');
//		Employee e4 = new Employee(104, "Reshmi", "Female", 12000.00, 'C');
//		Employee e5 = new Employee(105, "Vikas", "Male", 7000.00, 'A');
//		Employee e6 = new Employee(105, "Raj", "Male", 7000.00, 'B');
//		
//		
//		
//		Set<Employee> empSet = new TreeSet(new EmployeeGradeCompartor());
//		
//		empSet.add(e1);
//		empSet.add(e3);
//		empSet.add(e2);
//		empSet.add(e4);
//		empSet.add(e5);
//		empSet.add(e6);
//		
//		
//		
//		System.out.println(empSet);
//		
//		System.out.println(empSet.size());
		
		
		
		
		
		
		
		Employee e1 = new Employee(101, "Ram", "Male", 3000.00, 'B');
		Employee e2 = new Employee(102, "Shalini", "Female", 5000.00, 'A');
		Employee e3 = new Employee(103, "Sham", "Male", 8000.00, 'A');
		Employee e4 = new Employee(104, "Reshmi", "Female", 12000.00, 'C');
		Employee e5 = new Employee(105, "Vikas", "Male", 7000.00, 'A');
		Employee e6 = new Employee(105, "Raj", "Male", 7000.00, 'B');
		
		
		
		Set<Employee> empSet = new TreeSet(new EmployeeIdComparator());
		
		empSet.add(e1);
		empSet.add(e3);
		empSet.add(e2);
		empSet.add(e4);
		empSet.add(e5);
		empSet.add(e6);
		
		
		
		System.out.println(empSet);
		
		System.out.println(empSet.size());
		
		
		
		
	}

}
