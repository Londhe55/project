package com.training.ui;

import java.util.HashSet;
import java.util.Set;

import com.training.model.Circle;

public class Main7 {

	public static void main(String[] args) {
		
		Set<Circle> circleSet = new HashSet<Circle>();
		
		
		Circle c1 = new Circle(2);
		Circle c2 = new Circle(10);
		Circle c3 = new Circle(5);
		Circle c4 = new Circle(100);
		
		
		circleSet.add(c1);
		circleSet.add(c2);
		circleSet.add(c3);
		circleSet.add(c4);
		
		
		// Circle is a custom class
		// Due to that here new Circle(10) will be  added when we are using set
		// If we don't want then you can use equals method should be used in the Circle class
		
		circleSet.add(new Circle(12));
		circleSet.add(new Circle(10));
		
		
		System.out.println(circleSet.size());
		
		System.out.println(circleSet);
		
		for(Circle c: circleSet) {
			System.out.println(c);
		}
				
		
		
		
		

	}

}
