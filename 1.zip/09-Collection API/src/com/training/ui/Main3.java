package com.training.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Main3 {

	public static void main(String[] args) {
		
		// Set
		
		
		// Insertion Order is not maintained
		// allows duplicates
		// index based operation are not available
		// Not Sorted
		// You can add only one null value in Treeset
		
		// You can not use Traditional for loop Because of index based search is not allowed in set
		// Instead of Traditional You can use Modern loop as for each loop
		

		
//		Set<Float> set = new HashSet<Float>();
//		
//		set.add(56.0f);  // Must give f otherwise it will considere as the double value
//		set.add(12.5f);
//		set.add(22.5f);
//		set.add(10.6f);
//		
//		
//		System.out.println(set);
//		
//		System.out.println(set.contains(56.0f));
//		
//		System.out.println(set.remove(22.5f));
//		
//		System.out.println(set);
//		
//		set.clear();
//		
//		System.out.println(set.isEmpty());
		
		
		
		
		
		// Tree Set
		
		// Sorted Collection ==> Ascending Order
		// Insertion Order is not maintained
		// You can not add only one null value in the HashSet
		
		
		Set<Float> set = new TreeSet();
		
		set.add(56.0f);  // Must give f otherwise it will considere as the double value
		set.add(12.5f);
		set.add(22.5f);
		set.add(10.6f);
//		set.add(null);

		
		System.out.println(set);
		
		System.out.println(set.contains(56.0f));
		
		System.out.println(set.remove(22.5f));
		
		System.out.println(set);
		
		set.clear();
		
		System.out.println(set.isEmpty());
		
		
		
		
	}

}
