package com.training.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Main6 {

	public static void main(String[] args) {
		
		String s1 = "minimum";
		Integer i1 = 100;
		
		String s2 = "maximum";
		Integer i2 = 1000;
		
		
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		
		
		map.put(s1, i1);
		map.put(s2, i2);
		
	
		
		System.out.println("Return all the Keys");
		System.out.println(map.keySet());
		
		
		System.out.println();
		System.out.println("Return all the Values");
		System.out.println(map.values());
		
		
		System.out.println();
		Set<String> allKeys = map.keySet();
		
		for(String key: allKeys) {
			System.out.println(key + " : "+ map.get(key));   // Return key with values
		}
		
		
		
		System.out.println();
		System.out.println(map);
	}

}
