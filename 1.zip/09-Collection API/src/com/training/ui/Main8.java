package com.training.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.training.model.Square;

public class Main8 {

	public static void main(String[] args) {
		
		
//		Set<Square> squareSet = new HashSet<Square>();
//		
//	
//		
//		squareSet.add(new Square(2));
//		squareSet.add(new Square(4));
//		squareSet.add(new Square(15));
//		squareSet.add(new Square(5));
//		squareSet.add(new Square(10));
//		
//		
//		System.out.println(squareSet);
//		
//		System.out.println(squareSet.size());
//		
//		
//		
//		for(Square s: squareSet) {
//			System.out.println(s);
//		}
//		
//		squareSet.clear();
//		System.out.println(squareSet.isEmpty());
		
		
		
		
		
		// Treeset
		
		
		
		
		
		
		
//		Set<Square> squareSet = new TreeSet();
//		
//		
//	
//		
//		squareSet.add(new Square(2));
//		squareSet.add(new Square(4));
//		squareSet.add(new Square(15));
//		squareSet.add(new Square(5));
//		squareSet.add(new Square(10));
//		
//		
//		System.out.println(squareSet);
//		
//		System.out.println(squareSet.size());
//		
//		
//		
//		for(Square s: squareSet) {
//			System.out.println(s);
//		}
//		
//		squareSet.clear();
//		System.out.println(squareSet.isEmpty());
		
		
		
		
		
		
	}

}
