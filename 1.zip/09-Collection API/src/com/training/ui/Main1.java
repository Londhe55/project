package com.training.ui;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main1 {

	public static void main(String[] args) {	
		
//		List<Integer> mylist1 = new ArrayList<Integer>();
//		
//		mylist1.add(10);
//		mylist1.add(20);
//		mylist1.add(30);
//		mylist1.add(40);
//		mylist1.add(50);
//		
//		System.out.println(mylist1);
//		
//		mylist1.add(0, 100);
//		mylist1.add(1000);
//		
//		System.out.println(mylist1);
//		
//		System.out.println(mylist1.size());  // To check size of the list
//		
//		System.out.println(mylist1.get(0));  // Get the 0 th index element
//		
//		System.out.println(mylist1.get(2));    // Get the element of 2 nd index
//		
//		System.out.println(mylist1.get(mylist1.size()-1));   // Get the last element
//		
//		
//		System.out.println(mylist1.set(0, 1));   // Replace 0 th index value with 1
//		
//		System.out.println(mylist1.contains(40));  // If 40 contains then true Otherwise False
//		
////		System.out.print(mylist1.clear());    // Clear the all element and brackets remain
//		
//		mylist1.remove(Integer.valueOf(50));
//		System.out.println(mylist1);   //remove 
		
		
		
		
		
		
		//LinkedList
		
		
		// Faster than ArrayList
		// Contains Duplicate
		// Maintains Insertion Order
		// Null values allowed
		
		
		List<Integer> mylist1 = new LinkedList();
		
		mylist1.add(10);
		mylist1.add(20);
		mylist1.add(30);
		mylist1.add(20);
		mylist1.add(40);
		mylist1.add(50);
		mylist1.add(null);
		mylist1.add(null);
		
		
		// Traditional For Loop
		for(int i = 0; i < mylist1.size(); i++) {
			System.out.println(mylist1.get(i));
		}
		
		// Modern For Loop
		for(Integer i: mylist1) {
			System.out.println(i);
		}
		
//		System.out.println(mylist1);
//		
//		mylist1.add(0, 100);
//		mylist1.add(1000);
//		
//		System.out.println(mylist1);
//		
//		System.out.println(mylist1.size());  // To check size of the list
//		
//		System.out.println(mylist1.get(0));  // Get the 0 th index element
//		
//		System.out.println(mylist1.get(2));    // Get the element of 2 nd index
//		
//		System.out.println(mylist1.get(mylist1.size()-1));   // Get the last element
//		
//		
//		System.out.println(mylist1.set(0, 1));   // Replace 0 th index value with 1
//		
//		System.out.println(mylist1.contains(40));  // If 40 contains then true Otherwise False
//		
////		System.out.print(mylist1.clear());    // Clear the all element and brackets remain
//		
//		mylist1.remove(Integer.valueOf(50));
//		System.out.println(mylist1);   //remove 
		
		
	}

}
