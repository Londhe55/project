package com.training.model;

import java.util.Objects;

public class Employee implements Comparable<Employee>{
	
	
	private int id;
	private String name;
	private String gender;
	private double salary;
	private char grade;
	
	
	
	
	public Employee(int id, String name, String gender, double salary, char grade) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.salary = salary;
		this.grade = grade;
	}




	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getGender() {
		return gender;
	}




	public void setGender(String gender) {
		this.gender = gender;
	}




	public double getSalary() {
		return salary;
	}




	public void setSalary(double salary) {
		this.salary = salary;
	}




	public char getGrade() {
		return grade;
	}




	public void setGrade(char grade) {
		this.grade = grade;
	}




	@Override
	public String toString() {
		return "\nEmployee [id=" + id + ", name=" + name + ", gender=" + gender + ", salary=" + salary + ", grade="
				+ grade + "]";
	}




	@Override
	public int hashCode() {
		return Objects.hash(id);
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return id == other.id;
	}




	@Override
	public int compareTo(Employee o) {

		return this.id - o.id;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
