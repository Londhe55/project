package com.training.model;

import java.util.Comparator;

public class EmployeeIdComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		
		
		// If you want descending order the you can change 1 to -1 and -1 to 1
		
		if(o1.getId() < o2.getId()) {
			return -1;
		}
		else if(o1.getId() > o2.getId()) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
	

}
