package com.training.model;

import java.util.Objects;

public class Circle implements Comparable<Circle>{
	
	private int radius;
	
	

	public Circle(int radius) {
		super();
		this.radius = radius;
	}



	public int getRadius() {
		return radius;
	}



	public void setRadius(int radius) {
		this.radius = radius;
	}



	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}



	@Override
	public int hashCode() {
		return Objects.hash(radius);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle other = (Circle) obj;
		return radius == other.radius;
	}



	@Override
	public int compareTo(Circle o) {

		
		if(this.radius < o.radius) {
			return -1;
		}
		else if (this.radius < o.radius) {
			return 1;
		}
		else {
			return 0;
		}
		
		
		
		
		// Also you can use    return this.radius - o.radius;
		// Also you can use    return Integer.compare(this.radius, o.radius);
	}
	
	
	

}
