package com.training.model;

import java.util.Objects;

public class Student implements Comparable<Student>{
	
	
	private int rollNumber;
	private String name;
	private double marks;
	private int ratings;
	
	
	
	
	
	public Student(int rollNumber, String name, double marks, int ratings) {
		super();
		this.rollNumber = rollNumber;
		this.name = name;
		this.marks = marks;
		this.ratings = ratings;
	}
	
	
	
	@Override
	public String toString() {
		return "\n Student [rollNumber=" + rollNumber + ", name=" + name + ", marks=" + marks + ", ratings=" + ratings
				+ "]";
	}
	
	
	
	
	
	
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}


	
	
	
	

	



	@Override
	public int hashCode() {
		return Objects.hash(marks);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Double.doubleToLongBits(marks) == Double.doubleToLongBits(other.marks);
	}



	@Override
	public int compareTo(Student o) {
		
		
		
//		return (int) (this.marks - o.marks);
		
		return Double.compare(this.marks, this.marks);
	}
	
	
	
	
	
	
	

}
