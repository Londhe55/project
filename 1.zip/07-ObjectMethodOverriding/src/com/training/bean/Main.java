package com.training.bean;

import com.training.ui.Employee;
import com.training.ui.Square;

public class Main {

	public static void main(String[] args) {
		
		Square s1 = new Square(10);
		
		System.out.println(s1.hashCode());
		System.out.println(s1.toString());
		System.out.println(s1.getArea());
		
		System.out.println(s1.toString());
		
		Employee e1 = new Employee(101, "Veer", 10000.00);
		System.out.println(e1);
		
		Employee e2 = new Employee(101, "Dharmavir", 50000);
		System.out.println(e2);
		
		int a =10;
		int b = 10;
		
		System.out.println(a==b);
		
		System.out.println(e1==e2);
		
		System.out.println(e1.equals(e2));
		
		// Below line shows NullPointerException
		System.out.println(e1.equals(null));
		
		System.out.println(e1.equals(s1));
		
		System.out.println(e1.hashCode());

		
		
		
	}
	
	

}

// When you call object then also toString method executed automatically

// You Can Generate to String method through the eclipse automatically

