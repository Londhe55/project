package com.training.ui;

public class Square {
	
	int size;
	

	public Square(int size) {
		super();
		this.size = size;
	}
	
	public int getArea() {
		return this.size *this.size;
	}
	
	
	public String toString() {
		
		return "Square["+ "Size = " + this.size +" ] ";
	}
	

}
