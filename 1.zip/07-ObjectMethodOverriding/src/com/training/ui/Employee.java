package com.training.ui;

public class Employee {
	
	int id;
	String name;
	double basicSalary;
	
	
	public Employee(int id, String name, double basicSalary) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
	}
	
	public String toSTring() {
		
		return "EMployee["+" id=" + this.id +", Name =" +this.name+"]";
	}
	
	
	public int hashCode() {
		
		int temp;
		temp = (int)(basicSalary * 100);
		return temp;
	}
	
	
	
	public boolean equals(Object o) {
		
		Employee other = ( Employee )o;
		
		if (o == null) {
			return false;
		}
		
		if (this == o) {
			return true;
		}
		
		
		if (!(o instanceof Employee)) {
			return false;
		}
		
		if (this.id == other.id && this.basicSalary == other.basicSalary) {
			return true;
		}
		else {
			return false;
		}
	}
	
	

}

// You can not use name in the hashcode

// Also whatever you used in the equals method that only you can use in the hashcode

