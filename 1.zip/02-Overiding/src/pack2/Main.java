package pack2;

import pack1.A;
import pack1.B;

public class Main {

	public static void main(String[] args) {
		
		
		A obj = new A();
		obj.m1(5);
		
		B b = new B();
		b.m1(10);
		
		A a = new A();
		a.m1(4);

	}

}
