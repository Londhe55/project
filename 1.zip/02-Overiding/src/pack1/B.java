package pack1;

public class B extends A {

	
	@Override
	public void m1(int a) {
		System.out.println(a*a*a);
	}
	
	
	public void m2() {
		System.out.println("GoodBye");
	}
}




