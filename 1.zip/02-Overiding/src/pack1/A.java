package pack1;

public class A {
	
	public void m1(int a) {
		System.out.println(a*a);
	}
	
	public void m2() {
		System.out.println("Welcome");
	}

}




//You can increament level of access But you can not reduce
//private method can not be overided
//Final Method can not be override
//Static method we can not override
//COnstructor can not be overide


// Upcasting  ===> in which you can create object using subclass 

// Static method invoked based upon reference type
// Instance method invoked besed upon the object