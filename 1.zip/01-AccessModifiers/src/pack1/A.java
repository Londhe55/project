package pack1;

public class A {
	
	private int v1;
	int v2;
	protected int v3;
	public int v4;
	
	
	

}


// private
// default
// protected
// public