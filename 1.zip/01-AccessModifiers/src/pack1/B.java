package pack1;

public class B {
	
	
		
		A obj = new A();
		
		public void test1() {
//			System.out.println(obj.v1);   // The access modifier is Private so we can not access in freind class also
			System.out.println(obj.v2);
			System.out.println(obj.v3);
			System.out.println(obj.v4);
		
	}
}
