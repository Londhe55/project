package pack2;

import pack1.A;

public class E {
	
	public static void main(String[] args) {
		
		A obj = new A();
		
//		System.out.println(obj.v1);   // private variable can not access
//		System.out.println(obj.v2);	  // default variable can not access
//		System.out.println(obj.v3);   // protected variable can not access
		System.out.println(obj.v4);
	}
	


}
