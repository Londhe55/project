package pack2;
import pack1.A;

public class C {

	
	public void test2() {
		
		A obj = new A();
//		System.out.println(obj.v1);  // Private 
//		System.out.println(obj.v2);  // default 
//		System.out.println(obj.v3);  // protected
		System.out.println(obj.v4);
	}
}
