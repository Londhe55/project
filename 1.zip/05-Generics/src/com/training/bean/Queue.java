package com.training.bean;

public interface Queue<T> {
    void enQueue(T e);
    T remove();
}