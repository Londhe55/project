package com.training.bean;

@SuppressWarnings("unchecked")
public class QueueImpl<T> implements Queue<T> {

    private T[] queue;
    private int front, rear, size, capacity;

    public QueueImpl(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be greater than zero.");
        }
        this.capacity = capacity;
        this.queue = (T[]) new Object[capacity]; 
        this.front = 0;
        this.rear = -1;
        this.size = 0;
    }

    @Override
    public void enQueue(T e) {
        if (isFull()) {
            throw new IllegalStateException("Queue is full");
        }
        rear = (rear + 1) % capacity;
        queue[rear] = e;
        size++;
    }

    @Override
    public T remove() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        T item = queue[front];
        queue[front] = null; 
        front = (front + 1) % capacity;
        size--;
        return item;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isFull() {
        return size == capacity;
    }
}