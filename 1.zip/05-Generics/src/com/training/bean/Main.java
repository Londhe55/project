package com.training.bean;

public class Main {
    public static void main(String[] args) {

        
        Queue<String> stringQueue = new QueueImpl<>(10);
        stringQueue.enQueue("Apple");
        stringQueue.enQueue("Banana");
        stringQueue.enQueue("Mango");
        System.out.println(stringQueue.remove()); 

       
        Queue<Integer> intQueue = new QueueImpl<>(10);
        intQueue.enQueue(10);
        intQueue.enQueue(20);
        intQueue.enQueue(30);
        System.out.println(intQueue.remove()); 
        System.out.println(intQueue.remove()); 

        
        Queue<Float> floatQueue = new QueueImpl<>(5);
        floatQueue.enQueue(1.5f);
        floatQueue.enQueue(2.5f);
        System.out.println(floatQueue.remove()); 

        
        Queue<Character> charQueue = new QueueImpl<>(5);
        charQueue.enQueue('A');
        charQueue.enQueue('B');
        System.out.println(charQueue.remove()); 
        
        
        Queue<Double> doubleQueue = new QueueImpl<>(5);
        doubleQueue.enQueue(10.5);
        doubleQueue.enQueue(20.75);
        System.out.println(doubleQueue.remove()); 
        System.out.println(doubleQueue.remove()); 

        
        Queue<Person> personQueue = new QueueImpl<>(3);
        personQueue.enQueue(new Person("Alice", 25));
        personQueue.enQueue(new Person("Bob", 30));

        System.out.println(personQueue.remove()); 
        System.out.println(personQueue.remove()); 
    }
}