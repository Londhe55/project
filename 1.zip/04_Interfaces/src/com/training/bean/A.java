package com.training.bean;

public interface A {

}
