package com.training.bean;

public interface B extends A {
	
	void read();

}
