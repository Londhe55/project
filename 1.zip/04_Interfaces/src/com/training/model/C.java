package com.training.model;

public class C  implements A,B{
	
	public void m1(double a) {
		System.out.println();
		
	}
	
	
	
	public void m2(boolean a) {
			
		}
	
	public void m3(char ch) {
		
	}

}
