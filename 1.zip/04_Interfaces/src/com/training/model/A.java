package com.training.model;

public interface A {
	
	void m1(double a);

}


// we can implements more than one interfaces
//  when interface want to implmets another interface then we use extends keywords

// variable declaring inside the interface that are public static final variable


// Interface can inherit another interface using extends keywords 
// In java or later version interfaces can contain defaults method
// in java 8 or later version interface  can contain static methoids 
// variables defined in the interfaces are public static final 



// Functional Interfaces

	// Feature added in java 1.8

	// Interfaces can contain only one method it is functional interfaces

