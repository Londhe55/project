package com.training.model;

public interface B {
	
	void m2(boolean a);
	void m3(char ch);

}



