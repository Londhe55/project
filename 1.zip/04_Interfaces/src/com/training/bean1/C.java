package com.training.bean1;

public class C implements A {

	@Override
	public void demo1() {

		System.out.println("Demo 1");
	}

}
