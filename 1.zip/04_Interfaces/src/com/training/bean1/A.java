package com.training.bean1;

public interface A {
	void demo1();
	
	
	// default method intrduced in 1.8 when we want to introduce new method 
	// also static method
	
	
	
//	default Method
	default void demo2() {
		System.out.println("Deafult Implemetation");
	}
	
//	static Method
	static void demo3() {
		System.out.println("Static Method");
	}

}
