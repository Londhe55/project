package com.training.bean1;

public class B implements A {
	
	public void m1() {
		System.out.println();
	}

	@Override
	public void demo1() {
		System.out.println("Demo Method");
	}

}
