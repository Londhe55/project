package com.training.bean1;

public class D {

}
